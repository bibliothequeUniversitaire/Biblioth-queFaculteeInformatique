<?php

require_once("identifier.php");
?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Nouveau ensignant</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
	</head>
	<body>
		<?php include("nouveau.php");?>
        <style>
         body {
             background-image: url('95571686_2695129650770008_1954315548242214912_n.jpg');
              }
       </style>
     <div class="container">
			
            <div class="panel panel-info margetop" style="color: black">
				<div class="panel-heading" id="color" style="color: black">Veuillez saisir les données du nouveau ensignant</div>
				<div class="panel-body">
                    <form method="post" action="insertEnseignant.php" class="form"      enctype="multipart/form-data" >
                        <!--post pour envoyer--> 
                       <div class="form-group" >
                           <label>Nom d'enseignant:</label>   
                           <input type="text" name="nom" 
                                  placeholder="Nom d'enseignant"           
                                  class="form-control" />
                       </div>    
                        
                        <div class="form-group" >
                            <label>Prenom d'enseignant:</label>   
                            <input type="text" name="prenom" placeholder="Prenom d'enseignant"            
                                   class="form-control" />
                       </div>
                        
                        
                       
                        
                         <div class="form-group" >
                            <label >N° carte:</label>   
                            <input type="number" 
                             
                                   name="numCarte" placeholder="N° carte"            class="form-control" />
                       </div>
                        
                        
                        
                       
           
                        
                         <div class="form-group" >
                <label for="cevilite">Cevilite:</label>  
                <div class="radio">
                   <label><input type="radio" name="cevilite"  value="F" checked/>F</label><br>
                   <label><input type="radio" name="cevilite"  value="M"/>M</label>            
                </div>   
            </div> 
                        
                        
                        
                     <button type="submit" class="btn btn-warning" style="color: black">
                      <span class="glyphicon  glyphicon-save" style="color: black"></span>
                        Enregistrer
                     </button>
                   
                </form> 
                    
                    
                    
                    
                    
                </div>
        </div>
        
        </div>
							
	</body>
</html>
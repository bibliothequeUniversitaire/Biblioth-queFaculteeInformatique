<?php

require_once("identifier.php");

require_once("connectiDb.php");

 
 $idc=$_SESSION['idc'];

     $dateR=$_SESSION['dateR'];
    $dateFen=$_SESSION['dateFEn'];
    $dateFet=$_SESSION['dateFE'];
     $numCarte=isset($_POST['numcarte'])?$_POST['numcarte']:"";
$type=isset($_POST['typee'])?$_POST['typee']:"E";




$requeteN="select nbrCopie from cd where idCd='$idc'";

 $resultatN=$pdo->query($requeteN);
$nbrCopie=$resultatN->fetch();
 $nbrCopie=$nbrCopie['nbrCopie'];
 
 

$debut = strtotime($dateR);
$fin = strtotime($type);
$dif = ceil(abs($fin - $debut) / 86400);


$requeteidEn="select idEnseignant from enseignant where numcarte='$numCarte'";

 $resultatidEn=$pdo->query($requeteidEn);
$iden=$resultatidEn->fetch();
 $idEn=$iden['idEnseignant'];

 $requeteidE="select idEtudiant from etudiant where numcarte='$numCarte'";

 $resultatidE=$pdo->query($requeteidE);
$ide=$resultatidE->fetch();
 $idE=$ide['idEtudiant'];
/////////////////////////////////////////////////////////
$requeteTeste="select count(idEtudiant) from reserver where idEtudiant='$idE'";

 $resultatTeste=$pdo->query($requeteTeste);
$n=$resultatTeste->fetch();
 $y=$n['count(idEtudiant)'];


$requeteT="select count(idEnseignant)  from reserver where idEnseignant='$idEn'";

 $resultatT=$pdo->query($requeteT);
$p=$resultatT->fetch();
 $m=$p['count(idEnseignant)'];
///////////////////////////////////////////////

$requeteP="select nom from etudiant as e,penalite as p where
(p.idEtudiant=e.idEtudiant) and e.idEtudiant='$idE'";

 $resultatP=$pdo->query($requeteP);
$k=$resultatP->fetch();
 $a=$k['nom'];



////////////////////////////////
$requeteP="select nom from enseignant as e,penalite as p where
(p.idEnseignant=e.idEnseignant) and e.idEnseignant='$idEn'";

 $resultatP=$pdo->query($requeteP);
$r=$resultatP->fetch();
 $j=$r['nom'];


if(!empty($idEn) or !empty($idE)){
    if($dif==5){  
      if(empty($j)){    
        if($m<3){
       $requeteEn="insert into reserver(idCd,idEnseignant,dateRes,dateFinRes) values(?,?,?,?)";    
   $param=array($idc,$idEn,$dateR,$dateFen);

    $resultatEn = $pdo->prepare($requeteEn);
    $resultatEn->execute($param);

   $nbrCopie=$nbrCopie-1; 
        
$requetenbr="update cd set nbrCopie='$nbrCopie' where idCd='$idc';";    
   $paramm=array($nbrCopie);

    $resultatnbr = $pdo->prepare($requetenbr);
    $resultatnbr->execute($paramm);
        header("location:cd.php");}else{
		
			echo'<link href="../css/erreur.css" rel="stylesheet" type="text/css">';
			echo'<p><strong>Erreur !</strong> vous avez déja effectuer 3 réservations  !!</p>';

        }}else{
             echo'<link href="../css/erreur.css" rel="stylesheet" type="text/css">';
			echo'<p><strong>Erreur !</strong> vous ete penalisé  !!</p>';
          }
    }else{ 
      if(empty($a)){    
        if($y<2){
    $requeteE="insert into reserver(idCd,idEtudiant,dateRes,dateFinRes) values(?,?,?,?)";    
   $param=array($idc,$idE,$dateR,$dateFet);

    $resultatE = $pdo->prepare($requeteE);
    $resultatE->execute($param);

   $nbrCopie=$nbrCopie-1;    
        $requetenbr="update cd set nbrCopie='$nbrCopie' where idCd='$idc';";    
   $paramm=array($nbrCopie);

    $resultatnbr = $pdo->prepare($requetenbr);
    $resultatnbr->execute($paramm);
        header("location:cd.php");}else{
           echo'<link href="../css/erreur.css" rel="stylesheet" type="text/css">';
		   echo'<p><strong>Erreur !</strong> vous avez déja effectuer 2 réservations  !!</p>';
}}else{
       echo'<link href="../css/erreur.css" rel="stylesheet" type="text/css">';
	   echo'<p><strong>Erreur !</strong>vous ete deja penalise  !!</p>';
          }}
}else{
       echo'<link href="../css/erreur.css" rel="stylesheet" type="text/css">';
	   echo'<p><strong>Erreur !</strong>Votre numéro de carte est erroner !!</p>';    
}




?>

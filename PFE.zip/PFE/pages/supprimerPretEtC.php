<?php
   session_start();
  if(isset($_SESSION['user'])){//utilisateur connecter
	require_once("connectiDb.php");
	
	
	$idcet=$_GET['idcet'];
	$idet=$_GET['idet'];
    $nbr=$_GET['nbr'];
    $idEmprrt=$_GET['idEmprrt'];
     
	$requete="delete from emprunt where idCd=? and idEmrunt=?";			
	$param=array($idcet,$idEmprrt);	
	$resultatC = $pdo->prepare($requete);
    $resultatC ->execute($param);
      
       $nbr=$nbr+1; 
      ////////////////////
      
      $requetenbr="update cd set nbrCopie='$nbr' where idCd='$idcet';";    
   $paramm=array($nbr);

    $resultatnbr = $pdo->prepare($requetenbr);
    $resultatnbr->execute($paramm);
      
      
      
	header("location:cdPretEt.php");
      }else{//si l'utilisateur n'est pa authentifier
      header("location:login.php");
  }
	
?>
    
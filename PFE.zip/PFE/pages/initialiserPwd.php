<?php
require "PHPMailer/PHPMailerAutoload.php";
 $bdd = new PDO('mysql:host=localhost;dbname=jdida;charset=utf8;', 'root', '');
if(isset($_POST['valider_email'])){
  $email = $_POST['email'];
  $requete_sur_email = $bdd->prepare('select * from utilisateur where email = ?');
  $requete_sur_email->execute(array($email));
  if($requete_sur_email->rowCount() > 0){
	$info_user = $requete_sur_email->fetch();
	  $id_user = $info_user['idUtilisateur'];
	
	  $generator="ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
	  
      $code=substr(str_shuffle($generator),0,8);

        $requete=$bdd->prepare("update utilisateur set pwd=md5('$code') where idUtilisateur=$id_user");
    $requete->execute();

	function smtpmailer($to, $from, $from_name, $subject, $body)

    {

        $mail = new PHPMailer();

        $mail->IsSMTP();

        $mail->SMTPAuth = true; 

 

        $mail->SMTPSecure = 'ssl'; 

        $mail->Host = 'smtp.gmail.com';

        $mail->Port = 465;  

        

        $mail->Username = 'nadjetradia22@gmail.com'; 

        $mail->Password = '0542394025';  

        

   

        $mail->IsHTML(true);

        

        $mail->From="nadjetradia22@gmail.com";

        $mail->FromName=$from_name;

        $mail->Sender=$from;

        $mail->AddReplyTo($from, $from_name);

        $mail->Subject = $subject;

        $mail->Body = $body;

        $mail->AddAddress($to);

        if(!$mail->Send())

        {

            $error ="Une erreur s'est produite lors de l'envoie du mail !";

            return $error; 

        }

        else 

        {

            $error = "Email envoyé avec succès !";  

            return $error;

        }

    }

    

    

    $to   = $info_user['email'];

    

    $from = 'nadjetradia22@gmail.com';

    

    $name = 'Admin de site';

    

    $subj = 'Récupération de votre compte sur notre site';

    

    $msg = 'Bonjour voici votre code veuillez le modifier à la prochaine ouverture de session :'.$code;

    

    $error=smtpmailer($to, $from, $name ,$subj, $msg);

	  
    
      
      
      
      
	  
	  
  }else{
	  echo "l'email est invalide(n'existe pas dans le site)";
  }



      
    
}
?>



<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8" />
    <title>Initiliser votre mot de passe</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/monStyle.css">

</head>
<body>
	<div class="container col-md-6 col-md-offset-3">
		<br>
		<div class="panel panel-primary ">
			<div class="panel-heading">Initiliser votre mot de passe</div>
			<div class="panel-body">

				<form method="post" action="">

					<div class="form-group">
						<label for="email" class="control-label">
							Veuillez saisir votre
							Email de récuperation
						</label>
						
                        
                        <input type="email" name="email" class="form-control">
						 

					</div>

                    	 
					<button 
						type="submit" name="valider_email"
						class="btn btn-success">
							Initialiser le mot de passe
					</button>

				</form>
<?php
	 if(isset($error)){
	  echo $error;
	 }
	 
	 ?>
					
			</div>
			
		</div>
		
		
	</div>

</body>
</html>

<?php
require_once("identifier.php");
require_once("connectiDb.php");

    $nom=isset($_POST['nom'])?$_POST['nom']:"";//les donées sont envoyée par la méthode post
    $prenom=isset($_POST['prenom'])?$_POST['prenom']:"";
    $numCarte=isset($_POST['numCarte'])?$_POST['numCarte']:"";
    $cevilite=isset($_POST['cevilite'])?$_POST['cevilite']:"F";
    $niveau=isset($_POST['niveau'])?$_POST['niveau']:"";
    $type=isset($_POST['typee'])?$_POST['typee']:"E";


$requeteidEn="select idEnseignant from enseignant where numCarte='$numCarte'";

 $resultatidEn=$pdo->query($requeteidEn);
 $iden=$resultatidEn->fetch();
 $idEn=$iden['idEnseignant'];

 $requeteidE="select idEtudiant from etudiant where numCarte='$numCarte'";

 $resultatidE=$pdo->query($requeteidE);
$ide=$resultatidE->fetch();
 $idE=$ide['idEtudiant'];
/////////////////



if(empty($idEn) and empty($idE)){

if($type=='E'){
   $requeteE="insert into etudiant(nom,prenom,numCarte,cevilite,niveau) values(?,?,?,?,?)";    
   $param=array($nom,$prenom,$numCarte,$cevilite,$niveau);


    $resultatE = $pdo->prepare($requeteE);
    $resultatE->execute($param);
}else{
    
      $requeteEn="insert into   enseignant(nom,prenom,numCarte,cevilite) values(?,?,?,?)";    
   $param=array($nom,$prenom,$numCarte,$cevilite);


    $resultatEn = $pdo->prepare($requeteEn);
    $resultatEn->execute($param);
    
}



	header("location:login.php");
}else{
echo'<link href="../css/erreur.css" rel="stylesheet" type="text/css">';
	echo'<p><strong>Erreur !</strong>Votre numéro de carte est deja existe !!</p>';	
      
}



?>
<meta charset="utf-8" />
<?php
    require_once("identifier.php");
	require_once("connectiDb.php");
     
     $titrec=isset($_GET['titreC'])?$_GET['titreC']:"";
     $nomprenomc=isset($_GET['nomprenomC'])?$_GET['nomprenomC']:"";
     $auteurc=isset($_GET['auteurC'])?$_GET['auteurC']:"";
     
    $sizeE=isset($_GET['size'])?$_GET['size']:3;
    $pageE=isset($_GET['page'])?$_GET['page']:1;
    $offsetE=($pageE-1)*$sizeE;
     $requeteE="select  p.idCd,e.idEtudiant,etudiant,titre,idEmrunt,nom,prenom,datePret,dateRetour,nbrCopie
                 from cd as c,emprunt as p,etudiant as e
                 where (c.idCd=p.idCd and p.idEtudiant=e.idEtudiant)
                 
                 and titre like '%$titrec%' 
                 and etudiant like '%$auteurc%' 
                 and (nom like '%$nomprenomc%' or prenom like '%$nomprenomc%')
                 limit $sizeE 
                 offset $offsetE";
     $requeteCountE="select count(*) countC from cd as c,emprunt as p,etudiant as e
                 where (c.idCd=p.idCd and p.idEtudiant=e.idEtudiant)
                 and titre like '%$titrec%' 
                 and etudiant like '%$auteurc%'
                 and (nom like '%$nomprenomc%' or prenom like '%$nomprenomc%')
                 ";
$resultatE=$pdo->query($requeteE);//execution de la requete
     $resultatCountE=$pdo->query($requeteCountE);
     $tabCountE=$resultatCountE->fetch();
     $nbrCdE=$tabCountE['countC'];
     $resteE=$nbrCdE % $sizeE; // % operateur modulo:le reste de la division euclidiene de $nbrFiliere par
                               //$size
   if($resteE==0)//nbrFiliere est un multiple de size
        $nbrPageE=$nbrCdE/$sizeE;
   else
		$nbrPageE=floor($nbrCdE/$sizeE)+1;// floor retourne la partie entière d'un nombre 
										// decimale
	


    $sizeEn=isset($_GET['size'])?$_GET['size']:4;
    $pageEn=isset($_GET['page'])?$_GET['page']:1;
    $offsetEn=($pageEn-1)*$sizeEn;
    
    
    
    
    
?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Gestion des prets</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

		
        
	</head>
    <body>
        <?php include("nouveau.php");?>
       <style>
         body {
             background-image: url('95571686_2695129650770008_1954315548242214912_n.jpg');
              }
       </style>    
		
      <div class="container ">    <!--container permet d'apliquer une marge gauche et droite-->
        <div class="panel panel-info margetop" id="padding">
          <div class="panel-heading" id="color" style="color: black">Recherche des prets</div>
           <div class="panel-body">
             <form method="get" action="cdPretEt.php" class="form-inline" >
                <div class="form-group" >
                <input type="text" name="titreC" placeholder="Titre du cd" class="form-control" value="<?php echo $titrec?>"/>
                    &nbsp &nbsp
                    <input type="text" name="auteurC" placeholder=" Auteur " class="form-control" value="<?php echo $auteurc?>"/>
                    &nbsp &nbsp
                     <input type="text" name="nomprenomC" placeholder="Nom ou Prenom étudiant" class="form-control" value="<?php echo $nomprenomc?>"/>
                 </div> 
                 
                 
                 
                 &nbsp &nbsp
                    <button type="submit" class="btn btn-warning" style="color: black">
                      <span class="glyphicon glyphicon-search" style="color: black"></span>
                        Rechercher...
                  </button>
                    
                  
                </form>    
               
               </div>
           </div>
        
           <div class="panel panel-info margetop">
               <div class="panel-heading" id="color" style="color: black">Liste des prets des étudiants(<?php echo $nbrCdE?> Cds)</div>
               <div class="panel-body">
                  <table class="table table-striped table-bordered">
                     <thead>
                       <tr style="color: chocolate">
                       <th >N°cd</th><th >N°Emprunte</th>
					   <th >Titre</th>
					   <th >Auteur</th>
                       <th >N°Lecteur</th>
					   <th >Nom étudiant</th>
                       <th >Prénom étudiant</th>
                       <th >Date pret</th>
					   <th >Date retour</th>
                <?php if($_SESSION['user']['role']=='ADMIN'){?>             
                       <th>Pénalité</th> 
                       <th>Action</th>
                            <?php }?>
                        </tr>
                     </thead>          
                     <tbody>
                        
                          <?php while($cd=$resultatE->fetch()){?>   
                            <tr class="<?php 
                                  if($_SESSION['user']['role']=='ADMIN'){      
                                 $dateR=$cd['dateRetour'];
                                  
                       $dateAuj= date("Y-m-d");
                       $dateA = date_create($dateAuj);                  
                       $dateR = date_create($dateR); 
                             $Auj= date_timestamp_get($dateA);
                             $d= date_timestamp_get($dateR);         
                                      
                                      
                                        if($Auj>=$d)
                                        echo 'danger' ;          
                                  }
                                        ?>">
                              <td ><?php echo $cd['idCd']?></td>
                              <td ><?php echo $cd['idEmrunt']?></td>
                              <td ><?php echo $cd['titre']?></td>
                              <td ><?php echo $cd['etudiant']?></td>
                              <td ><?php echo $cd['idEtudiant'] ?></td>
                              <td ><?php echo $cd['nom'] ?></td> 
                              <td ><?php echo $cd['prenom'] ?></td> 
                              <td ><?php echo $cd['datePret']?></td>
                              <td ><?php echo $cd['dateRetour']?></td>
                         <?php if($_SESSION['user']['role']=='ADMIN'){?>         
                             <td><a onclick="return confirm('La punition a été exécutée' )" 
                                     href="insertPenEtC.php?idle=<?php echo $cd['idCd']?>
                                         &ide=<?php echo $cd['idEtudiant']?>"><span class="glyphicon glyphicon-pushpin" style="color: #994d00"></span>
                                  </a>
                                </td> 
                                
                              <td >
                                  &nbsp &nbsp  
                                 <a onclick="return confirm('Etes vous sure de vouloire supprimer ce pret' )"
                                     href="supprimerPretEtC.php?idcet=<?php echo $cd['idCd']?>
                                           &idet=<?php echo $cd['idEtudiant']?>&nbr=<?php echo $cd['nbrCopie']?>
                                      &idEmprrt=<?php echo $cd['idEmrunt']?>      
                                           
                                           "><span class="glyphicon glyphicon-trash" style="color: #994d00"></span></a>
                              </td>    
                                <?php }?>  
                            </tr>
                          <?php }?>    
                     </tbody>    
                   </table>   
                      
               </div>
          </div>
        
        <div>
                   
                     <ul class="pagination" >
							
							<?php for($i=1;$i<=$nbrPageE;$i++){ ?>
				              <li class="<?php if($i==$pageE) echo 'active' ?>">

								<a href="cdPretEt.php?page=<?php echo $i ?>&titrec=<?php echo $titrec?>">	
										 <?php echo $i ?>
									</a>
								</li>
							<?php } ?>	
						</ul>
                   
                   
                   </div>
        
        
        
        
        
        
        
        
        
        
          <!-------------->
    
          
          <!----------->
    </div>    
    </body>
</html>    
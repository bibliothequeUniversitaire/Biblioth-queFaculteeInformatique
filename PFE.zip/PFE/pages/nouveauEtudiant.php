<?php

require_once("identifier.php");
?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Nouveau etudiant</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
	</head>
	<body>
		<?php include("nouveau.php");?>
        <style>
         body {
             background-image: url('95571686_2695129650770008_1954315548242214912_n.jpg');
              }
       </style>
     <div class="container">
			
            <div class="panel panel-info margetop">
				<div class="panel-heading" id="color" style="color: black">Veuillez saisir les données du nouveau etudiant</div>
				<div class="panel-body">
                    <form method="post" action="insertEtudiant.php" class="form"      enctype="multipart/form-data" >
                        <!--post pour envoyer--> 
                       <div class="form-group" >
                           <label>Nom d'étudiant:</label>   
                           <input type="text" name="nom" 
                                  placeholder="Nom d'étudiant"           
                                  class="form-control" />
                       </div>    
                        
                        <div class="form-group" >
                            <label>Prenom d'étudiant:</label>   
                            <input type="text" name="prenom" placeholder="Prenom d'étudiant"            
                                   class="form-control" />
                       </div>
                        
                        
                       
                        
                         <div class="form-group" >
                            <label >N° carte:</label>   
                            <input type="number" 
                             
                                   name="numCarte" placeholder="N° carte"            class="form-control" />
                       </div>
                        
                        
                        
                       
           
                        
                         <div class="form-group" >
                <label for="cevilite">Cevilite:</label>  
                <div class="radio">
                   <label><input type="radio" name="cevilite"  value="F" checked/>F</label><br>
                   <label><input type="radio" name="cevilite"  value="M"/>M</label>            
                </div>   
            </div> 
                        
                        
                        <div class="form-group" >
                       <label for="niveau">Niveau:</label>
                       <select name="niveau" class="form-control" id="niveau"><!--this.from.submit() evenement de js-->
                       <option value="all">Tous les niveaux</option>
                       <option value="l2" selected>Licence 2</option>
                       <option value="l3">Licence 3</option>
                      <option value="m1">Master 1</option>
                      <option value="m2">Master 2</option>
                      </select>
                        </div>
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                     <button type="submit" class="btn btn-warning" style="color: black">
                      <span class="glyphicon  glyphicon-save" style="color: black"></span>
                        Enregistrer
                     </button>
                   
                </form> 
                    
                    
                    
                    
                    
                </div>
        </div>
        
        </div>
							
	</body>
</html>
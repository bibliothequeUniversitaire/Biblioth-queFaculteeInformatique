<?php
   session_start();
  if(isset($_SESSION['user'])){//utilisateur connecter
	require_once("connectiDb.php");
	
	
	$idcen=$_GET['idcen'];
	$iden=$_GET['iden'];
    $nbr=$_GET['nbrEn'];
    $idRescc=$_GET['idRescc'];
      
      
	$requete="delete from reserver where idCd=? and idReservation=?";			
	$param=array($idcen,$idRescc);	
	$resultatC = $pdo->prepare($requete);
    $resultatC ->execute($param);
      $nbr=$nbr+1; 
      ////////////////////
      
      $requetenbr="update cd set nbrCopie='$nbr' where idCd='$idcen';";    
   $paramm=array($nbr);

    $resultatnbr = $pdo->prepare($requetenbr);
    $resultatnbr->execute($paramm);
      
      
      
      
      
      
	header("location:cdReserverEn.php");
      }else{//si l'utilisateur n'est pa authentifier
      header("location:login.php");
  }
	
?>
    
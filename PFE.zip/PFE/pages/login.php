<?php 
  session_start();
  if(isset($_SESSION['erreurLogin']))
     $erreurLogin=$_SESSION['erreurLogin'];
     
    else{
        $erreurLogin="";
    }
   session_destroy();

?>

<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Se connecter</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	</head>
	<body>
		
        
        
                <style>
body {
  background-image: url('95571686_2695129650770008_1954315548242214912_n.jpg');
}
</style>
    <div class="container col-lg-4 col-lg-offset-4 col-md-6" style="color: black" >
			
        <div class="panel panel-info margetop">
                
           <div class="panel-heading" id="color" style="color: black">Se connecter</div> 
           <div class="panel-body" class="panel-heading" id="color" style="color: black">
                    
           <form method="post" action="seConnecter.php" class="form" ><!--enctype pour l'envoi d'un fichier-->
                        
                  <?php if(!empty($erreurLogin)){//empty c-a-d enssemble vide?>        
                  <div class="alert alert-danger">
                      <?php echo $erreurLogin ?>
                  </div>
                    <?php }?>    
               
               
                        <div class="form-group" >
                    <label for="login">Login:</label>  
                    
                <input type="text" name="login" 
                       placeholder="Login"
                       class="form-control" />
                </div>   
                        <!---->
            <div class="form-group" >
                <label for="pwd">Mot de passe:</label>  
                <input type="password" name="pwd" 
                       placeholder="Mot de passe"
                       class="form-control" />
                </div>   
                        
                         <!---->
                        
                  <button type="submit" class="btn btn-warning">
                      <span class="glyphicon glyphicon-log-in"></span>
                        Se connecter
                      
                  </button><br><br>
               
               	<a href="InitialiserPwd.php" style="color: black">Mot de passe Oublié</a>
							&nbsp &nbsp &nbsp  &nbsp  &nbsp
				<a href="nouvelUtilisateur.php" style="color: black">Créer un compte</a>	
                     
                    </form>
                    
                    
                    
                    
                </div> 
                    
                    
                </div>
        </div>
        
		
							
	</body>
</html>
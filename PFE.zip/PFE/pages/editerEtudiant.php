<?php
   require_once("identifier.php");
	require_once("connectiDb.php");
    $idE=isset($_GET['ide'])?$_GET['ide']:0;
    $requeteE="select * from etudiant where idEtudiant= $idE";
    $resultatE=$pdo->query($requeteE);
    $etudiant=$resultatE->fetch();

    $nom=$etudiant['nom'];
    $prenom=$etudiant['prenom'];
    $numCarte=$etudiant['numCarte'];
    $cevilite=$etudiant['cevilite'];
    $niveau=$etudiant['niveau'];


    


?>


<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Edition des livres</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
        
	</head>
	<body>
		<?php include("nouveau.php");?>
    <div class="container">
			
        <div style="background-color:lightbrown"  class="panel panel-primary margetop" >
                
           <div class="panel-heading"  id="color" style="color: black">Editer étudiant</div>
           <div class="panel-body">
                    
           <form method="post" action="updateEtudiant.php" class="form" enctype="multipart/form-data"><!--enctype pour l'envoi d'un fichier-->
                        
                        
                <div class="form-group" >
                    <label for="ide">N° enseignant: <?php echo $idE ?></label>  
                    
                <input type="hidden" name="ide"  class="form-control" value="<?php echo $idE ?>"/>
                </div>   
                        
                        <div class="form-group" >
                    <label for="nom">Nom:</label>  
                    
                <input type="text" name="nom" 
                       plceholder="Nom"
                       class="form-control" 
                       value="<?php echo $nom?>"/>
                </div>   
                        <!---->
            <div class="form-group" >
                <label for="prenom">Prenom:</label>  
                <input type="text" name="prenom" 
                       plceholder="Prenom"
                       class="form-control" 
                       value="<?php echo $prenom ?>"/>
                </div>   
                        <!---->
                

               
               <div class="form-group" >    
                        <label>Niveau:</label>   
                        <select name="niveau" class="form-control" id="categorie"><!--this.from.submit() evenement de js-->
                  
                  <option value="l2"<?php if($niveau==="l2") echo "selected"?>>Licence2</option>
                  <option value="l3"<?php if($niveau==="l3") echo "selected"?>>Licence3</option>
                  <option value="m1"<?php if($niveau==="m1") echo "selected"?>>Master1</option>
                    <option value="m2"<?php if($niveau==="m2") echo "selected"?>>Master2</option>        
                     </select>
                        </div>
                         <!---->
            <div class="form-group" >
                <label for="numCarte">N°carte:</label>  
                <input type="numCarte" name="numCarte" 
                       plceholder="N°carte"
                       class="form-control" 
                       value="<?php echo $numCarte ?>"/>
                </div>   
                        
                         <!---->
               
                     
               
               
               
               
               
               <div class="form-group" >
                <label for="cevilite">Cevilite:</label>  
                <div class="radio">
                   <label><input type="radio" name="cevilite"  value="F"
                                 <?php if($cevilite==="F")echo "checked"?>/>F</label><br>
                   <label><input type="radio" name="cevilite"  value="M"
                                 <?php if($cevilite==="M")echo "checked"?>/>M</label>            
                </div>   
            </div>
               
               
               
               <!---->
               
                        
                        
                        
                  <button type="submit" class="btn btn-warning" style="color: black">
                      <span class="glyphicon glyphicon-save" style="color: black"></span>
                        Enregistrer
                      
                  </button>
                     
                    </form>
                    
                    
                    
                    
                </div> 
                    
                    
                </div>
        </div>
        
		
							
	</body>
</html>
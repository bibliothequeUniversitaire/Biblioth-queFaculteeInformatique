<?php
   session_start();
  if(isset($_SESSION['user'])){//utilisateur connecter
	require_once("connectiDb.php");
	
	
	$idmet=$_GET['idmet'];
	$idet=$_GET['idet'];
	$nbr=$_GET['nbr'];

	$requete="delete from penalite where idmemoire=? and idEtudiant=?";			
	$param=array($idmet,$idet);	
	$resultatL = $pdo->prepare($requete);
    $resultatL ->execute($param);	
     $nbr=$nbr+1; 
      ////////////////////////////
      
      $requetenbr="update memoire set nbrCopie='$nbr' where idmemoire='$idmet';";    
   $paramm=array($nbr);

    $resultatnbr = $pdo->prepare($requetenbr);
    $resultatnbr->execute($paramm);
      
      
	header("location:penaliteEtm.php");
      }else{//si l'utilisateur n'est pa authentifier
      header("location:login.php");
  }
	
?>
    
<?php		
	try {
		
	    $pdo = new PDO("mysql:host=localhost;dbname=jdida", 
	        "root", "");//$pdo est un objet de la classe PDO
		
	}catch (Exception $e){
		die('Erreur de connexion: ' .$e->getMessage());//die est une fonction
		
		die('Erreur : impossible de se connecter à la base de donnée');
	}	
?>
<meta charset="utf-8" />
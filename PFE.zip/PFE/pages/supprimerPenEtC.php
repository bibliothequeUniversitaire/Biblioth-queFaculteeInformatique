<?php
   session_start();
  if(isset($_SESSION['user'])){//utilisateur connecter
	require_once("connectiDb.php");
	
	
	$idcet=$_GET['idcet'];
	$idet=$_GET['idet'];
	$nbr=$_GET['nbr'];

	$requete="delete from penalite where idCd=? and idEtudiant=?";			
	$param=array($idcet,$idet);	
	$resultatL = $pdo->prepare($requete);
    $resultatL ->execute($param);	
     $nbr=$nbr+1; 
      ////////////////////////////
      
      $requetenbr="update cd set nbrCopie='$nbr' where idCd='$idcet';";    
   $paramm=array($nbr);

    $resultatnbr = $pdo->prepare($requetenbr);
    $resultatnbr->execute($paramm);
      
      
	header("location:penaliteEtc.php");
      }else{//si l'utilisateur n'est pa authentifier
      header("location:login.php");
  }
	
?>
    
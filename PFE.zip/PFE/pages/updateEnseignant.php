

<?php
    require_once("identifier.php");
	require_once("connectiDb.php");

    $idEn=isset($_POST['iden'])?$_POST['iden']:0;
    $nom=isset($_POST['nom'])?$_POST['nom']:"";//les donées sont envoyée par la méthode post

    $prenom=isset($_POST['prenom'])?$_POST['prenom']:"";//les donées sont envoyée par la méthode post
    $numCarte=isset($_POST['numCarte'])?$_POST['numCarte']:"";
    $cevilite=isset($_POST['cevilite'])?$_POST['cevilite']:"";

    
    
 
 
    $requete="update  enseignant set 	nom=?,prenom=?,numCarte=?,cevilite=? where idEnseignant=? ";
    $param=array($nom,$prenom,$numCarte,$cevilite,$idEn);
    $resultat = $pdo->prepare($requete);
    $resultat->execute($param);	
	header("location:enseignant.php");
	
?>
<meta charset="utf-8" />
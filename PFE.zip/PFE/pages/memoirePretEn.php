<?php
    require_once("identifier.php");
	require_once("connectiDb.php");
     
     $titrem=isset($_GET['titreM'])?$_GET['titreM']:"";
     $nomprenomm=isset($_GET['nomprenomM'])?$_GET['nomprenomM']:"";
     $auteurm=isset($_GET['auteurM'])?$_GET['auteurM']:"";
    


    $sizeEn=isset($_GET['size'])?$_GET['size']:2;
    $pageEn=isset($_GET['page'])?$_GET['page']:1;
    $offsetEn=($pageEn-1)*$sizeEn;
    
    
    
    
    $requeteEn="select p.idmemoire,e.idEnseignant,etudiant,titre,idEmrunt,nom,prenom,datePret,dateRetour,nbrCopie
                 from memoire as m,emprunt as p,enseignant as e
                 where (m.idmemoire=p.idmemoire and p.idEnseignant=e.idEnseignant)
                 
                 and titre like '%$titrem%' 
                 and etudiant like '%$auteurm%' 
                and (nom like '%$nomprenomm%' or prenom like '%$nomprenomm%')
                 limit $sizeEn 
                 offset $offsetEn";
    $requeteCountEn="select count(*) countEn from memoire as m,emprunt as p,enseignant as e
                 where (m.idmemoire=p.idmemoire and p.idEnseignant=e.idEnseignant)
                 and titre like '%$titrem%' 
                 and etudiant like '%$auteurm%'
                  and (nom like '%$nomprenomm%' or prenom like '%$nomprenomm%')
                 ";
    
    $resultatEn=$pdo->query($requeteEn);
     $resultatCountEn=$pdo->query($requeteCountEn);
     $tabCountEn=$resultatCountEn->fetch();
     $nbrMemoireEn=$tabCountEn['countEn'];
     $resteEn=$nbrMemoireEn % $sizeEn; 
   
if($resteEn==0)
        $nbrPageEn=$nbrMemoireEn/$sizeEn;
   else
		$nbrPageEn=floor($nbrMemoireEn/$sizeEn)+1;
    
    
    
    
?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Gestion des prets</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

		
        
	</head>
    <body>
        <?php include("nouveau.php");?>
       <style>
         body {
             background-image: url('95571686_2695129650770008_1954315548242214912_n.jpg');
              }
       </style>    
		
      <div class="container " >    <!--container permet d'apliquer une marge gauche et droite-->
        <div class="panel panel-info margetop" id="padding">
          <div class="panel-heading" id="color" style="color: black">Recherche des prets</div>
           <div class="panel-body">
             <form method="get" action="memoirePretEn.php" class="form-inline" >
                <div class="form-group" >
                <input type="text" name="titreM" placeholder="Titre du mémoire" class="form-control" value="<?php echo $titrem?>"/>
                    &nbsp &nbsp
                    <input type="text" name="auteurM" placeholder=" Auteur " class="form-control" value="<?php echo $auteurm?>"/>
                    &nbsp &nbsp
                     <input type="text" name="nomprenomM" placeholder="Nom ou Prenom ensaignant" class="form-control" value="<?php echo $nomprenomm?>"/>
                 </div> 
                 
                 
                 
                 &nbsp &nbsp
                    <button type="submit" class="btn btn-warning" style="color: black">
                      <span class="glyphicon glyphicon-search" style="color: black"></span>
                        Rechercher...
                  </button>
                    
                  
                </form>    
               
               </div>
           </div>
        
           
          <!-------------->
          &nbsp &nbsp
          &nbsp &nbsp
        <div class="container ">
            <div class="panel panel-info margetop">
               <div class="panel-heading" id="color" style="color: black">Liste des prets des enseignants(<?php echo $nbrMemoireEn ?> Mémoires)</div>
               <div class="panel-body">
                  <table class="table table-striped table-bordered">
                     <thead>
                        <tr style="color: chocolate">
                           <th >N°livre</th>
                            <th >N°Emprunte</th><th >Titre</th><th>Auteur</th>
                            <th>N°Lecteur</th><th>Nom enseignant</th>
                            <th>Prenom enseignant</th>
                            <th >Date pret</th><th>Date retour</th>
                    <?php if($_SESSION['user']['role']=='ADMIN'){?>        
                            <th>Pénalité</th>
                            <th>Action</th>
                            <?php }?>
                           
                        </tr>
                     </thead>          
                     <tbody>
                        
                          <?php while($Memoire=$resultatEn->fetch()){?>   
                            <tr class="<?php 
                                  if($_SESSION['user']['role']=='ADMIN'){      
                                  
    
   $dateR=$Memoire['dateRetour'];
                                  
                       $dateAuj= date("Y-m-d");
                       $dateA = date_create($dateAuj);                  
                       $dateR = date_create($dateR); 
                             $Auj= date_timestamp_get($dateA);
                             $d= date_timestamp_get($dateR);         
                                      
                                  
                                        if($Auj>=$d)
                                        echo 'danger' ;       
                                  }
    
    
                                        ?>">
                              <td ><?php echo $Memoire['idmemoire']?></td>
                              <td ><?php echo $Memoire['idEmrunt']?></td>
                              <td ><?php echo $Memoire['titre']?></td>
                              <td ><?php echo $Memoire['etudiant']?></td>
                              
                              <td ><?php echo $Memoire['idEnseignant'] ?></td>
                             <td ><?php echo $Memoire['nom'] ?></td>
                             <td ><?php echo $Memoire['prenom'] ?></td>
                             <td ><?php echo $Memoire['datePret']?></td>
                              <td ><?php echo $Memoire['dateRetour']?></td> 
                               <?php if($_SESSION['user']['role']=='ADMIN'){?>  
                                <td><a 
                                       onclick="return confirm('La punition a été exécutée' )" 
                                     href="inserPenEnM.php?idmen=<?php echo $Memoire['idmemoire']?>
                                         &iden=<?php echo $Memoire['idEnseignant']?>"><span class="glyphicon glyphicon-pushpin" style="color: #994d00"></span>
                                  </a>
                                </td>
								<td >
                                  &nbsp &nbsp  
                                  <a onclick="return confirm('Etes vous sure de vouloire supprimer ce pret' )"
                                     href="supprimerPretEnM.php?idmen=<?php echo $Memoire['idmemoire']?>
                                         &iden=<?php echo $Memoire['idEnseignant']?>  
                                   &nbrEn=<?php echo $Memoire['nbrCopie']?>        
                                      &idEmprr=<?php echo $Memoire['idEmrunt']?>      
                                           
                                           "><span class="glyphicon glyphicon-trash" style="color: #994d00"></span></a>
                               </td>     
                                <?php }?>  
                            </tr>
                          <?php }?>    
                     </tbody>    
                   </table>   
                  
                    
                      
               </div>
           </div>
           <div>
            <ul class="pagination" style="color: black">
							<?php for($j=1;$j<=$nbrPageEn;$j++){ ?>
				              <li class="<?php if($j==$pageEn) echo 'active' ?>">
								<a href="memoirePretEn.php?page=<?php echo $j ?>&titreM=<?php echo $titrem?>">
										 <?php echo $j ?>
									</a>
								</li>
							<?php } ?>	
						</ul>
          
          
            </div> </div>
    </div>    
    </body>
</html>    
<?php
    require_once("identifier.php");
	require_once("connectiDb.php");
    $idM=isset($_GET['idm'])?$_GET['idm']:0;
    $requeteM="select * from memoire where idmemoire= $idM";
    $resultatM=$pdo->query($requeteM);
    $memoire=$resultatM->fetch();

    $titre=$memoire['titre'];
    $etudiant=$memoire['etudiant'];
    $categorie=$memoire['categorie'];
    $edition=$memoire['edition'];
    $anneeEdition=$memoire['anneeEdition'];
    $nbrCopie=$memoire['nbrCopie'];
    $nomPhotos=$memoire['photos'];
    
    $description=$memoire['description'];
    $encadreur=$memoire['encadreur'];

?>


<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Editer mémoire</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
        
	</head>
	<body>
		<?php include("nouveau.php");?>
    <div class="container" id="padding">
			
        <div style="background-color:lightbrown"  class="panel panel-primary margetop" >
                
           <div class="panel-heading" id="color" style="color: black">Editer mémoire</div>
           <div class="panel-body">
                    
           <form method="post" action="updateMemoire.php" class="form" enctype="multipart/form-data"><!--enctype pour l'envoi d'un fichier-->
                        
                        
                <div class="form-group" >
                    <label for="idm">N° mémoire: <?php echo $idM ?></label>  
                    
                <input type="hidden" name="idm"  class="form-control" value="<?php echo $idM ?>"/>
                </div>   
                        
                        <div class="form-group" >
                    <label for="titre">Titre:</label>  
                    
                <input type="text" name="titre" 
                       plceholder="Titre"
                       class="form-control" 
                       value="<?php echo $titre ?>"/>
                </div>   
                        <!---->
            <div class="form-group" >
                <label for="etudiant">Etudiant:</label>  
                <input type="text" name="etudiant" 
                       plceholder="Etudiant"
                       class="form-control" 
                       value="<?php echo $etudiant ?>"/>
                </div>   
               <!---->
               
               <div class="form-group" >
                <label for="encadreur">Encadreur:</label>  
                <input type="text" name="encadreur" 
                       plceholder="Encadreur"
                       class="form-control" 
                       value="<?php echo $encadreur ?>"/>
               
               
               
                        <!---->
                <div class="form-group" >    
                        <label>Catégorie:</label>   
                        <select name="categorie" class="form-control" id="categorie"><!--this.from.submit() evenement de js-->
                 
                  <option value="master"<?php if($categorie==="master") echo "selected"?>>Master</option>
                  <option value="licence"<?php if($categorie==="licence") echo "selected"?>>Licence</option>
                  <option value="doctorat"<?php if($categorie==="doctorat") echo "selected"?>>Doctorat</option>
                    <option value="majister"<?php if($categorie==="majister") echo "selected"?>>Majister</option>        
                     </select>
                        </div>
                         <!---->
            <div class="form-group" >
                <label for="edition">Edition:</label>  
                <input type="edition" name="edition" 
                       plceholder="Edition"
                       class="form-control" 
                       value="<?php echo $edition ?>"/>
                </div>   
                        
                         <!---->
               
                        <div class="form-group" >
                <label for="anneeEdition">anneeEdition:</label>  
                <input type="number" min="1900" max="3000" 
                       name="anneeEdition" 
                       plceholder="anneeEdition"
                       class="form-control" 
                       value="<?php echo $anneeEdition ?>"/>
                </div> 
                        
                        <!---->
               
                        <div class="form-group" >
                <label for="nbrCopie">Nombre de copie:</label>  
                <input type="number"   min="0" max="100"
                       name="nbrCopie" 
                       plceholder="nombre de copie"
                       class="form-control" 
                       value="<?php echo $nbrCopie ?>"/>
                </div> 
                        
                        <!---->
               
               
                <div class="form-group" >
                    <label for="photos">Photo:</label>  
                    
                <input type="file" name="photos" /><!--file pour imoprter les photos-->
            </div> 
               
               
               
               
               <div class="form-group" >
                <label for="description">Description:</label>  
                <input type="description" name="description" 
                       plceholder="description"
                       class="form-control" 
                       value="<?php echo $description ?>"/>
                </div>    
                  <button type="submit" class="btn btn-warning" style="color: black">
                      <span class="glyphicon glyphicon-save" style="color: black"></span>
                        Enregistrer
                      
                  </button>
                     
                    </form>
                </div> 
                    
                </div>
        </div>
        
		
							
	</body>
</html>
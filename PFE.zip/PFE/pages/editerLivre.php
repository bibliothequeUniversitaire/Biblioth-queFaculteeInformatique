<?php
    require_once("identifier.php");
	require_once("connectiDb.php");
    $idL=isset($_GET['idl'])?$_GET['idl']:0;
    $requeteL="select * from livre where idLivre= $idL";
    $resultatL=$pdo->query($requeteL);
    $livre=$resultatL->fetch();

    $titre=$livre['titre'];
    $auteur=$livre['auteur'];
    
    $maisonEdition=$livre['maisonEdition'];
    $anneeEdition=$livre['anneeEdition'];
    $nbrCopie=$livre['nbrCopie'];
    $nomPhotos=$livre['photos'];
    
    $description=$livre['description'];
    $branche=$livre['branche'];

?>


<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Editer livre</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
        
	</head>
	<body>
		<?php include("nouveau.php");?>
    <div class="container" id="padding">
			
        <div style="background-color:lightbrown"  class="panel panel-primary margetop" >
                
           <div class="panel-heading" id="color" style="color: black">Editer livre</div>
           <div class="panel-body">
                    
           <form method="post" action="updateLivre.php" class="form" enctype="multipart/form-data"><!--enctype pour l'envoi d'un fichier-->
                        
                        
                <div class="form-group" >
                    <label for="idm">N° Livre: <?php echo $idL ?></label>  
                    
                <input type="hidden" name="idl"  class="form-control" value="<?php echo $idL ?>"/>
                </div>   
                        
                                <div class="form-group" >
                    <label for="titre">Titre:</label>  
                    
                <input type="text" name="titre" 
                       plceholder="Titre"
                       class="form-control" 
                       value="<?php echo $titre ?>"/>
                </div>   
                        <!---->
            <div class="form-group" >
                <label for="auteur">Auteur:</label>  
                <input type="text" name="auteur" 
                       plceholder="Auteur"
                       class="form-control" 
                       value="<?php echo $auteur ?>"/>
                </div> 
               <!---->
               
              <div class="form-group" >
                <label for="maisonEdition">Maison edition :</label>  
                <input type="maisonEdition" name="maisonEdition" 
                       plceholder="Maison edition"
                       class="form-control" 
                       value="<?php echo $maisonEdition ?>"/>
                </div> 
               
               <!---->
                 <div class="form-group" >
                <label for="anneeEdition">Annee edition:</label>  
                <input type="number"  min="1900" max="3000" 
                       name="anneeEdition" 
                       plceholder="anneeEdition"
                       class="form-control" 
                       value="<?php echo $anneeEdition ?>"/>
                </div>
               <!---->
                 <div class="form-group" >
                <label for="nbrCopie">Nombre de copie:</label>  
                <input type="number"   min="0" max="100" 
                       name="nbrCopie" 
                       plceholder="anneeEdition"
                       class="form-control" 
                       value="<?php echo $nbrCopie ?>"/>
                </div> 
                        <!---->
                <div class="form-group" >    
                        <label>Branche:</label>   
                        <select name="branche" class="form-control" id="branche"><!--this.from.submit() evenement de js-->
                  
                  <option value="base de donnee"<?php if($branche==="base de donnee") echo "selected"?>>Base de donnée</option>
                            
                  <option value="architecture"<?php if($branche==="architecture") echo "selected"?>>Architecture</option>
                            
                  <option value="algorithme"<?php if($branche==="algorithme") echo "selected"?>>Algorithme</option>
                            
                    <option value="compilation"<?php if($branche==="compilation") echo "selected"?>>Compilation</option>   
                            
                    <option value="langage de programmation"<?php if($branche==="langage de programmation") echo "selected"?>>Langage de programmation</option> 
                            
                    <option value="web"<?php if($branche==="web") echo "selected"?>>Web</option> 
                    
                     <option value="reseau"<?php if($branche==="reseau") echo "selected"?>>Réseau</option>         
                            
                     </select>
                        </div>
                         <!---->
            <div class="form-group" >
                    <label for="photos">Photo:</label>  
                    
                <input type="file" name="photos" /><!--file pour imoprter les photos-->
            </div> 
               
               
               
               
               <div class="form-group" >
                <label for="description">Description:</label>  
                <input type="description" name="description" 
                       plceholder="description"
                       class="form-control" 
                       value="<?php echo $description ?>"/>
                </div> 
                        
                        <!---->
               
                        
                        <!---->
               
               
               
               
               
               
                  
                  <button type="submit" class="btn btn-warning" style="color: black">
                      <span class="glyphicon glyphicon-save" style="color: black"></span>
                        Enregistrer
                      
                  </button>
                     
                    </form>
                </div> 
                    
                </div>
        </div>
        
		
							
	</body>
</html>
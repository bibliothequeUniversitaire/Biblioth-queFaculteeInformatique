<?php

   require_once("identifier.php");
 
	require_once("connectiDb.php");
    $idM=isset($_GET['idm'])?$_GET['idm']:0;
    $requete="select * from memoire where idmemoire= $idM";
    $resultat=$pdo->query($requete);
    $memoire=$resultat->fetch();
    
    $titre=$memoire['titre'];
    $nbr=$memoire['nbrCopie'];
    $etudiant=$memoire['etudiant'];
    $encadreur=$memoire['encadreur'];
    $annee=$memoire['anneeEdition'];
    $edition=$memoire['edition'];
    $photos=$memoire['photos'];
    $description=$memoire['description'];
    $categorie=$memoire['categorie'];
        
?>


<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Détail du mémoire</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		
        <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
	</head>
	<body>
        
	<?php include("nouveau.php");?>
    <div class="container">
			
        <div style="background-color:lightbrown"  class="panel panel-primary margetop" >
               
           <div class="panel-heading"  id="color" style="color: black">Détail du mémoire</div>
           <div class="panel-body">
                    
           <form method="post" action="memoire.php" class="form" enctype="multipart/form-data" ><!--enctype pour l'envoi d'un fichier-->
                
               
               <div class="form-group" >
                   <label for="idl"><font color="chocolate">N°Mémoire:</font> <?php echo $idM ?></label>  
                    <input type="hidden" name="idm"  class="form-control" value="<?php echo $idM ?>"/>
                </div>   
                        
                <div class="form-group" >
                    <label><font color="chocolate">Titre :</font> <?php echo $titre ?></label>  
                    <input type="hidden" name="titre" 
                       class="form-control" 
                       value="<?php echo $titre ?>"/>
                </div>   
                        <!---->
                <div class="form-group" >
                    <label><font color="chocolate">Etudiant: </font><?php echo $etudiant ?></label>  
                    <input type="hidden" name="auteur" 
                       class="form-control" 
                       value="<?php echo $etudiant ?>"/>
                </div>  
               
               <!---->
                <!---->
                <div class="form-group" >
                    <label><font color="chocolate">Encadreur: </font><?php echo $encadreur ?></label>  
                    <input type="hidden" name="auteur" 
                       class="form-control" 
                       value="<?php echo $encadreur ?>"/>
                </div>  
               
               <!---->
               <div class="form-group" >
                    <label><font color="chocolate">Catégorie : </font><?php echo $categorie?></label>  
                    <input type="hidden" name="categorie" 
                       class="form-control" 
                       value="<?php echo $categorie ?>"/>
                </div> 
               <!---->
               
               
          
                <div class="form-group" >
                    <label><font color="chocolate">Maison edition: </font><?php echo $edition ?></label>  
                    <input type="hidden" name="edition" 
                       class="form-control" 
                       value="<?php echo $edition ?>"/>
                </div> 
               

               
               
                        <!---->
              
               <div class="form-group" >
                    <label><font color="chocolate">Année edition: </font><?php echo $annee ?></label>  
                    <input type="hidden" name="maison" 
                       class="form-control" 
                       value="<?php echo $annee ?>"/>
                </div>
               <!---->
               
                 <div class="form-group" >
                    <label><font color="chocolate">Nombre de copie: </font><?php echo $nbr ?></label>  
                    <input type="hidden" name="nbr" 
                       class="form-control" 
                       value="<?php echo $nbr ?>"/>
                </div>
                    
               <!---->
                 <div class="form-group" >
                    <label><font color="chocolate">Description : </font><?php echo $description ?></label>  
                    <input type="hidden" name="nbr" 
                       class="form-control" 
                       value="<?php echo $description ?>"/>
                </div>                  
             <!---->
                  
                            <!---->     
              <img src="../images/<?php echo $photos?>" 
								class="center"				  width="236" height="304"
                
                   >   
               <!---->
                  <button type="submit" class="btn btn-warning" style="color: black" >
                      <span class="glyphicon glyphicon-share" style="color: black"></span>
                        Retour
                      
                  </button> 
             
                      
                    </form>
                    
                    
                    
                    
                </div> 
                    
                    
                </div>
        </div>
        
		
							
	</body>
</html>



<?php
   session_start();
  if(isset($_SESSION['user'])){//utilisateur connecter
	require_once("connectiDb.php");

	$iden=$_GET['iden'];

	$requete="delete from enseignant where idEnseignant=?";			
	$param=array($iden);	
	$resultatC = $pdo->prepare($requete);
    $resultatC ->execute($param);	
	header("location:enseignant.php");
      }else{//si l'utilisateur n'est pa authentifier
      header("location:login.php");
  }
	
?>

<meta charset="utf-8" />
    
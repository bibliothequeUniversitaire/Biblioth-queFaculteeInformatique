<?php
   session_start();
  if(isset($_SESSION['user'])){//utilisateur connecter
	require_once("connectiDb.php");
	
	
	$idlet=$_GET['idlet'];
	$idet=$_GET['idet'];
	$nbr=$_GET['nbr'];

	$requete="delete from penalite where idLivre=? and idEtudiant=?";			
	$param=array($idlet,$idet);	
	$resultatL = $pdo->prepare($requete);
    $resultatL ->execute($param);	
     $nbr=$nbr+1; 
      ////////////////////////////
      
      $requetenbr="update livre set nbrCopie='$nbr' where idLivre='$idlet';";    
   $paramm=array($nbr);

    $resultatnbr = $pdo->prepare($requetenbr);
    $resultatnbr->execute($paramm);
      
      
	header("location:penaliteEtl.php");
      }else{//si l'utilisateur n'est pa authentifier
      header("location:login.php");
  }
	
?>
    
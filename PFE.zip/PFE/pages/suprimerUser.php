
<?php
     session_start();
  if(isset($_SESSION['user'])){//utilisateur connecter
        
	require_once("connectiDb.php");
	

    $idUser=isset($_GET['idu'])?$_GET['idu']:0;

    
       $requete="delete from utilisateur where 	idUtilisateur=?";	
       $param=array($idUser);

       $resultat = $pdo->prepare($requete);

       $resultat->execute($param);
     header("location:utilisateurs.php"); 
  }else{//si l'utilisateur n'est pa authentifier
      header("location:login.php");
  }
 

?>
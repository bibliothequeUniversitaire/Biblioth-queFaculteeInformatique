
<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Initilisation du mot de passe</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/MonStyle.css">	
	</head>
	<body>		
		<div class="container col-md-6 col-md-offset-3">			
			<div class="panel panel-primary espace60 ">
				<div class="panel-heading">Initilisation du mot de passe</div>
				<div class="panel-body">
					<div class="card bg-success text-white">
						<div class="card-body">
							Un message contenant votre nouveau mot de passe<br>
							a été envoyé sur votre adresse Email.
						</div>
						
						<br><p><a href="login.php">Se Connecter</a>	</p>
					 </div>
							
	
				</div>
			</div>			
		</div>
		<script>
		
    </script>	
	</body>
</html>






<?php
    require_once("identifier.php");
	require_once("connectiDb.php");

    $idC=isset($_POST['idc'])?$_POST['idc']:0;
    $nom=isset($_POST['nom'])?$_POST['nom']:"";//les donées sont envoyée par la méthode post

    $titre=isset($_POST['titre'])?$_POST['titre']:"";//les donées sont envoyée par la méthode post
    $etudiant=isset($_POST['etudiant'])?$_POST['etudiant']:"";
    $categorie=isset($_POST['categorie'])?$_POST['categorie']:"";

    $edition=isset($_POST['edition'])?$_POST['edition']:"";
    $anneeEdition=isset($_POST['anneeEdition'])?$_POST['anneeEdition']:1;
    $nbrCopie=isset($_POST['nbrCopie'])?$_POST['nbrCopie']:1;
    $encadreur=isset($_POST['encadreur'])?$_POST['encadreur']:"";
    $description=isset($_POST['description'])?$_POST['description']:"";
    
 
 
    $requete="update  cd set 	titre=?,etudiant=?,categorie=?,edition=?,anneeEdition=?,nbrCopie=?,description=?,encadreur=? where idCd=? ";
    $param=array($titre,$etudiant,$categorie,$edition,$anneeEdition,$nbrCopie,$description,$encadreur,$idC);
    $resultat = $pdo->prepare($requete);
    $resultat->execute($param);	
	header("location:cd.php");
	
?>
<meta charset="utf-8" />
<?php
    require_once("identifier.php");
	require_once("connectiDb.php");
     
     $titrel=isset($_GET['titreL'])?$_GET['titreL']:"";
     $nomprenoml=isset($_GET['nomprenomL'])?$_GET['nomprenomL']:"";
     $auteurl=isset($_GET['auteurL'])?$_GET['auteurL']:"";
     
    

    $sizeEn=isset($_GET['size'])?$_GET['size']:2;
    $pageEn=isset($_GET['page'])?$_GET['page']:1;
    $offsetEn=($pageEn-1)*$sizeEn;
    
    
    
    
    $requeteEn="select  r.idLivre,e.idEnseignant,auteur,titre,idReservation,nom,prenom,dateRes,dateFinRes,nbrCopie
                 from livre as l,reserver as r,enseignant as e
                 where (l.idLivre=r.idLivre and r.idEnseignant=e.idEnseignant)
                 
                 and titre like '%$titrel%' 
                 and auteur like '%$auteurl%' 
                and (nom like '%$nomprenoml%' or prenom like '%$nomprenoml%')
                 limit $sizeEn 
                 offset $offsetEn";
    $requeteCountEn="select count(*) countEn from livre as l,reserver as r,enseignant as e
                 where (l.idLivre=r.idLivre and r.idEnseignant=e.idEnseignant)
                 and titre like '%$titrel%' 
                 and auteur like '%$auteurl%'
                  and (nom like '%$nomprenoml%' or prenom like '%$nomprenoml%')
                 ";
    
    $resultatEn=$pdo->query($requeteEn);
     $resultatCountEn=$pdo->query($requeteCountEn);
     $tabCountEn=$resultatCountEn->fetch();
     $nbrLivreEn=$tabCountEn['countEn'];
     $resteEn=$nbrLivreEn % $sizeEn; 
   
if($resteEn==0)
        $nbrPageEn=$nbrLivreEn/$sizeEn;
   else
		$nbrPageEn=floor($nbrLivreEn/$sizeEn)+1;
    
    
    
    
?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Gestion des prets</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

		
        
	</head>
    <body>
        <?php include("nouveau.php");?>
       <style>
         body {
             background-image: url('95571686_2695129650770008_1954315548242214912_n.jpg');
              }
       </style>    
		
      <div class="container ">    <!--container permet d'apliquer une marge gauche et droite-->
        <div class="panel panel-info margetop" id="padding">
          <div class="panel-heading" id="color" style="color: black">Recherche des Reserver</div>
           <div class="panel-body">
             <form method="get" action="livreReserverEn.php" class="form-inline" >
                <div class="form-group" >
                <input type="text" name="titreL" placeholder="Titre du livre" class="form-control" value="<?php echo $titrel?>"/>
                    &nbsp &nbsp
                    <input type="text" name="auteurL" placeholder=" Auteur " class="form-control" value="<?php echo $auteurl?>"/>
                    &nbsp &nbsp
                     <input type="text" name="nomprenomL" placeholder="Nom Prenom enseigant" class="form-control" value="<?php echo $nomprenoml?>"/>
                 </div> 
                 
                 
                 
                 &nbsp &nbsp
                    <button type="submit" class="btn btn-warning" style="color: black">
                      <span class="glyphicon glyphicon-search" style="color: black"></span>
                        Rechercher...
                  </button>
                    
                  
                </form>    
               
               </div>
           </div>
        
           
          <!-------------->
          &nbsp &nbsp
          &nbsp &nbsp
        <div class="container ">
            <div class="panel panel-info margetop">
               <div class="panel-heading" id="color" style="color: black">Liste des Reservation des enseignants(<?php echo $nbrLivreEn ?> Livres)</div>
               <div class="panel-body">
                  <table class="table table-striped table-bordered">
                     <thead>
                        <tr style="color: chocolate">
                           <th >N°livre</th><th >N°Réservation</th><th >Titre</th><th>Auteur</th>
                            <th>N°Lecteur</th><th>Nom enseignant</th>
                            <th>Prénom enseignant</th>
                            <th>Date Reservation</th><th>Date Fin Reservation</th>
                            <?php if($_SESSION['user']['role']=='ADMIN'){?> 
                            <th>Action</th>
                             <?php }?>  
                        </tr>
                     </thead>          
                     <tbody>
                        
                          <?php while($Livre=$resultatEn->fetch()){?>   
                            <tr class="<?php 
                                  if($_SESSION['user']['role']=='ADMIN'){      
                                  $dateR=$Livre['dateFinRes'];
                                  
                       $dateAuj= date("Y-m-d");
                       $dateA = date_create($dateAuj);                  
                       $dateR = date_create($dateR); 
                             $Auj= date_timestamp_get($dateA);
                             $d= date_timestamp_get($dateR);         
                                      
                                  
                                        if($Auj>=$d)
                                        echo 'danger' ; 
                                      
                                  }
                                      
                                      
                                        ?>">
                              <td ><?php echo $Livre['idLivre']?></td>
                              <td ><?php echo $Livre['idReservation']?></td>
                              <td ><?php echo $Livre['titre']?></td>
                              <td ><?php echo $Livre['auteur']?></td>
                              <td ><?php echo $Livre['idEnseignant'] ?></td>
                             <td ><?php echo $Livre['nom'] ?></td>
                             <td ><?php echo $Livre['prenom'] ?></td>
                              <td ><?php echo $Livre['dateRes']?></td>    
                              <td ><?php echo $Livre['dateFinRes']?></td>    
                            <?php if($_SESSION['user']['role']=='ADMIN'){?> 
                              <td >
                                  &nbsp &nbsp  
                                  <a onclick="return confirm('Etes vous sure de vouloire supprimer cette Reservation' )"
                                     href="supprimerReserverEnL.php?idlen=<?php echo $Livre['idLivre']?>
                                         &iden=<?php echo $Livre['idEnseignant']?>  
                                   &nbrEn=<?php echo $Livre['nbrCopie']?>    
                                     &idRess=<?php echo $Livre['idReservation']?>          
                                           
                                           "><span class="glyphicon glyphicon-trash" style="color: #994d00"></span></a>
                              </td>    
                                <?php }?>  
                            </tr>
                          <?php }?>    
                     </tbody>    
                   </table>   
                  
                    
                      
               </div>
           </div>
          
          
           <div>
           <ul class="pagination" >
							<?php for($j=1;$j<=$nbrPageEn;$j++){ ?>
				              <li class="<?php if($j==$pageEn) echo 'active' ?>">
								<a href="livreReserverEn.php?page=<?php echo $j ?>&titreL=<?php echo $titrel?>">
										 <?php echo $j ?>
									</a>
								</li>
							<?php } ?>	
						</ul>
          
          
          </div> 
          </div>
          <!----------->
    </div>    
    </body>
</html>    
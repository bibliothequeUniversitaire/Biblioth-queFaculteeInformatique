<?php
    require_once("identifier.php");
	require_once("connectiDb.php");
     
     $titrel=isset($_GET['titreL'])?$_GET['titreL']:"";

     $auteurMaisonEditionl=isset($_GET['auteurMaisonEditionL'])?$_GET['auteurMaisonEditionL']:"";
     $branche=isset($_GET['branche'])?$_GET['branche']:"all";
     $anneel=isset($_GET['anneeL'])?$_GET['anneeL']:"";

                           
                                                     

 $size=isset($_GET['size'])?$_GET['size']:6;
    $page=isset($_GET['page'])?$_GET['page']:1;
    $offset=($page-1)*$size;


if($branche=="all"){
     $requete="select * from livre
                   where (auteur like '%$auteurMaisonEditionl%' or maisonEdition like '%$auteurMaisonEditionl%')
                   and titre like '%$titrel%'
                   and anneeEdition like '%$anneel%'
                   
                   limit $size offset $offset";
     $requeteCount="select count(*) countL from livre 
             where (auteur like '%$auteurMaisonEditionl%' or maisonEdition like '%$auteurMaisonEditionl%')
                   and titre like '%$titrel%'
                   and anneeEdition like '%$anneel%'";
}else{
    
      $requete="select * from livre
                   where (auteur like '%$auteurMaisonEditionl%' or maisonEdition like '%$auteurMaisonEditionl%')
                   and titre like '%$titrel%'
                   and anneeEdition like '%$anneel%'
                   and branche like '%$branche%'
                   limit $size offset $offset";
    
     $requeteCount="select count(*) countL from livre 
              where (auteur like '%$auteurMaisonEditionl%' or maisonEdition like '%$auteurMaisonEditionl%')
                   and titre like '%$titrel%'
                   and anneeEdition like '%$anneel%'
                   and branche like '%$branche%'";
    
    
    
    
}

     $resultatL=$pdo->query($requete);//execution de la requete
     $resultatCount=$pdo->query($requeteCount);
     $tabCount=$resultatCount->fetch();
     $nbrLivre=$tabCount['countL'];
     $reste=$nbrLivre % $size; // % operateur modulo:le reste de la division euclidiene de $nbrFiliere par
                               //$size
   if($reste==0)//nbrFiliere est un multiple de size
        $nbrPage=$nbrLivre/$size;
   else
		$nbrPage=floor($nbrLivre/$size)+1;// floor retourne la partie entière d'un nombre 
										// decimale
	

      
?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Gestion des livres</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

		
        
	</head>
    <body>
       <style>
         body {
             background-image: url('95571686_2695129650770008_1954315548242214912_n.jpg');
              }
       </style>    
        
        
        
		<?php include("nouveau.php");?>
      <div class="container ">    <!--container permet d'apliquer une marge gauche et droite-->
        <div class="panel panel-info margetop" id="padding">
          <div class="panel-heading" id="color" style="color: black">Recherche des livres</div>
           <div class="panel-body">
             <form method="get" action="livre.php" class="form-inline" >
                <div class="form-group" >
                    &nbsp
                <input type="text" name="titreL" placeholder="Titre du livre" class="form-control" value="<?php echo $titrel?>"/>
                    &nbsp &nbsp
                    <input type="text" name="auteurMaisonEditionL" placeholder=" Auteur maison d'Edition" class="form-control" value="<?php echo $auteurMaisonEditionl?>"/>
                     
                 &nbsp &nbsp
                <input id="number" 
                       type="number"    min="1900" max="3000"  
                       name="anneeL" 
                       placeholder="AnneeEdition" 
                       class="form-control"
                       value="<?php echo $anneel?>"/>

                 &nbsp &nbsp
                 <label for="branche">Branche:</label>
                  &nbsp &nbsp
                <select name="branche" class="form-control" id="branche" onchange="this.form.submit()"><!--this.from.submit() evenement de js-->
                  <option value="all"<?php if($branche==="all") echo "selected"?>style="color: black">Tous les branches</option>
                    
        
                    <option value="base de donnee"<?php if($branche==="base de donnee") echo "selected"?> style="color: black" >Base de donnée</option>
                    
                    
                  <option value="architecture"<?php if($branche==="architecture") echo "selected"?> style="color: black" >Architecture</option>
                    
                    
                    
                  <option value="compilation"<?php if($branche==="compilation") echo "selected"?> style="color: black" >Compilation</option>
                    
                  
                  <option value="langage de programmation"<?php if($branche==="langage de programmation") echo "selected"?> style="color: black" >Langage de programmation</option>
                    
                
                   <option value="web"<?php if($branche==="web") echo "selected"?> style="color: black" >Web</option>
                    
                   <option value="reseau"<?php if($branche==="reseau") echo "selected"?> style="color: black" >Reseau</option>
                     </select>
                 
                 
                 </div> 
                 
                 
                    <button type="submit" class="btn btn-warning" style="color: black">
                      <span class="glyphicon glyphicon-search" style="color: black"></span>
                        Rechercher...
                  </button>
                    
                  <?php if($_SESSION['user']['role']=='ADMIN'){?>  
                    <a href="nouveauLivre.php" style="color: black"><span class="glyphicon glyphicon-plus" style="color: black"></span>
                      Nouveau livre</a>
                 <?php }?>
                </form>    
               
               </div>
           </div>
        
           <div class="panel panel-info margetop">
               <div class="panel-heading" id="color" style="color: black">Liste des livres (<?php echo $nbrLivre?> Livres)</div>
               <div class="panel-body">
                  <table class="table table-striped table-bordered">
                     <thead>
                        <tr style="color: chocolate">
                            <th>N°livre</th><th>Titre</th><th>Auteur</th><th>MaisonEdition</th><th>AnneeEdition</th>
                            <th>Copie</th><th>Photo</th><th>Détail</th>
                            <th>Pret </th><th>Reserver</th>
                            <?php if($_SESSION['user']['role']=='ADMIN'){?>
                            <th >Action</th>
                           <?php }?> 
                        </tr>
                     </thead>          
                     <tbody>
                        
                          <?php while($livre=$resultatL->fetch()){?>   
                            <tr style="color: black">
                              <td ><?php echo $livre['idLivre']?></td>
                              <td ><?php echo $livre['titre']?></td>
                              <td ><?php echo $livre['auteur']?></td>
                              <td ><?php echo $livre['maisonEdition']?></td>
                              <td ><?php echo $livre['anneeEdition']?></td>
                              <td ><?php echo $livre['nbrCopie']?></td>
                              <td >
								  <img src="../images/<?php echo $livre['photos']?>" 
												class="img-thumbnail"  width="50" height="40" >
							  </td>
                              
                            <td>
                             &nbsp &nbsp
                             <a href="detailLivre.php?idl=<?php echo $livre['idLivre']?>"><span class="glyphicon glyphicon-play" style="color: #994d00"></span></a></td>   
                                
                                
                                
                            
                                
                             <td>
                             
                             <a href="formulairePretLivre.php?idl=<?php echo $livre['idLivre']?>"><span class="glyphicon glyphicon-play" style="color: #994d00"></span></a></td> 
                                
                                <!----------------------------->
                            <td>
                                <a href="formulaireReserverLivre.php?idl=<?php echo $livre['idLivre']?>"><span class="glyphicon glyphicon-play" style="color: #994d00"></span></a>  
                            </td>
                                  &nbsp &nbsp
                             
                                
                            <?php if($_SESSION['user']['role']=='ADMIN'){?>   
                              <td >
                                <a href="editerLivre.php?idl=<?php echo $livre['idLivre']?>"><span class="glyphicon glyphicon-edit" style="color: #994d00"></span></a>
                                  &nbsp &nbsp
                                  <a onclick="return confirm('Etes vous sure de vouloire supprimer ce livre' )"
                                     href="supprimerLivre.php?idl=<?php echo $livre['idLivre']?>"><span class="glyphicon glyphicon-trash" style="color: #994d00"></span></a>  
                              </td>    
                                <?php }?> 
                                
                            </tr>
                          <?php }?>    
                        
                      
                     </tbody>    
                   </table>   
                   <div>
                   
                     <ul class="pagination" style="color: black">
							
							<?php for($i=1;$i<=$nbrPage;$i++){ ?>
				              <li class="<?php if($i==$page) echo 'active' ?>">

								<a href="livre.php?page=<?php echo $i ?>&titreL=<?php echo $titrel?>">

										
										 <?php echo $i ?>
									</a>
								</li>
							<?php } ?>	
						</ul>
                   
                   
                   </div>    
               </div>
           </div>
    </div>    
    </body>
</html>    
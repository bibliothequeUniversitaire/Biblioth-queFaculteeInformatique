<?php

require_once("identifier.php");
?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Nouveau livre</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
	</head>
	<body>
		<?php include("nouveau.php");?>
        <style>
         body {
             background-image: url('95571686_2695129650770008_1954315548242214912_n.jpg');
              }
       </style>
     <div class="container">
			
            <div class="panel panel-info margetop" style="color: black">
				<div class="panel-heading" id="color" style="color: black">Veuillez saisir les données du nouveau livre</div>
				<div class="panel-body">
                    <form method="post" action="insertLivre.php" class="form"      enctype="multipart/form-data" >
                        <!--post pour envoyer--> 
                       <div class="form-group" >
                           <label>Titre du livre:</label>   
                           <input type="text" name="titre" placeholder="Titre du livre"            class="form-control" />
                       </div>    
                        
                        <div class="form-group" >
                            <label>Auteur:</label>   
                            <input type="text" name="auteur" placeholder="Auteur"            class="form-control" />
                       </div>
                        
                        
                       
                        
                        
                        
                         <div class="form-group" >
                            <label >MaisonEdition:</label>   
                            <input type="text" name="maisonedition" placeholder="Edition"   class="form-control" />
                       </div>
                        
                         <div class="form-group" >
                            <label >AnneeEdition:</label>   
                            <input type="number" 
                            min="1900" max="3000" 
                                   name="anneeEdition" placeholder="AnneeEdition"            class="form-control" />
                       </div>
                        
                        <div class="form-group" >
                            <label >Nombre de copie:</label>   
                            <input type="number" 
                                   min="0" max="100" 
                            name="nbrCopie" placeholder="Nombre de copie"            class="form-control" />
                       </div>
                        
                       
           <div class="form-group" >
                       <label for="branche">Branche:</label>
                       <select name="branche" class="form-control" id="branche"><!--this.from.submit() evenement de js-->
                       
                       <option value="base de donnee" selected>Base de donnee</option>
                       <option value="architecture">Architecture</option>
                      <option value="compilation">Compilation</option>
                      <option value="langage de programmation">Langage de programmation</option>
                           <option value="web">web</option>
                           
                           <option value="reseau">Reseau</option>
                           
                           
                      </select>
                        </div>
                        
                        
                        
                         <div class="form-group" >
                             <label for="photos">Photo:</label>  
                             <input type="file" name="photos" /><!--file pour imoprter les photos-->
                         </div> 
                        
                        <div class="form-group" >
                            <label>Description:</label>   
                            <input type="text" name="description" placeholder="Description"            class="form-control" />
                       </div>
                        
                        
                        
                        
                        
                        
                     <button type="submit" class="btn btn-warning" style="color: black">
                      <span class="glyphicon  glyphicon-save" style="color: black"></span>
                        Enregistrer
                     </button>
                   
                </form> 
                    
                    
                    
                    
                    
                </div>
        </div>
        
        </div>
							
	</body>
</html>


<?php
    require_once("identifier.php");
	require_once("connectiDb.php");

    $idL=isset($_POST['idl'])?$_POST['idl']:0;
    $nom=isset($_POST['nom'])?$_POST['nom']:"";//les donées sont envoyée par la méthode post

    $titre=isset($_POST['titre'])?$_POST['titre']:"";//les donées sont envoyée par la méthode post
    $auteur=isset($_POST['auteur'])?$_POST['auteur']:"";



    $maisonEdition=isset($_POST['maisonEdition'])?$_POST['maisonEdition']:"";
    $anneeEdition=isset($_POST['anneeEdition'])?$_POST['anneeEdition']:1;
    $nbrCopie=isset($_POST['nbrCopie'])?$_POST['nbrCopie']:1;
    
    
    
    $nomPhotos=isset($_FILES['photos']['name'])?$_FILES['photos']['name']:"";//Récuperer le Nom de la photo envoyée
    $imageTemp=$_FILES['photos']['tmp_name'];
    move_uploaded_file($imageTemp,"../images/".$nomPhotos);

    $description=isset($_POST['description'])?$_POST['description']:"";
    $branche=isset($_POST['branche'])?$_POST['branche']:"";
        
 if(!empty($nomPhotos)){  //empty envoie vrai ssi  $nomPhoto est vide
    $requete="update   livre set 	titre=?,auteur=?,maisonEdition=?,anneeEdition=?,nbrCopie=?,photos=?,description=?,branche=? where idLivre=? ";
    $param=array($titre,$auteur,$maisonEdition,$anneeEdition,$nbrCopie,$nomPhotos,$description,$branche,$idL);
        
 }else{
    $requete="update   livre set 	titre=?,auteur=?,maisonEdition=?,anneeEdition=?,nbrCopie=?,description=?,branche=? where idLivre=? ";
    $param=array($titre,$auteur,$maisonEdition,$anneeEdition,$nbrCopie,$description,$branche,$idL);
    }
    $resultat = $pdo->prepare($requete);
    $resultat->execute($param);	
	header("location:livre.php");
	
?>
<meta charset="utf-8" />
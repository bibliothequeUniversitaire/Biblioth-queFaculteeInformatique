
<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Page blanche</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
	</head>
	<body>
		<?php include("nouveau.php");?>
     <div class="container">
			<div class="panel panel-success margetop">
				<div class="panel-heading">Rechercher des ouvrages...</div>
				<div class="panel-body">
					le contenu du paneau
                </div>
            </div>
            <div class="panel panel-primary ">
				<div class="panel-heading">Liste des ouvrages  </div>
				<div class="panel-body">
                    le tableau des ouvrages
                </div>
        </div>
        
        </div>
							
	</body>
</html>
<?php 
  session_start();
  if(!isset($_SESSION['user']))//utilisateur non connecter
         header('location:login.php');
	require_once("connectiDb.php");


?>
<meta charset="utf-8" />
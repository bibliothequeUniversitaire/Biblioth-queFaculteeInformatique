<?php
   require_once("identifier.php");
	require_once("connectiDb.php");
    $idEn=isset($_GET['iden'])?$_GET['iden']:0;
    $requeteEn="select * from enseignant where idEnseignant= $idEn";
    $resultatEn=$pdo->query($requeteEn);
    $enseignant=$resultatEn->fetch();

    $nom=$enseignant['nom'];
    $prenom=$enseignant['prenom'];
    $numCarte=$enseignant['numCarte'];
    $cevilite=$enseignant['cevilite'];
  


    


?>


<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Edition des livres</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
        
	</head>
	<body>
		<?php include("nouveau.php");?>
    <div class="container">
			
        <div style="background-color:lightbrown"  class="panel panel-primary margetop" >
                
           <div class="panel-heading"  id="color" style="color: black">Editer enseignant</div>
           <div class="panel-body">
                    
           <form method="post" action="updateEnseignant.php" class="form" enctype="multipart/form-data"><!--enctype pour l'envoi d'un fichier-->
                        
                        
                <div class="form-group" >
                    <label for="iden">N° enseignant: <?php echo $idEn ?></label>  
                    
                <input type="hidden" name="iden"  class="form-control" value="<?php echo $idEn ?>"/>
                </div>   
                        
                        <div class="form-group" >
                    <label for="nom">Nom:</label>  
                    
                <input type="text" name="nom" 
                       plceholder="Nom"
                       class="form-control" 
                       value="<?php echo $nom?>"/>
                </div>   
                        <!---->
            <div class="form-group" >
                <label for="prenom">Prenom:</label>  
                <input type="text" name="prenom" 
                       plceholder="Prenom"
                       class="form-control" 
                       value="<?php echo $prenom ?>"/>
                </div>   
                        <!---->
                
                         <!---->
            <div class="form-group" >
                <label for="numCarte">N°carte:</label>  
                <input type="numCarte" name="numCarte" 
                       plceholder="N°carte"
                       class="form-control" 
                       value="<?php echo $numCarte ?>"/>
                </div>   
                        
                         <!---->
               
                     
               
               
               
               
               
               <div class="form-group" >
                <label for="cevilite">Cevilite:</label>  
                <div class="radio">
                   <label><input type="radio" name="cevilite"  value="F"
                                 <?php if($cevilite==="F")echo "checked"?>/>F</label><br>
                   <label><input type="radio" name="cevilite"  value="M"
                                 <?php if($cevilite==="M")echo "checked"?>/>M</label>            
                </div>   
            </div>
               
               
               
               <!---->
               
                        
                        
                        
                  <button type="submit" class="btn btn-warning" style="color: black">
                      <span class="glyphicon glyphicon-save" style="color: black"></span>
                        Enregistrer
                      
                  </button>
                     
                    </form>
                    
                    
                    
                    
                </div> 
                    
                    
                </div>
        </div>
        
		
							
	</body>
</html>
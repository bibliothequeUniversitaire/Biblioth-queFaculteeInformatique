<?php
   session_start();
  if(isset($_SESSION['user'])){//utilisateur connecter
	require_once("connectiDb.php");
	
	
	$idlet=$_GET['idlet'];
	$idet=$_GET['idet'];
	$nbr=$_GET['nbr'];
	$idEmpr=$_GET['idEmpr'];

	$requete="delete from emprunt where idLivre=?  and idEmrunt=?";			
	$param=array($idlet,$idEmpr);	
	$resultatL = $pdo->prepare($requete);
    $resultatL ->execute($param);	
     $nbr=$nbr+1; 
      ////////////////////////////
      
      $requetenbr="update livre set nbrCopie='$nbr' where idLivre='$idlet';";    
   $paramm=array($nbr);

    $resultatnbr = $pdo->prepare($requetenbr);
    $resultatnbr->execute($paramm);
      
      
	header("location:livrePretEt.php");
      }else{//si l'utilisateur n'est pa authentifier
      header("location:login.php");
  }
	
?>
    
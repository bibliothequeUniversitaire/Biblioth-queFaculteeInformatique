<?php

require_once("identifier.php");
?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Nouveau Mémoire</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
	</head>
	<body>
		<?php include("nouveau.php");?>
        <style>
         body {
             background-image: url('95571686_2695129650770008_1954315548242214912_n.jpg');
              }
       </style>
     <div class="container">
			
            <div class="panel panel-info margetop" >
				<div class="panel-heading" id="color" style="color: black">Veuillez saisir les données du nouveau memoire</div>
				<div class="panel-body">
                    <form method="post" action="insertMemoire.php" class="form"      enctype="multipart/form-data" >
                        <!--post pour envoyer--> 
                       <div class="form-group" >
                           <label for="categorie">Titre du mémoire:</label>   
                           <input type="text" name="titre" placeholder="Titre du mémoire"            class="form-control" />
                       </div>    
                        
                        <div class="form-group" >
                            <label for="categorie">Etudiant:</label>   
                            <input type="text" name="etudiant" placeholder="Etudiant"            class="form-control" />
                       </div>
                        
                        
                        
                        <div class="form-group" >
                            <label for="categorie">Encadreur:</label>   
                            <input type="text" name="encadreur" placeholder="Encadreur"   class="form-control" />
                       </div>
                        
                        
                        <div class="form-group" >
                       <label for="categorie">Catégorie:</label>
                       <select name="categorie" class="form-control" id="categorie"><!--this.from.submit() evenement de js-->
                       <option value="master" selected>master</option>
                       <option value="licence">Licence</option>
                      <option value="doctorat">Doctorat</option>
                      <option value="majister">Majister</option>
                      </select>
                        </div>
                        
                        
                        
                        
                         <div class="form-group" >
                            <label for="categorie">Edition:</label>   
                            <input type="text" name="edition" placeholder="Edition"            class="form-control" />
                       </div>
                        
                        
                        
                         <div class="form-group" >
                            <label for="categorie">AnneeEdition:</label>   
                            <input type="number"  min="1900" max="3000" 
                                   name="anneeEdition" placeholder="AnneeEdition"            class="form-control" />
                       </div>
                        
                        <div class="form-group" >
                            <label for="categorie">Nombre de copie:</label>   
                            <input type="number" 
                                   min="0" max="100"
                                   name="nbrCopie" placeholder="Nombre de copie"   class="form-control" />
                       </div>
                        
                        
                         <div class="form-group" >
                             <label for="photos">Photo:</label>  
                             <input type="file" name="photos" /><!--file pour imoprter les photos-->
                         </div> 
                        
                        <div class="form-group" >
                            <label for="categorie">Description:</label>   
                            <input type="text" name="description" placeholder="Description"            class="form-control" />
                       </div>
                        
                        
                        
                        
                     <button type="submit" class="btn btn-warning" style="color: black">
                      <span class="glyphicon  glyphicon-save" style="color: black"></span>
                        Enregistrer
                     </button>
                   
                </form> 
                    
                    
                </div>
        </div>
        
        </div>
							
	</body>
</html>
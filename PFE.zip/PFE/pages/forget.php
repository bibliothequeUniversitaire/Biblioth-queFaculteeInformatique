<?php
require "PHPMailer/PHPMailerAutoload.php";
$bdd = new PDO('mysql:host=localhost;dbname=jdida;charset=utf8;', 'root', '');
if(isset($_POST['valider_email'])){
  $email = $_POST['email'];
  $requete_sur_email = $bdd->prepare('select * from users where email = ?');
  $requete_sur_email->execute(array($email));
  if($requete_sur_email->rowCount() > 0){
	$info_user = $requete_sur_email->fetch();
	  $mdp_user = $info_user['mdp'];
	
	  
	  




	function smtpmailer($to, $from, $from_name, $subject, $body)

    {

        $mail = new PHPMailer();

        $mail->IsSMTP();

        $mail->SMTPAuth = true; 

 

        $mail->SMTPSecure = 'ssl'; 

        $mail->Host = 'smtp.gmail.com';

        $mail->Port = 465;  

        

        $mail->Username = 'sehilfatimazohra19@gmail.com'; 

        $mail->Password = 'malakmalak<>{}[]1999';  

        

   

        $mail->IsHTML(true);

        

        $mail->From="sehilfatimazohra19@gmail.com";

        $mail->FromName=$from_name;

        $mail->Sender=$from;

        $mail->AddReplyTo($from, $from_name);

        $mail->Subject = $subject;

        $mail->Body = $body;

        $mail->AddAddress($to);

        if(!$mail->Send())

        {

            $error ="Une erreur s'est produite lors de l'envoie du mail !";

            return $error; 

        }

        else 

        {

            $error = "Email envoyé avec succès !";  

            return $error;

        }

    }

    

    

    $to   = $info_user['email'];

    

    $from = 'sehilfatimazohra19@gmail.com';

    

    $name = 'Admin de site';

    

    $subj = 'Récupération de votre compte sur notre site';

    

    $msg = 'Bonjour voici votre mot de passe sur le site :'.$mdp_user;

    

    $error=smtpmailer($to, $from, $name ,$subj, $msg);

	  
	  
	  
  }else{
	  echo "l'email est invalide(n'existe pas dans le site)";
  }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>passe word oublié</title>	
<meta charset="utf-8">
</head>
	
<body>
 <div align="center">
	<form method="post" action="">
	  <input type="email" name="email">
	  <br/>
	  <input type="submit" name="valider_email" >
	</form>
	 <?php
	 if(isset($error)){
	  echo $error;
	 }
	 
	 ?>
	 <?= error; ?>
 </div>	
</body>
</html>
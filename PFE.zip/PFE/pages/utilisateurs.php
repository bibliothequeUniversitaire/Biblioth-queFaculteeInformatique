<?php
require_once("identifier.php");
	require_once("connectiDb.php");
    
 /* if(isset($_GET['nomL']))
    $nomL=$_GET['nomL'];
  else 
      $nomL=""; */
    
    $login=isset($_GET['login'])?$_GET['login']:"";
    

    $size=isset($_GET['size'])?$_GET['size']:4;
    $page=isset($_GET['page'])?$_GET['page']:1;
    $offset=($page-1)*$size;

    
   

       $requeteUser="select * from utilisateur where login like '%$login%'
       ";
      
       $requeteCount="select count(*) countUser from utilisateur ";
      
 
    $resultatUser=$pdo->query($requeteUser);
    
    $resultatCount=$pdo->query($requeteCount);
    $tabCount=$resultatCount->fetch();
    $nbrUser=$tabCount['countUser'];

   $reste=$nbrUser % $size; 
                               
   if($reste===0)
        $nbrPage=$nbrUser/$size;
   else
		$nbrPage=floor($nbrUser/$size)+1;
										
	

?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Gestion des utilisateurs</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
        
	</head>
    
	<body>
        <style>
              body {
              background-image: url('95571686_2695129650770008_1954315548242214912_n.jpg');
              }
</style>
        
		<?php include("nouveau.php");?>
			
		<div class="container ">
          <div class="panel panel-warning margetop">
            <div class="panel-heading " id="color" style="color: black">Rechercher des utilisateurs</div>
            <div class="panel-body">
                     
              <form method="get" action="utilisateurs.php" class="form-inline" >
                <div class="form-group" >
                     &nbsp &nbsp  &nbsp &nbsp  &nbsp &nbsp  &nbsp &nbsp
                <input type="text" name="login" placeholder="login" 
                       class="form-control"
                       value="<?php echo $login ?>"/>
                    
                </div>   
                       
                  
                  
                   &nbsp &nbsp  &nbsp &nbsp  &nbsp &nbsp
                  <button type="submit" class="btn btn-warning" style="color: black">
                      
                      <span class="glyphicon glyphicon-search" style="color: black"></span>
                      
                        Rechercher...
                  </button>
                    
                 
                    </form>
                </div>
            </div>
            <div class="panel panel-primary ">
				<div class="panel-heading " id="color" style="color: black">Liste des utilisateurs(<?php echo $nbrUser?> Utilisateurs) </div>
				<div class="panel-body">
                    <table class="table table-striped">
                      <thead>
                           
                        <tr style="color: chocolate">
                           <th>Login</th><th>Email</th><th>Role</th><th>Action</th>
                          
                        </tr>
                      </thead>
                      <tbody>
                 <?php while($user=$resultatUser->fetch()){ ?>
                     <tr class="<?php echo $user['etat']==1?'success':'danger'?>">  
                          <td><?php echo $user['login']?></td>
                          <td><?php echo $user['email']?></td>
                          <td><?php echo $user['role']?></td>
                          
                        <td>
                            
                            <a href="adminEdit.php?id=<?php echo $user['idUtilisateur']?>">
                               <span class="glyphicon glyphicon-edit" style="color: #994d00"></span>
                            </a>   
                                 &nbsp;&nbsp;
                            <a  onclick="return confirm('Ete vous sure de vouloire supprimer cet utilisateur ' )"
                               href="suprimerUser.php?idu=<?php echo $user['idUtilisateur']?>">
                               <span class="glyphicon glyphicon-trash" style="color: #994d00"></span>
                                &nbsp;&nbsp;
                            </a>  
                            <a href="activerUser.php?idu=<?php echo $user['idUtilisateur']?>&etat=<?php echo $user['etat']?>">
                               <?php 
                            
                                   if($user['etat']==1)
                                      echo '<span class="glyphicon glyphicon-remove" style="color: #994d00"></span>';
                                   else{
                                      echo '<span class="glyphicon glyphicon-ok" style="color: #994d00"></span>';
                                 }                               
                            
                                ?>
                            </a>
                            
                        </td>
                          
                     </tr> 
                 <?php } ?>
                       
                      </tbody>
                    </table>
                    <div>
                        <!--pagination-->
						<ul class="pagination">
							
							<?php for($i=1;$i<=$nbrPage;$i++){ ?>
				              <li class="<?php if($i==$page) echo 'active' ?>">

								<a href="utilisateurs.php?page=<?php echo $i ?>&login=<?php echo $login?>">

										<!--recherche par login-->
										 <?php echo $i ?>
									</a>
								</li>
							<?php } ?>	
						</ul>
					</div>

                   
                </div>
            </div>
        </div>			
	</body>
</html>


<!DOCTYPE html>
<html lang="en">
<head>
<title>Page Title</title>
       <meta charset="UTF-8">
	
	<link rel="stylesheet" type="text/css" href="../css/footer.css">
       <meta name="viewport" content="width=device-width, initial-scale=1">
       <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
       <link rel="stylesheet" href="https://getbootstrap.com/docs/3.3/components/#glyphicons-glyphs">
       <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
       <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
	
	
       
	
     
<style>
* {
  box-sizing: border-box;
}

/* Style the body */
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

/* Header/logo Title */
.header {
  padding: 80px;
  text-align: center;
  background: #000000;
  color: white;
}

/* Increase the font size of the heading */
.header h1 {
  font-size: 40px;
}

/* Sticky navbar - toggles between relative and fixed, depending on the scroll position. It is positioned relative until a given offset position is met in the viewport - then it "sticks" in place (like position:fixed). The sticky value is not supported in IE or Edge 15 and earlier versions. However, for these versions the navbar will inherit default position */
.navbar {
  overflow: hidden;
  background-color:  #000000;
  position: sticky;
  position: -webkit-sticky;
  top: 0;
}

/* Style the navigation bar links */
.navbar a {
  float: left;
  display: block;
  color: white;
  text-align: center;
  padding: 5px 15px;
  text-decoration: none;
}


/* Right-aligned link */
.navbar a.right {
  float: right;
}

/* Change color on hover */
.navbar a:hover {
  background-color: #ddd;
  color: black;
}

/* Active/current link */
.navbar a.active {
  background-color: #666;
  color: white;
}

/* Column container */
.row {  
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
}

/* Create two unequal columns that sits next to each other */
/* Sidebar/left column */
.side {
  -ms-flex: 50%; /* IE10 */
  flex: 30%;
  background-color :salmon; /* colomn gouche*/
	
 /
	
  padding: 20px;
}

/* Main column */
.main {   
  -ms-flex: 70%; /* IE10 */
  flex: 70%;
  background-color: white;
  padding: 20px;
}

/* Fake image, just for this example */
.fakeimg {
  /*background-color:darkred;*/
  width: 100%;
  padding: 20px;
}

/* Footer */
.footer {
  padding: 1px;
  text-align: center;
  background: #ddd;
}

/* Responsive layout - when the screen is less than 700px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 500px) {
  .row {   
    flex-direction: column;
  }
}

/* Responsive layout - when the screen is less than 400px wide, make the navigation links stack on top of each other instead of next to each other */
@media screen and (max-width: 400px) {
  .navbar a {
    float: none;
    width: 100%;
  }
}
    
    /*--------------------------------------------------------------*/
   * {
  box-sizing: border-box;
}

body {
  font-family: Arial;
  font-size: 17px;
}

.container {
  position: relative;
  max-width: 1500px;
  margin: 0 auto;
}

.container img {vertical-align: middle;}

.container .content {
  position: absolute;
  bottom: 0;
  background: rgb(0, 0, 0); /* Fallback color */
  background: rgba(0, 0, 0, 0.5); /* Black background with 0.5 opacity */
  color: #f1f1f1;
  width: 100%;
  padding: 20px;
}
    .center {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 50%;
}
/*------------------------------------debut-footer---------------------------------------*/
body,h1,h2,h3,h4,h5,h6 {font-family: "Lato", sans-serif;}
body, html {
  height: 10%;
  color: #000;
  line-height: 1.8;
}

/* Create a Parallax Effect */
.bgimg-1, .bgimg-2, .bgimg-3 {
  background-attachment: fixed;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}


.w3-wide {letter-spacing: 2px;}
.w3-hover-opacity {cursor: pointer;}

/* Turn off parallax scrolling for tablets and phones */
@media only screen and (max-device-width: 50px) {
  .bgimg-1, .bgimg-2, .bgimg-3 {
    background-attachment: scroll;
    min-height: 50px;
  }
}
/*------------------------------------fin--footer---------------------------------------*/
/*-----------------------------------debut-affiche-perdu---------------------------------*/
body,h1,h5 {font-family: "Raleway", sans-serif}
body, html {height: 100%}
.bgimg {
  background-image: url('');
  min-height: 100%;
  background-position: center;
  background-size: cover;
}
/*----------------------------------fin-affiche-perdu------------------------------------*/
        
</style>
</head>
<body>

 <div class="container">
 <section>    
   <img src="29064419_127470191426428_174595890764664072_o.jpg" alt="Notebook" style="height: 400px; width: 100%;" class="mySlides">
        
   <img src="téléchargement (1).jpg" alt="Notebook" style="height: 400px; width: 100%;" class="mySlides"> 
		
   <img src="photo.jpg" alt="Notebook" style="height: 400px; width:100%;" class="mySlides">
	 
   <img src="msa_bu-lettres-2-720x587.jpg" alt="Notebook" style="height: 400px; width:100%;" class="mySlides">
 </section>
        
 <!----------------------------------debut_slider-------------------------------------->      
 <script>

var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}
    x[myIndex-1].style.display = "block";
    setTimeout(carousel, 3000);
}
</script>
<!------------------------------------fin_slider------------------------------------------> 
	 <script type="text/javascript">
        (function () {
            var options = {
                whatsapp: "+213675537803", // WhatsApp number  (comme Admin)
                call_to_action: "Message us", // Call to action
                position: "right", // Position may be 'right' or 'left'

            };
            var proto = document.location.protocol, Host = "whatshelp.io", url = proto + "//static." + Host;
            var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
            s.onload = function () { WhWidgetSendButton.init(Host, proto, options); };
            var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
        })();
    </script> 
<!------------------------------debut_whatsapp-------------------------------------------->
	                       <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5ebc80c28ee2956d73a0e852/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
                             <!--End of Tawk.to Script-->
<!-----------------------------------fin_whatsapp----------------------------------------->
<!-----------------------------------script like----------------------------------------->
	 <script>
function likeFunction(x) {
  x.style.fontWeight = "bold";
  x.innerHTML = "✓ Liked";
}
</script>
<!-----------------------------------fin_script-like-------------------------------------->

     <div class="content">
       <h1>Bibliothèque</h1>
       <p>Université Djilali Liabes de Sidi Bel Abbes.</p>
       <p> Département Informatique SBA.</p>
     </div>
</div> 
        
    
    
    
<div class="navbar">
  <a ><img src="udl.jpg" style="height: 60px; width:60px;"
  ></a>
    <div class="bgimg w3-display-container w3-text-white">
 
  <a href="vers.php"><h3>Home</h3></a>
  <a ><h3><button onclick="document.getElementById('menu').style.display='block'" class="w3-button ">Service</button></h3></a>
  <a ><h3><button onclick="document.getElementById('contact').style.display='block'" class="w3-button ">contact</button></h3></a>
    <a ><h3><button onclick="document.getElementById('description').style.display='block'" class="w3-button  w3-text-white">Description</button></h3></a>
    
  <a href="login.php" class="right"><h3>Connecter</h3></a>
        </div>
    
</div> 

<div class="row">
  <div class="side">
  <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bienvenu !!!</h2>
    <div class="fakeimg" style="height:150px;" ><img src="images (1).jpeg"></div><br>
	  
                     <!---->
      <br>
      &nbsp &nbsp &nbsp &nbsp &nbsp
      <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Catalogue des ouvrages :</h2>
     
      <br>
   <div > <section>    
  <img src="../images/20200301_131500.jpg"  style="height: 500px; 
  width: 400px; display: block;
  margin-left: auto;
  margin-right: auto;
  width: 60%;" class="Slides" >
        
      <img src="../images/20200301_131538.jpg" style="height: 500px; 
  width: 400px; display: block;
  margin-left: auto;
  margin-right: auto;
  width: 60%;" class="Slides" > 
        <img src="../images/20200301_131558.jpg" a style="height: 500px; 
  width: 400px; display: block;
  margin-left: auto;
  margin-right: auto;
  width: 60%;" class="Slides" >
       
       <img src="../images/20200301_101930 (2).jpg" a style="height: 500px; 
  width: 400px; display: block;
  margin-left: auto;
  margin-right: auto;
  width: 60%;" class="Slides" >
       
       <img src="../images/20200301_101924.jpg" a style="height: 500px; 
  width: 400px; display: block;
  margin-left: auto;
  margin-right: auto;
  width: 60%;" class="Slides" >
       
       <img src="../images/20200301_101918.jpg" a style="height: 500px; 
  width: 400px; display: block;
  margin-left: auto;
  margin-right: auto;
  width: 60%;" class="Slides" >
       
        <img src="../images/20200301_131726.jpg" a style="height: 500px; 
  width: 400px;display: block;
  margin-left: auto;
  margin-right: auto;
  width: 60%;" class="Slides" >
        <img src="../images/20200301_131834.jpg" a style="height: 500px; 
  width: 400px; display: block;
  margin-left: auto;
  margin-right: auto;
  width: 60%;" class="Slides" >
        <img src="../images/20200301_131856.jpg" a style="height: 500px; 
  width: 400px; display: block;
  margin-left: auto;
  margin-right: auto;
  width: 60%;" class="Slides" >
        <img src="../images/20200301_132103.jpg" a style="height: 500px; 
  width: 400px; display: block;
  margin-left: auto;
  margin-right: auto;
  width: 60%;" class="Slides" >
        </section></div>
      <!---->
      
      
      
      
      
	  
	 
<!-- Menu Modal -->
<div id="menu" class="w3-modal">
  <div class="w3-modal-content w3-animate-zoom">
    <div class="w3-container w3-black w3-display-container">
      <span onclick="document.getElementById('menu').style.display='none'" class="w3-button w3-display-topright w3-large"><span class="glyphicon glyphicon-remove"></span></span>
      <h1>Notre Service</h1>
    </div>
    <div class="w3-container w3-red">
      <h5>Inscription.</h5>
      <h5>Prêt d'un ouvrage.</h5>
      <h5>Réserver un ouvrage.</h5>
      <h5>Voir les détails d'un ouvrage.</h5>
      <h5>Voir les lecteurs.</h5>
    </div>
  </div>
</div>
&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
<!-- Contact Modal -->
<div id="contact" class="w3-modal">
  <div class="w3-modal-content w3-animate-zoom">
    <div class="w3-container w3-black">
      <span onclick="document.getElementById('contact').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
      <h1>CONTACT US</h1>
    </div>
   
     <div class="w3-container w3-green">
      <h5><address><i class="fa fa-phone">&nbsp;&nbsp;</i>
            <span>Phone: <a href="tel:5555555555">(555) 555-8899</a></span>
          </address></h5>
      <h5><i class="fa fa-user">&nbsp;&nbsp;</i>Responsable: Mr.xxxxx </h5>
      <h5><i class="fa fa-envelope">&nbsp;&nbsp;</i>E-mail : Bibliothèque-Dépa-info-SBA@gmail.com</h5>
      <h5><i class="fa fa-whatsapp">&nbsp;&nbsp;</i>whatsapp : 06 xx xx xxxx</h5>
      <h5><i class="fa fa-facebook">&nbsp;&nbsp;</i>page Facebook : Bibliothèque Département Info_SBA</h5>
    </div>
    
  </div>
</div> 
	  <!-- localisation Modal -->
<div id="description" class="w3-modal">
  <div class="w3-modal-content w3-animate-zoom">
    <div class="w3-container w3-black">
      <span onclick="document.getElementById('description').style.display='none'" class="w3-button w3-display-topright w3-large">x</span>
      <h1>DESCRIPTION</h1>
    </div>
   
     <div class="w3-container w3-yellow w3-text-white">
      <h5>Bibliothèque </h5>
      <h5>Universite Djilali Liabes</h5>
      <h5>departement informatique</h5>
      <h5>de sidi bel abbes</h5>
      <h5>CPR</h5>
    </div>
    
  </div>
</div> 
   
  </div>
  <div class="main">
  
    <h1>Bibliothèque universitaire</h1>
    
    <p>Une bibliothèque universitaire  est une bibliothèque rattachée à une université. Les documents et les services présents dans la bibliothèque universitaire peuvent ainsi servir à la double mission des universités, l'enseignement et la recherche.</p>
      
      <img src="msa_bu-lettres-2-720x587.jpg" a style="height: 500px; 
  width: 100%; "  >
    <br>
        
   
       <script>

var Index = 0;
rousel();

function rousel() {
    var j;
    var y = document.getElementsByClassName("Slides");
    for (j = 0; j < y.length; j++) {
       y[j].style.display = "none";
    }
    Index++;
    if (Index > y.length) {Index = 1}
    y[Index-1].style.display = "block";
    setTimeout(rousel, 3000);
}
</script>
      
    
  </div>
</div>
<!--=====================================footer=========================================-->
	<footer class="w3-center w3-black w3-padding-64 w3-opacity w3-hover-opacity-off">
  <a href="vers.php" class="w3-button w3-light-grey"><i class="fa fa-arrow-up w3-margin-right"></i>To the top</a>
		
  <div class="w3-xlarge w3-section">
    <i><i class="fa fa-share-alt">&nbsp;&nbsp;</i>Share: </i>&nbsp;&nbsp;&nbsp;&nbsp;
	  
    <i class="fa fa-facebook-official w3-hover-opacity"><a href="http://www.facebook.com/sharer.php?u=http%3A%2F%2Fwww.aliasdmc.com%2Fdeveloppement%2Fwebmaster%2Ffaire_un_lien_de_partage_sur_les_reseaux_sociaux.php&t=Comment%20faire%20des%20liens%20de%20partage%20sur%20les%20r%C3%A9seaux%20sociaux">&nbsp;facebook</a></i>&nbsp;&nbsp;&nbsp;&nbsp;
	  
    <i class="fa fa-whatsapp w3-hover-opacity"><a href="whatsapp://send?text=The text to share!" data-action="share/whatsapp/share">&nbsp;Whatsapp</a></i>&nbsp;&nbsp;&nbsp;&nbsp;
	  
    <i class="fa fa-twitter w3-hover-opacity"><a href="http://twitter.com/share?url=http://www.monsite.com&text=Texte du tweet">&nbsp;Twitter</a></i> 
	  
	  <i ><p><button class="w3-button w3-white w3-border w3-hover-opacity" onclick="likeFunction(this)"><b><i class="fa fa-thumbs-up"></i> Like</b></button></p></i>
	
	   
  </div>
</footer>
 

</body>
</html>

<?php
require_once("identifier.php");
require_once("connectiDb.php");

    $nom=isset($_POST['nom'])?$_POST['nom']:"";//les donées sont envoyée par la méthode post
    $prenom=isset($_POST['prenom'])?$_POST['prenom']:"";
    $numEn=isset($_POST['numCarte'])?$_POST['numCarte']:"";
    $cevilite=isset($_POST['cevilite'])?$_POST['cevilite']:"F";
    $niveau=isset($_POST['niveau'])?$_POST['niveau']:"";

    $requete="insert into   etudiant(nom,prenom,numCarte,cevilite,niveau) values(?,?,?,?,?)";    
   $param=array($nom,$prenom,$numEn,$cevilite,$niveau);


    $resultat = $pdo->prepare($requete);
    $resultat->execute($param);	
	header("location:etudiant.php");



?>

<meta charset="utf-8" />
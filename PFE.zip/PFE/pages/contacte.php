

<!DOCTYPE html>
<html lang="en">
<head>
<title>Page Title</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
     
<style>
* {
  box-sizing: border-box;
}

/* Style the body */
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

/* Header/logo Title */
.header {
  padding: 80px;
  text-align: center;
  background: #1abc9c;
  color: white;
}

/* Increase the font size of the heading */
.header h1 {
  font-size: 40px;
}

/* Sticky navbar - toggles between relative and fixed, depending on the scroll position. It is positioned relative until a given offset position is met in the viewport - then it "sticks" in place (like position:fixed). The sticky value is not supported in IE or Edge 15 and earlier versions. However, for these versions the navbar will inherit default position */
.navbar {
  overflow: hidden;
  background-color:  #000000;
  position: sticky;
  position: -webkit-sticky;
  top: 0;
}

/* Style the navigation bar links */
.navbar a {
  float: left;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 20px;
  text-decoration: none;
}


/* Right-aligned link */
.navbar a.right {
  float: right;
}

/* Change color on hover */
.navbar a:hover {
  background-color: #ddd;
  color: black;
}

/* Active/current link */
.navbar a.active {
  background-color: #666;
  color: white;
}

/* Column container */
.row {  
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
}

/* Create two unequal columns that sits next to each other */
/* Sidebar/left column */
.side {
  -ms-flex: 30%; /* IE10 */
  flex: 30%;
  background-color: #f1f1f1;
  padding: 20px;
}

/* Main column */
.main {   
  -ms-flex: 70%; /* IE10 */
  flex: 70%;
  background-color: white;
  padding: 20px;
}

/* Fake image, just for this example */
.fakeimg {
  background-color: #aaa;
  width: 100%;
  padding: 20px;
}

/* Footer */
.footer {
  padding: 1px;
  text-align: center;
  background: #ddd;
}

/* Responsive layout - when the screen is less than 700px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 700px) {
  .row {   
    flex-direction: column;
  }
}

/* Responsive layout - when the screen is less than 400px wide, make the navigation links stack on top of each other instead of next to each other */
@media screen and (max-width: 400px) {
  .navbar a {
    float: none;
    width: 100%;
  }
}
    
    -----------------------------------------
   * {
  box-sizing: border-box;
}

body {
  font-family: Arial;
  font-size: 17px;
}

.container {
  position: relative;
  max-width: 1500px;
  margin: 0 auto;
}

.container img {vertical-align: middle;}

.container .content {
  position: absolute;
  bottom: 0;
  background: rgb(0, 0, 0); /* Fallback color */
  background: rgba(0, 0, 0, 0.5); /* Black background with 0.5 opacity */
  color: #f1f1f1;
  width: 100%;
  padding: 20px;
}
    .center {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 50%;
}
</style>
</head>
<body>

 <div class="container">
    <section>    
  <img src="29064419_127470191426428_174595890764664072_o.jpg" alt="Notebook" style="height: 400px; 
  width: 100%;" class="mySlides">
        
      <img src="téléchargement (1).jpg" alt="Notebook" style="height: 400px; 
  width: 100%;" class="mySlides"> 
        <img src="photo.jpg" alt="Notebook" style="height: 400px; 
  width: 100%;" class="mySlides">
        </section>
        
        
 <script>

var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}
    x[myIndex-1].style.display = "block";
    setTimeout(carousel, 3000);
}
</script>
        
        
        
        
        
        
       <div class="content">
    <h1>Bibliothèque</h1>
    <p>Université Djilali Liabes de Sidi Bel Abbes.</p>
     <p> Département Informatique SBA.</p>
  </div>
</div> 
        
    
    
    
<div class="navbar">
  <a ><img src="udl.jpg" style="height: 50px; 
  width:50px;"
  ></a>
  <a href="vers.php"><p>Home</p></a>
  <a href="service.php"><p>Service</p></a>
  <a href="contacte.php"><p>Contacte</p></a>
  <a href="login.php" class="right"><p>Connecter</p></a>

</div> 

<div class="row">
  <div class="side">
    <h2>About Me</h2>
    <h5>Photo of me:</h5>
  
    <h3>More Text</h3>
    <p>Lorem ipsum dolor sit ame.</p>
    <div class="fakeimg" style="height:60px;">Image</div><br>
    <div class="fakeimg" style="height:60px;">Image</div><br>
    <div class="fakeimg" style="height:60px;">Image</div>
  </div>
  <div class="main">
 
      <style>
table, th {
  border: 1px solid black;
 
}

</style>



<h2>Contacte :</h2>

<p>- Bibliothèque du Département Informatique SBA.</p>
<p>- Adresse : Sidi Bel Abbès</p>
<p>- Téléphone : 048 xx xx xx</p>
<p>- Responsable: Mr.xxxxx .</p>
<p>- E-mail : Bibliothèque-Dépa-info-SBA@gmail.com</p>
<p>- whatsapp : 06 xx xx xxxx</p>
<p>- page Facebook :  Bibliothèque Département Info_SBA</p>

  
  </div>
</div>

<div class="footer">
  <h3>Université Djilali Liabes de Sidi Bel Abbes</h3>
</div>

</body>
</html>




<?php
   session_start();
  if(isset($_SESSION['user'])){//utilisateur connecter
	require_once("connectiDb.php");

	$ide=$_GET['ide'];

	$requete="delete from etudiant where idEtudiant=?";			
	$param=array($ide);	
	$resultatC = $pdo->prepare($requete);
    $resultatC ->execute($param);	
	header("location:etudiant.php");
      }else{//si l'utilisateur n'est pa authentifier
      header("location:login.php");
  }
	
?>
<meta charset="utf-8" />
    
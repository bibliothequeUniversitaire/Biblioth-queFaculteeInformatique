<?php

   require_once("identifier.php");
 
	require_once("connectiDb.php");
    $idL=isset($_GET['idl'])?$_GET['idl']:0;
    $requete="select * from livre where idLivre= $idL";
    $resultat=$pdo->query($requete);
    $livre=$resultat->fetch();
    
    $titre=$livre['titre'];
    $nbr=$livre['nbrCopie'];
    $auteur=$livre['auteur'];
    $maison=$livre['maisonEdition'];
    $annee=$livre['anneeEdition'];
    $photos=$livre['photos'];
    $description=$livre['description'];
    $branche=$livre['branche'];
        
?>


<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Détail du livre</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/nouveau.css">
        <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
	</head>
	<body>
        
	<?php include("nouveau.php");?>
    <div class="container">
			
        <div style="background-color:lightbrown"  class="panel panel-primary margetop" >
               
           <div class="panel-heading"  id="color" style="color: black">Détail du livre</div>
           <div class="panel-body">
                    
           <form method="post" action="livre.php" class="form" enctype="multipart/form-data" ><!--enctype pour l'envoi d'un fichier-->
                
               
               <div class="form-group" >
                   <label for="idl"><font color="chocolate">N°livre:</font> <?php echo $idL ?></label>  
                    <input type="hidden" name="idl"  class="form-control" value="<?php echo $idL ?>"/>
                </div>   
                        
                <div class="form-group" >
                    <label><font color="chocolate">Titre :</font> <?php echo $titre ?></label>  
                    <input type="hidden" name="titre" 
                       class="form-control" 
                       value="<?php echo $titre ?>"/>
                </div>   
                        <!---->
                <div class="form-group" >
                    <label><font color="chocolate">Auteur: </font><?php echo $auteur ?></label>  
                    <input type="hidden" name="auteur" 
                       class="form-control" 
                       value="<?php echo $auteur ?>"/>
                </div>  
               
               <!---->
               
          
                <div class="form-group" >
                    <label><font color="chocolate">Maison edition: </font><?php echo $maison ?></label>  
                    <input type="hidden" name="maison" 
                       class="form-control" 
                       value="<?php echo $maison ?>"/>
                </div> 
               

               
               
                        <!---->
              
               <div class="form-group" >
                    <label><font color="chocolate">Année edition: </font><?php echo $annee ?></label>  
                    <input type="hidden" name="maison" 
                       class="form-control" 
                       value="<?php echo $annee ?>"/>
                </div>
               <!---->
               
                 <div class="form-group" >
                    <label><font color="chocolate">Nombre de copie: </font><?php echo $nbr ?></label>  
                    <input type="hidden" name="nbr" 
                       class="form-control" 
                       value="<?php echo $nbr ?>"/>
                </div>
                    
               <!---->
                 <div class="form-group" >
                    <label><font color="chocolate">Description : </font><?php echo $description ?></label>  
                    <input type="hidden" name="nbr" 
                       class="form-control" 
                       value="<?php echo $description ?>"/>
                </div>                  
             <!---->
                 <div class="form-group" >
                    <label><font color="chocolate">Branche : </font><?php echo $branche ?></label>  
                    <input type="hidden" name="nbr" 
                       class="form-control" 
                       value="<?php echo $branche ?>"/>
                </div>  
                      <div class="form-group image" >       <!---->     
              <img src="../images/<?php echo $photos?>" 
				 class="center"								  width="236" height="304"
                
                   >   </div>
               <!---->
                  <button type="submit" class="btn btn-warning" style="color: black" >
                      <span class="glyphicon glyphicon-share" style="color: black"></span>
                        Retour
                      
                  </button> 
             
                      
                    </form>
                    
                    
                    
                    
                </div> 
                    
                    
                </div>
        </div>
        
		
							
	</body>
</html>
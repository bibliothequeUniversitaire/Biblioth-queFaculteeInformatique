

<?php
    require_once("identifier.php");
	require_once("connectiDb.php");

   $idM=isset($_POST['idm'])?$_POST['idm']:0;
    $nom=isset($_POST['nom'])?$_POST['nom']:"";//les donées sont envoyée par la méthode post
 $titre=isset($_POST['titre'])?$_POST['titre']:"";//les donées sont envoyée par la méthode post
    $etudiant=isset($_POST['etudiant'])?$_POST['etudiant']:"";
   $encadreur=isset($_POST['encadreur'])?$_POST['encadreur']:"";
    $categorie=isset($_POST['categorie'])?$_POST['categorie']:"";

    $edition=isset($_POST['edition'])?$_POST['edition']:"";
    $anneeEdition=isset($_POST['anneeEdition'])?$_POST['anneeEdition']:1;
    $nbrCopie=isset($_POST['nbrCopie'])?$_POST['nbrCopie']:1;
   $nomPhotos=isset($_FILES['photos']['name'])?$_FILES['photos']['name']:"";//Récuperer le Nom de la photo envoyée
    $imageTemp=$_FILES['photos']['tmp_name'];
    move_uploaded_file($imageTemp,"../images/".$nomPhotos);
	
    $description=isset($_POST['description'])?$_POST['description']:"";
    
        
 if(!empty($nomPhotos)){  //empty envoie vrai ssi  $nomPhoto est vide
    $requete="update   memoire set 	titre=?,
etudiant=?,encadreur=?,categorie=?,edition=?,anneeEdition=?,nbrCopie=?,photos=?,description=? where idmemoire=? ";
     
    $param=array($titre,$etudiant,$encadreur,$categorie,$edition,$anneeEdition,$nbrCopie,$nomPhotos,$description,$idM);
        
 }else{
    $requete="update   memoire set 	titre=?,
etudiant=?,encadreur=?,categorie=?,edition=?,anneeEdition=?,nbrCopie=?,description=? where idmemoire=? ";
   $param=array($titre,$etudiant,$encadreur,$categorie,$edition,$anneeEdition,$nbrCopie,$description,$idM);
    }
    $resultat = $pdo->prepare($requete);
    $resultat->execute($param);	
	header("location:memoire.php");
	
?>
<meta charset="utf-8" />
<?php
    require_once("identifier.php");
	require_once("connectiDb.php");
     
     $titrem=isset($_GET['titreM'])?$_GET['titreM']:"";
     $nomprenomm=isset($_GET['nomprenomM'])?$_GET['nomprenomM']:"";
     $auteurm=isset($_GET['auteurM'])?$_GET['auteurM']:"";
     
    $sizeE=isset($_GET['size'])?$_GET['size']:2;
    $pageE=isset($_GET['page'])?$_GET['page']:1;
    $offsetE=($pageE-1)*$sizeE;
     $requeteE="select  r.idmemoire,e.idEtudiant,etudiant,titre,idReservation,nom,prenom,dateRes,dateFinRes,nbrCopie
                 from memoire as m,reserver as r,etudiant as e
                 where (m.idmemoire=r.idmemoire and r.idEtudiant=e.idEtudiant)
                 
                 and titre like '%$titrem%' 
                 and etudiant like '%$auteurm%' 
                 and (nom like '%$nomprenomm%' or prenom like '%$nomprenomm%')
                 limit $sizeE 
                 offset $offsetE";
     $requeteCountE="select count(*) countM from memoire as m,reserver as r,etudiant as e
                 where (m.idmemoire=r.idmemoire and r.idEtudiant=e.idEtudiant)
                 and titre like '%$titrem%' 
                 and etudiant like '%$auteurm%'
                 and (nom like '%$nomprenomm%' or prenom like '%$nomprenomm%')
                 ";
$resultatE=$pdo->query($requeteE);//execution de la requete
     $resultatCountE=$pdo->query($requeteCountE);
     $tabCountE=$resultatCountE->fetch();
     $nbrMemoireE=$tabCountE['countM'];
     $resteE=$nbrMemoireE % $sizeE; // % operateur modulo:le reste de la division euclidiene de $nbrFiliere par
                               //$size
   if($resteE==0)//nbrFiliere est un multiple de size
        $nbrPageE=$nbrMemoireE/$sizeE;
   else
		$nbrPageE=floor($nbrMemoireE/$sizeE)+1;// floor retourne la partie entière d'un nombre 
										// decimale
	


   
?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Gestion des prets</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

		
        
	</head>
    <body>
        <?php include("nouveau.php");?>
       <style>
         body {
             background-image: url('95571686_2695129650770008_1954315548242214912_n.jpg');
              }
       </style>    
		
      <div class="container ">    <!--container permet d'apliquer une marge gauche et droite-->
        <div class="panel panel-info margetop" id="padding">
          <div class="panel-heading" id="color" style="color: black">Recherche des Reservation</div>
           <div class="panel-body">
             <form method="get" action="memoireReserverEt.php" class="form-inline" >
                <div class="form-group" >
                <input type="text" name="titreM" placeholder="Titre du mémoire" class="form-control" value="<?php echo $titrem?>"/>
                    &nbsp &nbsp
                    <input type="text" name="auteurM" placeholder=" Auteur " class="form-control" value="<?php echo $auteurm?>"/>
                    &nbsp &nbsp
                     <input type="text" name="nomprenomM" placeholder="Nom Prenom étudiant" class="form-control" value="<?php echo $nomprenomm?>"/>
                 </div> 
                 
                 
                 
                 &nbsp &nbsp
                    <button type="submit" class="btn btn-warning" style="color: black">
                      <span class="glyphicon glyphicon-search" style="color: black"></span>
                        Rechercher...
                  </button>
                    
                  
                </form>    
               
               </div>
           </div>
        
           <div class="panel panel-info margetop">
               <div class="panel-heading" id="color" style="color: black">Liste des reservation des étudiants(<?php echo $nbrMemoireE?> Mémoires)</div>
               <div class="panel-body">
                  <table class="table table-striped table-bordered">
                     <thead>
                        <tr style="color: chocolate">
                       <th >N°mémoire</th><th>N°Réservation</th><th >Titre</th><th>Auteur</th>
                           <th>N°Lecteur</th><th>Nom étudiant</th>
                            <th>Prénom étudiant</th>
                            <th>Date Reservarion</th>
                            <th>Date Fin Reservarion</th>
                            <?php if($_SESSION['user']['role']=='ADMIN'){?> 
                            <th>Action</th>
                            <?php }?>
                        </tr>
                     </thead>          
                     <tbody>
                        
                          <?php while($memoire=$resultatE->fetch()){?>   
                            <tr class="<?php 
                                  if($_SESSION['user']['role']=='ADMIN'){      
                                  $dateR=$memoire['dateFinRes'];
                                  
                       $dateAuj= date("Y-m-d");
                       $dateA = date_create($dateAuj);                  
                       $dateR = date_create($dateR); 
                             $Auj= date_timestamp_get($dateA);
                             $d= date_timestamp_get($dateR);         
                                      
                                  
                                        if($Auj>=$d)
                                        echo 'danger' ;
                                        
                                  }
                                 
                                        ?>">
                              <td ><?php echo $memoire['idmemoire']?></td>
                              <td ><?php echo $memoire['idReservation']?></td>
                              <td ><?php echo $memoire['titre']?></td>
                              <td ><?php echo $memoire['etudiant']?></td>
                              
                              <td ><?php echo $memoire['idEtudiant'] ?></td>
                              <td ><?php echo $memoire['nom'] ?></td>
                              <td ><?php echo $memoire['prenom'] ?></td>
                              <td ><?php echo $memoire['dateRes']?></td>    
                              <td ><?php echo $memoire['dateFinRes']?></td>    
                            <?php if($_SESSION['user']['role']=='ADMIN'){?> 
                              <td >
                                  &nbsp &nbsp  
                                 <a onclick="return confirm('Etes vous sure de vouloire supprimer cette Reservation' )"
                                     href="supprimerReserverEtM.php?idmet=<?php echo $memoire['idmemoire']?>
                                           &idet=<?php echo $memoire['idEtudiant']?>
                                           &nbr=<?php echo $memoire['nbrCopie']?>
                                     &idResm=<?php echo $memoire['idReservation']?>       
                                           
                                           
                                           "><span class="glyphicon glyphicon-trash" style="color: #994d00"></span></a>
                              </td>    
                                <?php }?>  
                            </tr>
                          <?php }?>    
                     </tbody>    
                   </table>   
                  </div>
               </div>
           <div>
           <ul class="pagination" >
							<?php for($j=1;$j<=$nbrPageE;$j++){ ?>
				              <li class="<?php if($j==$pageE) echo 'active' ?>">
								<a href="memoireReserverEt.php?page=<?php echo $j ?>&titreM=<?php echo $titrem?>">
										 <?php echo $j ?>
									</a>
								</li>
							<?php } ?>	
						</ul>
          
          
          </div> 
        </div>
            
    </body>
</html>    
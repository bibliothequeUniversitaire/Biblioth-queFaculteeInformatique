<?php
   session_start();
  if(isset($_SESSION['user'])){//utilisateur connecter
	require_once("connectiDb.php");
	
	
	$idme=$_GET['idme'];
	$ide=$_GET['ide'];
    
      $dateP= date("Y-m-d");
    $dateFp=date('Y-m-d', strtotime($dateP. ' + 30 days'));

	$requete="insert into     penalite(idmemoire,idEtudiant,dateP,dateFp) values(?,?,?,?)";    
   $param=array($idme,$ide,$dateP,$dateFp);

    $resultat = $pdo->prepare($requete);
    $resultat->execute($param);
      
      
      
      
	header("location:memoirePretEt.php");
      }else{//si l'utilisateur n'est pa authentifier
      header("location:login.php");
  }
	
?>
   <meta charset="utf-8" /> 
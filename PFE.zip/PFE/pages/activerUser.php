

<?php
    session_start();
    if(isset($_SESSION['user'])){
	require_once("connectiDb.php");

    $idUser=isset($_GET['idu'])?$_GET['idu']:0;
    $etat=isset($_GET['etat'])?$_GET['etat']:0;//les donées sont envoyée par la méthode post
    
    if($etat==1)
        $newEtat=0;
    else

        $newEtat=1;

    
    $requete="update   utilisateur set 	etat=? where idUtilisateur=? ";
    $param=array($newEtat,$idUser);
 
    $resultat = $pdo->prepare($requete);
    $resultat->execute($param);	
	header("location:utilisateurs.php");
	}else{//si l'utilisateur n'est pa authentifier
         header("location:login.php");
         }
?>
<meta charset="utf-8" />
<?php
   session_start();
  if(isset($_SESSION['user'])){//utilisateur connecter
	require_once("connectiDb.php");
	
	
	$idmet=$_GET['idmet'];
	$idet=$_GET['idet'];
    $nbr=$_GET['nbr'];
    $idEmprrr=$_GET['idEmprrr'];
      
      
	$requete="delete from emprunt where idmemoire=? and idEmrunt=?";			
	$param=array($idmet,$idEmprrr);	
	$resultatL = $pdo->prepare($requete);
    $resultatL ->execute($param);
      $nbr=$nbr+1; 
      ////////////////////
      
      $requetenbr="update memoire set nbrCopie='$nbr' where idmemoire='$idmet';";    
   $paramm=array($nbr);

    $resultatnbr = $pdo->prepare($requetenbr);
    $resultatnbr->execute($paramm);
      
      
      
      
      
      
	header("location:memoirePretEt.php");
      }else{//si l'utilisateur n'est pa authentifier
      header("location:login.php");
  }
	
?>
    
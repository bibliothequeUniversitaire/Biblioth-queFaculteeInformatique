
<?php
	require_once('connectiDb.php');
?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		
		<title>Nouvel Lecteur</title>
		
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		
		<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
        
	</head>
	<body>		
		 
		<div class="container user-page">
			<h1 class="text-center">
        		Donnez Vos Information Personelle
    		</h1>
			<form method="post" action="insertLecteurNouveau.php" class="form"      enctype="multipart/form-data" >			
										
				<div class="input-container">
					<input
                            title="ce champ est vide"
							class="form-control"
							type="text"
							name="nom"
							placeholder="Taper votre Nom"
							required="required">
				</div>
                <div class="input-container">
					<input
                            title="ce champ est vide"
							class="form-control"
							type="text"
							name="prenom"
							placeholder="Taper votre Prenom"
							required="required">
				</div>
                
                  
                <div>
                <input
                            title="ce champ est vide"
							pattern=".{12,}"
							title="Le numero de carte doit contenir 12 Number"
							class="form-control"
							type="number"
							name="numCarte"
							autocomplete="off"
							placeholder="Taper votre Numero de carte"
							required="required">
				</div>
                
                <div       class="form-group" required="required" title="choisez votre cevilite"> 
                           <label for="niveau">Cevilite:</label>
                           <div class="radio">
                                <label><input type="radio" name="cevilite"  value="F" checked/>F</label><br>
                                <label><input type="radio" name="cevilite"  value="M"/>M</label>            
                 <script>
function disable() {
  document.getElementById("niveau").disabled=true;
}
function enable() {
  document.getElementById("niveau").disabled=false;
}
</script>          </div>
                    
                </div>
                
                 <div class="form-group" >
                <label for="typee">Type:</label>  
                <div class="radio">
                   <label><input type="radio" name="typee"  value="E" checked onclick="enable()"/>Etudiant</label><br>
                   <label><input type="radio" name="typee"  value="En" onclick="disable()"/>Enseignant</label>            
                </div>   
            </div>  
                
                
                
                
                
                
                
                
                
                <div       class="form-group" required="required" title="choisez votre niveau" id="nve">
                           <label for="niveau">Niveau:</label>
                           <select name="niveau" class="form-control" id="niveau">
                                  <option value="l2" selected>Licence 2</option>
                                  <option value="l3">Licence 3</option>
                                  <option value="m1">Master 1</option>
                                  <option value="m2">Master 2</option>
                                  </select>
                    
               </div>
                
             
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                <div class="form-group"   title="accepté les condition">
                    
                 <label><input type="checkbox" required="required"  />  J'accepte les conditions  <a href="condition.php">de la bibliothèque</a> 
                </label>
                </div>    
                
                
                
                
               <input
						class="btn btn-success btn-block"
						type="submit"
						value="Enregistere">
        </form>
	</div>		
  </body>
</html>




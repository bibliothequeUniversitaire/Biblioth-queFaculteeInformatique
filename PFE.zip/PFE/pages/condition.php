<html>
 <head>
  <title>My bibliotheque</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="../css/styleMALAK.css"/>
  <style>
      #header{
          background-color: maroon;
      }
      #container{
          background-color: white;
      }
  </style>
 </head>
 
 <body>
     <style>
         body {
             background-image: url('téléchargement (3).jpg');
             
              }
         
       </style> 
 <form method="post" action="formulaireLecteur.php" class="content" enctype="multipart/form-data" >
  <div id="cont">
      <div id="hed">
          
       <h1 >Les Conditions</h1>
      </div>
      <div id="content">
       <div id="main">
           <ul>
        <li><a><h3>Les Enseignants:</h3></a>
            <ul>
               <li><a>le maximum d'emprunt : 3 ouvrages</a></li>
               <li><a>la durée de chaque emprunt : 30 jours.Si vous dépassez 30 jours, vous serez puni pendant une semaine en vous interdisant d'emprunter ou de reserver. </a></li>
               <li><a>le maximum de  reservation: 3 ouvrages</a></li>    
               <li><a>la durée de chaque reservation : si depasse 5jours eliminer</a></li>
            </ul>
        </li>
        <li><a><h3>Les Etudiants:</h3></a>
            <ul>
               <li><a>le maximum d'emprunt : 2 ouvrages</a></li>
               <li><a>la durée de chaque emprunt : 15 jours.Si vous dépassez 15 jours, vous serez puni pendant 15 jours en vous interdisant d'emprunter ou de réserver</a></li>
               <li><a>le maximum de reservation : 2 ouvrages</a></li>    
               <li><a>la durée de chaque reservation : si depasse 2jours eliminer</a>
            </ul>
       </li>
         <div class="shadowbox">
    <p class="para"> <h4>ATTENTION !!!
        pour suivi les emprunts et les reservation respecter les conditions. 
        Le non-respect des conditions ci-dessus ou toute infraction à la loi sur la bibliotheque entraine des sanctions sévéres .</h4></p>  
    </div>
    </ul>
        
            
        </div>
      </div>
          <button type="submit" class="btn">
                        j'accepte
                      </button>
      <div id="">
      </div>
  </div>
     </form>
 </body>
</html>
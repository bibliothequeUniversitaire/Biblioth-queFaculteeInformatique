<?php
    require_once("identifier.php");
	require_once("connectiDb.php");
     
     $titrem=isset($_GET['titreM'])?$_GET['titreM']:"";
     $anneem=isset($_GET['anneeM'])?$_GET['anneeM']:"";
     $anneem=isset($_GET['anneeM'])?$_GET['anneeM']:"";
     $categorie=isset($_GET['categorie'])?$_GET['categorie']:"all";//pour recuperer le parametre envoyer dans utl
     $encadreurEtudiantm=isset($_GET['encadreurEtudiantM'])?$_GET['encadreurEtudiantM']:"";
     

 $size=isset($_GET['size'])?$_GET['size']:6;
    $page=isset($_GET['page'])?$_GET['page']:1;
    $offset=($page-1)*$size;


if($categorie=="all"){
     $requete="select * from memoire
                   where (encadreur like '%$encadreurEtudiantm%' or etudiant 
                   like '%$encadreurEtudiantm%')
                   and   titre like '%$titrem%' 
                   and   anneeEdition like '%$anneem%' 
                   limit $size offset $offset";
     $requeteCount="select count(*) countM from memoire 
                   where (encadreur like '%$encadreurEtudiantm%' or etudiant 
                   like '%$encadreurEtudiantm%')
                   and   titre like '%$titrem%' 
                   and   anneeEdition like '%$anneem%'  ";
}else{
    
     $requete="select * from memoire
                   where (encadreur like '%$encadreurEtudiantm%' or etudiant 
                   like '%$encadreurEtudiantm%')
                   and   titre like '%$titrem%' 
                   and   anneeEdition like '%$anneem%'
                   and categorie='$categorie' 
                   limit $size offset $offset";
    $requeteCount="select count(*) countM from memoire 
              where (encadreur like '%$encadreurEtudiantm%' or etudiant 
                   like '%$encadreurEtudiantm%')
                   and   titre like '%$titrem%' 
                   and   anneeEdition like '%$anneem%'
              and categorie='$categorie'";
    
}
     $resultatM=$pdo->query($requete);//execution de la requete
     $resultatCount=$pdo->query($requeteCount);
     $tabCount=$resultatCount->fetch();
     $nbrMemoire=$tabCount['countM'];
     $reste=$nbrMemoire % $size; // % operateur modulo:le reste de la division euclidiene de $nbrFiliere par
                               //$size
   if($reste==0)//nbrFiliere est un multiple de size
        $nbrPage=$nbrMemoire/$size;
   else
		$nbrPage=floor($nbrMemoire/$size)+1;// floor retourne la partie entière d'un nombre 
										// decimale
	

      
?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Gestion des memoires</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
		
        
	</head>
    <body>
        <?php include("nouveau.php");?>
       <style>
         body {
             background-image: url('95571686_2695129650770008_1954315548242214912_n.jpg');
              }
       </style>  
        
        
        

      <div class="container ">    <!--container permet d'apliquer une marge gauche et droite-->
        <div class="panel panel-info margetop" >
          <div class="panel-heading" id="color" style="color: black">Recherche des mémoires</div>
           <div class="panel-body">
             <form method="get" action="memoire.php" class="form-inline" >
                <div class="form-group" >
                    &nbsp &nbsp
                <input type="text" name="titreM" placeholder="Titre memoire" class="form-control" value="<?php echo $titrem?>"/>
                    
                    &nbsp &nbsp
                <input type="text" name="encadreurEtudiantM" placeholder="Encadreur ou Etudiant" class="form-control"  value="<?php echo $encadreurEtudiantm?>"/>
                    
                     
                </div> 
                 
                 &nbsp &nbsp
                 
                 
                 <div class="form-group" >
                <input 
                       type="number"    min="1900" max="3000"  
                       name="anneeM"
                       placeholder="Annee d'édition" class="form-control" value="<?php echo $anneem?>"/>
                </div> 
                 
             
                <label for="categorie">Catégorie:</label>
                  &nbsp &nbsp
                <select name="categorie" class="form-control" id="categorie" onchange="this.form.submit()"><!--this.from.submit() evenement de js-->
                  <option value="all"<?php if($categorie==="all") echo "selected"?> style="color: black">Tous les memoires</option>
                  <option value="master"<?php if($categorie==="master") echo "selected"?> style="color: black">master</option>
                  <option value="licence"<?php if($categorie==="licence") echo "selected"?> style="color: black">licence</option>
                  <option value="doctorat"<?php if($categorie==="doctorat") echo "selected"?> style="color: black">doctorat</option>
                  <option value="majister"<?php if($categorie==="majister") echo "selected"?> style="color: black">majister</option>
                     </select>
                  &nbsp &nbsp
                    <button type="submit" class="btn btn-warning" style="color: black">
                      <span class="glyphicon glyphicon-search" style="color: black"></span>
                        Rechercher...
                  </button>
                    <?php if($_SESSION['user']['role']=='ADMIN'){?>
                    <a href="nouveauMemoire.php" style="color: black"><span class="glyphicon glyphicon-plus" style="color: black"></span>
                      Nouveau memoire</a>
                 <?php }?>
                </form>    
               
               </div>
           </div>
        
           <div class="panel panel-info margetop" >
               <div class="panel-heading" id="color" style="color: black">Liste des memoires (<?php echo $nbrMemoire?> Mémoires)</div>
               <div class="panel-body">
                  <table class="table table-striped table-bordered">
                     <thead>
                        <tr style="color: chocolate">
                           <th >N° memoire</th><th >titre</th><th >Etudiant</th><th>Encadreur</th><th >Catégorie</th><th >Edition</th><th >AnneeEdition</th><th >Copie</th><th >Photo</th>
                           <th>Détail</th><th>Pret</th><th>Reserver</th>
                            <?php if($_SESSION['user']['role']=='ADMIN'){?>
                            <th >Action</th>
                            <?php }?>
                            
                        </tr>
                     </thead>          
                     <tbody>
                        
                          <?php while($memoire=$resultatM->fetch()){?>   
                            <tr>
                              <td><?php echo $memoire['idmemoire']?></td>
                              <td><?php echo $memoire['titre']?></td>
                              <td><?php echo $memoire['etudiant']?></td>
                              <td><?php echo $memoire['encadreur']?></td>
                                
                              <td><?php echo $memoire['categorie']?></td>
                              <td><?php echo $memoire['edition']?></td>
                              <td><?php echo $memoire['anneeEdition']?></td>
                              <td><?php echo $memoire['nbrCopie']?></td>
                              <td>
								 <img src="../images/<?php echo $memoire['photos']?>" 
												class="img-thumbnail"  width="50" height="40" ></td>
                              
                              <td>
                             &nbsp &nbsp
                             <a href="detailMemoire.php?idm=<?php echo $memoire['idmemoire']?>"><span class="glyphicon glyphicon-play" style="color: #994d00"></span></a></td> 
                      
                                
                                
                                
                                
                              <td><a  href="formulairePretM.php?idm=<?php echo $memoire['idmemoire']?>" style="color: #994d00"><span class="glyphicon glyphicon-triangle-right"></span></a></td>
                              
                              <td><a  href="formulaireReserverM.php?idm=<?php echo $memoire['idmemoire']?>" style="color: #994d00"><span class="glyphicon glyphicon-triangle-right"></span></a></td> 
                                
                              <?php if($_SESSION['user']['role']=='ADMIN'){?>
                              <td style="color: #994d00">
                                <a href="editerMemoire.php?idm=<?php echo $memoire['idmemoire']?>" ><span style="color: #994d00"class="glyphicon glyphicon-edit"></span></a>
                                  
                                  
                                  
                                  &nbsp &nbsp
                                  <a onclick="return confirm('Etes vous sure de vouloire supprimer cette memoire' )"
                                     href="supprimerMemoire.php?idm=<?php echo $memoire['idmemoire']?>"><span class="glyphicon glyphicon-trash" style="color:#994d00"></span></a>  
                              </td>    
                                
                                <?php }?>
                            </tr>
                          <?php }?>    
                        
                      
                     </tbody>    
                   </table>   
                   <div>
                   
                     <ul class="pagination">
							
							<?php for($i=1;$i<=$nbrPage;$i++){ ?>
				              <li class="<?php if($i==$page) echo 'active' ?>">

								<a href="memoire.php?page=<?php echo $i ?>&titreM=<?php echo $titrem?>&categorie=<?php echo  $categorie?>">

										
										 <?php echo $i ?>
									</a>
								</li>
							<?php } ?>	
						</ul>
                   
                   
                   </div>    
               </div>
           </div>
    </div>    
    </body>
</html>    
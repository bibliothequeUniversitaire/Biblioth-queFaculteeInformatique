<?php
   session_start();
  if(isset($_SESSION['user'])){//utilisateur connecter
	require_once("connectiDb.php");
	
	
	$idcet=$_GET['idcet'];
	$idet=$_GET['idet'];
    $nbr=$_GET['nbr'];
    $idResc=$_GET['idResc'];
     
	$requete="delete from reserver where idCd=? and idReservation=?";			
	$param=array($idcet,$idResc);	
	$resultatC = $pdo->prepare($requete);
    $resultatC ->execute($param);
      
       $nbr=$nbr+1; 
      ////////////////////
      
      $requetenbr="update cd set nbrCopie='$nbr' where idCd='$idcet';";    
   $paramm=array($nbr);

    $resultatnbr = $pdo->prepare($requetenbr);
    $resultatnbr->execute($paramm);
      
      
      
	header("location:cdReserverEt.php");
      }else{//si l'utilisateur n'est pa authentifier
      header("location:login.php");
  }
	
?>
    
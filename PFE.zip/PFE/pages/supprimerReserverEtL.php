<?php
   session_start();
  if(isset($_SESSION['user'])){//utilisateur connecter
	require_once("connectiDb.php");
	
	
	$idlet=$_GET['idlet'];
	$idet=$_GET['idet'];
	$nbr=$_GET['nbr'];
	$idRes=$_GET['idRes'];

	$requete="delete from reserver where idLivre=? and idReservation=?";			
	$param=array($idlet,$idRes);	
	$resultatL = $pdo->prepare($requete);
    $resultatL ->execute($param);	
     $nbr=$nbr+1; 
      ////////////////////////////
      
      $requetenbr="update livre set nbrCopie='$nbr' where idLivre='$idlet';";    
   $paramm=array($nbr);

    $resultatnbr = $pdo->prepare($requetenbr);
    $resultatnbr->execute($paramm);
      
      
	header("location:livreReserverEt.php");
      }else{//si l'utilisateur n'est pa authentifier
      header("location:login.php");
  }
	
?>
    
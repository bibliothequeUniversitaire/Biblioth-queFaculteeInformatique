<?php
    require_once ('identifier.php');
?>
<?php
    require_once ('connectiDb.php');
    
    $idu=$_SESSION['idu'];
    $loginn=$_SESSION['login'];
    $mail=$_SESSION['email'];


    $pwd=isset($_POST['newpwd'])?$_POST['newpwd']:"";
    
     $requete="update   utilisateur set pwd=md5(?) where idUtilisateur=? ";
    $param=array($pwd,$idu);
 
    $resultat = $pdo->prepare($requete);
    $resultat->execute($param);	
    
  

?>
<!DOCTYPE html>
<html lang="fr">
    <head>
        <title>Changement de mot de passe</title>
        <meta charset="utf-8">
         <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../css/mystyle.css">
        <script src="../js/jquery-3.3.1.js"></script>
        <script src="../js/myjs.js"></script>
    </head>
    <body>
    	
    	<h1 class="text-center">Changement de mot de passe</h1>
    	
    	<div class="container">
    		
              
           <div class="alert alert-success">
        			<h3>Le Changement de votre compte est achevé avec succes</h3>
        			<p>
        				<label for="login" class="control-label">Login :<?php echo $loginn; ?></label>
        			</p>
        			<p>
        				<label for="email" class="control-label">Email :<?php echo $mail; ?></label>
        			</p>
        			<?php header("refresh:10;url=utilisateurs.php");?>
        			
        			
        		</div> 
            
            
            
        	    
    
    	</div>
    
    </body>
</html>
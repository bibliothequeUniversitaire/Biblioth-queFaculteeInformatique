<?php



   session_start();
  if(isset($_SESSION['user'])){//utilisateur connecter
	require_once("connectiDb.php");

	
	
	$idc=$_GET['idc'];

	$requete="delete from cd where idCd=?";			
	$param=array($idc);	
	$resultatC = $pdo->prepare($requete);
    $resultatC ->execute($param);	
	header("location:cd.php");
      }else{//si l'utilisateur n'est pa authentifier
      header("location:login.php");
  }
	
?>
<meta charset="utf-8" />
    
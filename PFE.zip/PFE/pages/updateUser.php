

<?php
    require_once("identifier.php");
	require_once("connectiDb.php");

    $idUser=isset($_POST['idu'])?$_POST['idu']:0;
    $login=isset($_POST['login'])?$_POST['login']:"";//les donées sont envoyée par la méthode post

    $email=isset($_POST['email'])?$_POST['email']:"";
    $role=isset($_POST['role'])?$_POST['role']:"";


    
    $requete="update   utilisateur set 	login=?,email=?,role=? where idUtilisateur=? ";
    $param=array($login,$email,$role,$idUser);
 
    $resultat = $pdo->prepare($requete);
    $resultat->execute($param);	
	header("location:utilisateurs.php");
	
?>
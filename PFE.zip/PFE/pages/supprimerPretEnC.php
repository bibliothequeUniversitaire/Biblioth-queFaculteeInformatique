<?php
   session_start();
  if(isset($_SESSION['user'])){//utilisateur connecter
	require_once("connectiDb.php");
	
	
	$idcen=$_GET['idcen'];
	$iden=$_GET['iden'];
    $nbr=$_GET['nbrEn'];
    $idEmprc=$_GET['idEmprc'];
      
      
	$requete="delete from emprunt where idCd=? and idEmrunt=?";			
	$param=array($idcen,$idEmprc);	
	$resultatC = $pdo->prepare($requete);
    $resultatC ->execute($param);
      $nbr=$nbr+1; 
      ////////////////////
      
      $requetenbr="update cd set nbrCopie='$nbr' where idCd='$idcen';";    
   $paramm=array($nbr);

    $resultatnbr = $pdo->prepare($requetenbr);
    $resultatnbr->execute($paramm);
      
      
      
      
      
      
	header("location:cdPretEn.php");
      }else{//si l'utilisateur n'est pa authentifier
      header("location:login.php");
  }
	
?>
    
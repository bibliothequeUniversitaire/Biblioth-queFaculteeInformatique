<?php
   session_start();
  if(isset($_SESSION['user'])){//utilisateur connecter
	require_once("connectiDb.php");
	
	
	$idlen=$_GET['idlen'];
	$iden=$_GET['iden'];
    $nbr=$_GET['nbrEn'];
    $idRess=$_GET['idRess'];
      
	$requete="delete from reserver where idLivre=? and idReservation=?";			
	$param=array($idlen,$idRess);	
	$resultatL = $pdo->prepare($requete);
    $resultatL ->execute($param);
      $nbr=$nbr+1; 
      
      /////////////////////////
      $requetenbr="update livre set nbrCopie='$nbr' where idLivre='$idlen';";    
   $paramm=array($nbr);

    $resultatnbr = $pdo->prepare($requetenbr);
    $resultatnbr->execute($paramm);
      
      
      
      
	header("location:livreReserverEn.php");
      }else{//si l'utilisateur n'est pa authentifier
      header("location:login.php");
  }
	
?>
    
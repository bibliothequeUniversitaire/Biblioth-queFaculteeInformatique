<?php
    require_once("identifier.php");
	require_once("connectiDb.php");
   $nomprenome=isset($_GET['nomprenomE'])?$_GET['nomprenomE']:"";
     $nume=isset($_GET['numE'])?$_GET['numE']:"";
     $niveau=isset($_GET['niveau'])?$_GET['niveau']:"all";
     

 $size=isset($_GET['size'])?$_GET['size']:2;
    $page=isset($_GET['page'])?$_GET['page']:1;
    $offset=($page-1)*$size;
if($niveau=="all"){
     $requete="select p.idmemoire,e.idEtudiant,titre,nom,prenom,niveau,dateP,dateFp,numCarte,nbrCopie
                 from memoire as m,penalite as p,etudiant as e
                 where (m.idmemoire=p.idmemoire and p.idEtudiant=e.idEtudiant)
                 
                 and numCarte like '%$nume%' 
                  
                and (nom like '%$nomprenome%' or prenom like '%$nomprenome%')
                 limit $size 
                 offset $offset";
    
    $requeteCount="select count(*) countE from memoire as m,penalite as p,etudiant as e
                 where (m.idmemoire=p.idmemoire and p.idEtudiant=e.idEtudiant)
                 
                 and numCarte like '%$nume%' 
                  
                and (nom like '%$nomprenome%' or prenom like '%$nomprenome%') ";
     }else{
    
      $requete=" select p.idmemoire,e.idEtudiant,titre,nom,prenom,niveau,dateP,dateFp,numCarte,nbrCopie
                 from memoire as m,penalite as p,etudiant as e
                 where (m.idmemoire=p.idmemoire and p.idEtudiant=e.idEtudiant)
                 
                 and numCarte like '%$nume%' 
                  
                and (nom like '%$nomprenome%' or prenom like '%$nomprenome%')
                   and niveau='$niveau'
                   
                   limit $size offset $offset";
    
     $requeteCount="select count(*) countE from memoire as m,penalite as p,etudiant as e
                 where (m.idmemoire=p.idmemoire and p.idEtudiant=e.idEtudiant)
                 
                 and numCarte like '%$nume%' 
                  
                and (nom like '%$nomprenome%' or prenom like '%$nomprenome%') 
                   and niveau='$niveau'";
   
}


$resultatE=$pdo->query($requete);//execution de la requete
     $resultatCount=$pdo->query($requeteCount);
     $tabCount=$resultatCount->fetch();
     $nbrEtudiant=$tabCount['countE'];
     $reste=$nbrEtudiant % $size; // % operateur modulo:le reste de la division euclidiene de $nbrFiliere par
                               //$size*/
   if($reste==0)//nbrFiliere est un multiple de size
        $nbrPage=$nbrEtudiant/$size;
   else
		$nbrPage=floor($nbrEtudiant/$size)+1;// floor retourne la partie entière d'un nombre 
								
      
?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Gestion des etudiants</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

		
        
	</head>
    <body>
<style>
         body {
             background-image: url('95571686_2695129650770008_1954315548242214912_n.jpg');
              }
       </style>
        
        
		<?php include("nouveau.php");?>
      <div class="container ">    <!--container permet d'apliquer une marge gauche et droite-->
        <div class="panel panel-info margetop" id="padding">
          <div class="panel-heading" id="color" style="color: black">Recherche des étudiants</div>
           <div class="panel-body">
             <form method="get" action="penaliteEtm.php" class="form-inline" >
                <div class="form-group" >
                    
                    &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
                    &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
                    &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
                <input type="text" name="nomprenomE" placeholder="Nom ou Prenom" class="form-control" value="<?php echo $nomprenome?>"/>
                    
                 
                 
                 &nbsp &nbsp
                <input id="number" 
                       type="number"    
                       name="numE" 
                       placeholder="N° carte" 
                       class="form-control"
                       value="<?php echo $nume?>"/>
                </div> 
                 
                 
                 
                 &nbsp &nbsp
                 
                 &nbsp &nbsp
                 <label for="niveau">Niveau:</label>
                  &nbsp &nbsp
                <select name="niveau" class="form-control" id="niveau" onchange="this.form.submit()"><!--this.from.submit() evenement de js-->
                  <option value="all"<?php if($niveau==="all") echo "selected"?>>Tous les niveaux</option>
                    
                  <option value="l2"<?php if($niveau==="l2") echo "selected"?>>Licence 2</option>
                    
                  <option value="l3"<?php if($niveau==="l3") echo "selected"?>>Licence 3</option>
                    
                  <option value="m1"<?php if($niveau==="m1") echo "selected"?>>Master 1</option>
                    
                  <option value="m2"<?php if($niveau==="m2") echo "selected"?>>Master 2</option>
                    
                    
                     </select>
                 
                 
                 
                 
                 
                 
                 &nbsp &nbsp
                    <button type="submit" class="btn btn-warning" style="color: black">
                      <span class="glyphicon glyphicon-search" style="color: black"></span>
                        Rechercher...
                  </button>
                    
                </form>    
               
               </div>
           </div>
        
           <div class="panel panel-info margetop" style="color: black">
               <div class="panel-heading" id="color" style="color: black">Liste des étudiants pénalisés (<?php echo $nbrEtudiant?> Etudiants)</div>
               <div class="panel-body">
                  <table class="table table-striped table-bordered">
                     <thead>
                        <tr style="color: chocolate">
                            <th >N°étudiant</th><th >Nom étudiant</th><th>Prénom étudiant</th><th>N°Carte</th><th>Niveau</th>
                           <th>N°mémoire</th><th>Titre</th><th >Date pénalité</th><th>Date fin pénalité</th>
                             <?php if($_SESSION['user']['role']=='ADMIN'){?>
                            <th>Action</th>
                              <?php }?>
                        </tr>
                     </thead>          
                     <tbody>
                        
                          <?php while($etudiant=$resultatE->fetch()){?>   
                            <tr class="<?php 
                                  if($_SESSION['user']['role']=='ADMIN'){      
                                  
    
   $dateR=$etudiant['dateFp'];
                                  
                       $dateAuj= date("Y-m-d");
                       $dateA = date_create($dateAuj);                  
                       $dateR = date_create($dateR); 
                             $Auj= date_timestamp_get($dateA);
                             $d= date_timestamp_get($dateR);         
                                      
                                  
                                        if($Auj>=$d)
                                        echo 'success' ;       
                                  }
    
    
                                        ?>">
                              <td ><?php echo $etudiant['idEtudiant']?></td>
                              <td ><?php echo $etudiant['nom']?></td>
                              <td ><?php echo $etudiant['prenom']?></td>
                              <td ><?php echo $etudiant['numCarte']?></td>
                              <td><?php echo  $etudiant['niveau']?></td>
                              <td ><?php echo $etudiant['idmemoire'] ?></td>
                              <td ><?php echo $etudiant['titre'] ?></td> 
                              <td ><?php echo $etudiant['dateP']?></td>
                              <td ><?php echo $etudiant['dateFp']?></td>    
                            <?php if($_SESSION['user']['role']=='ADMIN'){?> 
                               <td >
                                  &nbsp &nbsp  
                                 <a onclick="return confirm('Etes vous sure de vouloire supprimer cette punition' )"
                href="supprimerPenEtM.php?idmet=<?php echo $etudiant['idmemoire']?>
                                           &idet=<?php echo $etudiant['idEtudiant']?>&nbr=<?php echo $etudiant['nbrCopie']?>"><span class="glyphicon glyphicon-trash" style="color: #994d00"></span>
                                  </a>
                              </td>    
                                <?php }?>     
                                
                            </tr>
                          <?php }?>    
                        
                      
                     </tbody>    
                   </table>   
                   <div>
                   
                     <ul class="pagination">
							
							<?php for($i=1;$i<=$nbrPage;$i++){ ?>
				              <li class="<?php if($i==$page) echo 'active' ?>">

								<a href="penaliteEtm.php?page=<?php echo $i ?>&nomprenomE=<?php echo $nomprenome?>"style="color: black">

										
										 <?php echo $i ?>
									</a>
								</li>
							<?php } ?>	
						</ul>
                   
                   
                   </div>    
               </div>
           </div>
    </div>    
    </body>
</html>    
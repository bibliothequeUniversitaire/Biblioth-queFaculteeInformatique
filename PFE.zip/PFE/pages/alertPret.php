
<script>
    var b=2;
</script>

<?php
    $c='<script>  document.writeln(b);</script>';
    echo  $c;
?>
<meta charset="utf-8" />
<?php
require_once("identifier.php");
require_once("connectiDb.php");

    $titre=isset($_POST['titre'])?$_POST['titre']:"";//les donées sont envoyée par la méthode post
    $etudiant=isset($_POST['etudiant'])?$_POST['etudiant']:"";
    $encadreur=isset($_POST['encadreur'])?$_POST['encadreur']:"";
    $categorie=isset($_POST['categorie'])?$_POST['categorie']:"";



    $edition=isset($_POST['edition'])?$_POST['edition']:"";
    $anneeEdition=isset($_POST['anneeEdition'])?$_POST['anneeEdition']:1;
    $nbrCopie=isset($_POST['nbrCopie'])?$_POST['nbrCopie']:1;
    
    
    $description=isset($_POST['description'])?$_POST['description']:"";
    
    $requete="insert into     cd(titre,etudiant,encadreur,categorie,edition,anneeEdition,nbrCopie,description) values(?,?,?,?,?,?,?,?)";    
   $param=array($titre,$etudiant,$encadreur,$categorie,$edition,$anneeEdition,$nbrCopie,$description,);




    $resultat = $pdo->prepare($requete);
    $resultat->execute($param);	
	header("location:cd.php");

?>
<meta charset="utf-8" />
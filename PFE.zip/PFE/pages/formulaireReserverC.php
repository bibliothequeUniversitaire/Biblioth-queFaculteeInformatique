<?php

   require_once("identifier.php");
 
	require_once("connectiDb.php");
    $idC=isset($_GET['idc'])?$_GET['idc']:0;
    $requete="select * from cd where idCd= $idC";
    $resultat=$pdo->query($requete);
    $cd=$resultat->fetch();
    $_SESSION['idc']=$idC;
    $titre=$cd['titre'];
    $nbr=$cd['nbrCopie'];
    $etudiant=$cd['etudiant'];
    $dateRes= date("Y-m-d");
    $dateFinResEn=date('Y-m-d', strtotime($dateRes. ' + 5 days'));
    $dateFinResE=date('Y-m-d', strtotime($dateRes. ' + 3 days'));
    
  $_SESSION['dateR']=$dateRes;
  $_SESSION['dateFEn']=$dateFinResEn;
  $_SESSION['dateFE']=$dateFinResE;
        
?>


<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Formulaire Reserver CD</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
        
	</head>
	<body>
	<?php include("nouveau.php");?>
    <div class="container">
			
        <div style="background-color:lightbrown"  class="panel panel-primary margetop" >
               <?php if($nbr>=1){ ?> 
           <div class="panel-heading"  id="color" style="color: black">formulaire Reservation des Cd</div>
           <div class="panel-body">
                    
           <form method="post" action="insertCReserver.php" class="form" enctype="multipart/form-data" ><!--enctype pour l'envoi d'un fichier-->
                
               
               <div class="form-group" >
                    <label for="idm">N°CD: <?php echo $idC ?></label>  
                    <input type="hidden" name="idc"  class="form-control" value="<?php echo $idC ?>"/>
                </div>   
                        
                <div class="form-group" >
                    <label >Titre : <?php echo $titre ?></label>  
                    <input type="hidden" name="titre" 
                       class="form-control" 
                       value="<?php echo $titre ?>"/>
                </div>   
                        <!---->
                <div class="form-group" >
                    <label  >Auteur: <?php echo $etudiant ?></label>  
                    <input type="hidden" name="etudiant" 
                       class="form-control" 
                       value="<?php echo $etudiant ?>"/>
                </div>  
               
               <!---->
               
          
                <div class="form-group" >
                     <label >Date Reservation:  <?php echo $dateRes ?></label>   
                            <input type="hidden" 
                            name="dateRes" placeholder="dateRes"            class="form-control" />
                </div>
               
               <!---->
               
         <label >Date Fin Reservation: </label>     
               
<input type="radio" name="typee" value="<?php  echo $dateFinResEn?>" id="en" onclick="enn()" required>Enseignant
               
               &nbsp;
<input type="radio" name="typee" value="<?php  echo $dateFinResE?>" id="et" onclick="ett()"  >Etudiant





<p id="demo"></p>

    

<p id="demo"></p>

<script>
function ett() {
  var x = document.getElementById("et").value;
  document.getElementById("demo").innerHTML = x;
}
</script>        
            <script>
function enn() {
  var x = document.getElementById("en").value;
  document.getElementById("demo").innerHTML = x;
}
</script>          
               
               
                        <!---->
              
               
               
               
                 <div class="form-group" >
                           <label>N°carte :</label>   
                           <input type="number" name="numcarte" placeholder="Numero Lecteur:" class="form-control" required="required"
                            title="ce champ est vide "/>
                 </div> 
                        
               
               
               
               
               
                        
                  <button type="submit" class="btn btn-warning" style="color: black">
                      <span class="glyphicon glyphicon-save" style="color: black"></span>
                        Enregistrer
                      
                  </button>
                      <?php }else{
    
   echo $msg = "<center><h3><strong>Erreur!</strong> Ce Cd n'est pas disponible!!!</h3></center>";
    
    
}?>
                    </form>
                    
                    
                    
                    
                </div> 
                    
                    
                </div>
        </div>
        
		
							
	</body>
</html>


<?php
    require_once("identifier.php");
	require_once("connectiDb.php");

    $idUser=isset($_POST['idu'])?$_POST['idu']:0;
    $login=isset($_POST['login'])?$_POST['login']:"";//les donées sont envoyée par la méthode post

    $email=isset($_POST['email'])?$_POST['email']:"";
    


    
    $requete="update   utilisateur set 	login=?,email=? where idUtilisateur=? ";
    $param=array($login,$email,$idUser);
 
    $resultat = $pdo->prepare($requete);
    $resultat->execute($param);	
	header("location:livre.php");
	
?>
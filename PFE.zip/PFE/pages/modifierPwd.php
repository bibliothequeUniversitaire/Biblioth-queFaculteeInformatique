<?php
    require_once ('identifier.php');
?>

<!DOCTYPE HTML>
<html>
    <head>
<meta charset="utf-8" />
<title>Changement de mot de passe</title>
<link 	rel="stylesheet" 	type="text/css"     href="../css/bootstrap.min.css">
<link 	rel="stylesheet" 	type="text/css"  	href="../css/font-awesome.min.css">
<link 	rel="stylesheet" 	type="text/css" 	href="../css/monstyle.css">
<script src="../js/jquery-3.3.1.js"></script>
<script src="../js/myjs.js"></script>
    </head>
    
    
    
      <body>
                  <style>
body {
  background-image: url('95571686_2695129650770008_1954315548242214912_n.jpg');
}
</style>  
    	<div class="container editpwd-page">
    		<h1 class="text-center" style="color: chocolate">Changement de mot de passe</h1>
    		
    		<h2 class="text-center" style="color: chocolate"> Compte : <?php echo $_SESSION['user']['login'] ?> 	</h2>
    		
    		<form class="form-horizontal" method="post" action="updatePwd.php">
    
    
    			<!-- ***************** start old pwd field  ***************** -->
    &nbsp;&nbsp;&nbsp;
    				<div class="input-container">
    					<input 	
    						minlength=3
    						class="oldpwd form-control" 
    						type="password"
    						name="oldpwd" 
    						autocomplete="new-password"
    						placeholder="Taper votre Ancien Mot de passe" 
    						required> 
    					<i class="show-oldpwd fa fa-eye fa-2x"></i>
    				</div>
    
    
    			<!-- ***************** end old pwd field ***************** -->
    
    
    
    			<!--  ***************** start new pwd field  ***************** -->
    
    &nbsp;&nbsp;&nbsp;
    				<div class="input-container">
    					<input 	
    						minlength=4
    						class=" newpwd form-control" 
    						type="password"
    						name="newpwd" 
    						autocomplete="new-password"
    						placeholder="Taper votre Nouveau Mot de passe" 
    						required
                               > 
    					<i class="show-newpwd fa fa-eye fa-2x"></i>
    				</div>
    
    
    			<!--  *****************  end new pwd field  ***************** -->
    
    			<!--  ***************** start submit field  ***************** -->
       &nbsp;&nbsp;&nbsp;
    					<input 
    						type="submit" 
    						value="Enregistrer"
    						class="btn btn-primary btn-block" style="color: black"/>
    
    			<!--   ***************** end submit field  ***************** -->
    
    		</form>
    	</div>
    
    </body>
</html>




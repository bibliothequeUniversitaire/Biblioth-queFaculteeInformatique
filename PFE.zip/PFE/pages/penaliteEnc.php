<?php
    require_once("identifier.php");
	require_once("connectiDb.php");

     $nomprenomen=isset($_GET['nomprenomEn'])?$_GET['nomprenomEn']:"";
     $numEn=isset($_GET['numEn'])?$_GET['numEn']:"";


 $size=isset($_GET['size'])?$_GET['size']:2;
    $page=isset($_GET['page'])?$_GET['page']:1;
    $offset=($page-1)*$size;

     $requete="select p.idCd,e.idEnseignant,titre,nom,prenom,dateP,dateFp,numCarte,nbrCopie
                 from cd as c,penalite as p,enseignant as e
                 where (c.idCd=p.idCd and p.idEnseignant=e.idEnseignant)
                 
                 and numCarte like '%$numEn%' 
                  
                and (nom like '%$nomprenomen%' or prenom like '%$nomprenomen%')
                 limit $size 
                 offset $offset";
    
    $requeteCount="select count(*) countE from cd as c,penalite as p,enseignant as e
                 where (c.idCd=p.idCd and p.idEnseignant=e.idEnseignant)
                 
                 and numCarte like '%$numEn%' 
                  
                and (nom like '%$nomprenomen%' or prenom like '%$nomprenomen%') ";


$resultatEn=$pdo->query($requete);//execution de la requete
     $resultatCount=$pdo->query($requeteCount);
     $tabCount=$resultatCount->fetch();
     $nbrEnseignant=$tabCount['countE'];
     $reste=$nbrEnseignant % $size; // % operateur modulo:le reste de la division euclidiene de $nbrFiliere par
                               //$size*/
   if($reste==0)//nbrFiliere est un multiple de size
        $nbrPage=$nbrEnseignant/$size;
   else
		$nbrPage=floor($nbrEnseignant/$size)+1;// floor retourne la partie entière d'un nombre 




?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Gestion des pénalités</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>



	</head>
    <body>
       <style>
         body {
             background-image: url('95571686_2695129650770008_1954315548242214912_n.jpg');
              }
       </style>



		<?php include("nouveau.php");?>
      <div class="container" id="padding" >    <!--container permet d'apliquer une marge gauche et droite-->
        <div class="panel panel-info margetop" >
          <div class="panel-heading" id="color" style="color: black">Recherche des enseignant</div>
           <div class="panel-body">
             <form method="get" action="penaliteEnc.php" class="form-inline" >
                <div class="form-group" >
                    &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
                    &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
                    &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
                    &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
                    &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
                <input type="text" name="nomprenomEn" placeholder="Nom ou Prenom" class="form-control" value="<?php echo $nomprenomen?>"/>
                     &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp

                <input id="number"
                       type="number"
                       name="numEn"
                       placeholder="N° carte"
                       class="form-control"
                       value="<?php echo $numEn?>"/>
                </div>


                  &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp

                    <button type="submit" class="btn btn-warning" style="color: black">
                      <span class="glyphicon glyphicon-search" style="color: black"></span>
                        Rechercher...
                  </button>
                    &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
             
                </form>

               </div>
           </div>

           <div class="panel panel-info margetop">
               <div class="panel-heading" id="color" style="color: black">Liste des enseignants pénalisés(<?php echo $nbrEnseignant?> Enseignants)</div>
               <div class="panel-body">
                  <table class="table table-striped table-bordered">
                     <thead>
                        <tr style="color: chocolate">
                           <th >N°enseignant</th><th >Nom enseignant</th><th>Prénom enseignant</th><th>N°Carte</th>
                           <th>N°CD</th><th>Titre</th><th >Date pénalité</th><th>Date fin pénalité</th>
                             <?php if($_SESSION['user']['role']=='ADMIN'){?>
                            <th>Action</th>
                              <?php }?>
                        </tr>
                     </thead>
                     <tbody>

                          <?php while($enseignant=$resultatEn->fetch()){?>
                            <tr class="<?php 
                                  if($_SESSION['user']['role']=='ADMIN'){      
                                  
    
   $dateR=$enseignant['dateFp'];
                                  
                       $dateAuj= date("Y-m-d");
                       $dateA = date_create($dateAuj);                  
                       $dateR = date_create($dateR); 
                             $Auj= date_timestamp_get($dateA);
                             $d= date_timestamp_get($dateR);         
                                      
                                  
                                        if($Auj>=$d)
                                        echo 'success' ;       
                                  }
    
    
                                        ?>">
                              <td><?php echo $enseignant['idEnseignant']?></td>
                              <td><?php echo $enseignant['nom']?></td>
                              <td><?php echo $enseignant['prenom']?></td>
                             <td ><?php echo $enseignant['numCarte']?></td>
                             <td ><?php echo $enseignant['idCd']?></td>
                             <td ><?php echo $enseignant['titre']?></td>
                             <td ><?php echo $enseignant['dateP']?></td>
                              <td ><?php echo $enseignant['dateFp']?></td>     
                                <?php if($_SESSION['user']['role']=='ADMIN'){?>
                             
                             <td>
                            
                                  &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
                                  <a onclick="return confirm('Etes vous sure de vouloire supprimer cette punition' )"
                                     href="supprimerPenEnC.php?idcen=<?php echo $enseignant['idCd']?>
                                         &iden=<?php echo $enseignant['idEnseignant']?>  
                                   &nbrEn=<?php echo $enseignant['nbrCopie']?>"><span class="glyphicon glyphicon-trash" style="color: #994d00"></span></a>
                              </td>
                        <?php }?> 
                            </tr>
                <?php }?>


                     </tbody>
                   </table>
                   <div>

                     <ul class="pagination">

							<?php for($i=1;$i<=$nbrPage;$i++){ ?>
				              <li class="<?php if($i==$page) echo 'active' ?> ">

								<a  href="penaliteEnc.php?page=<?php echo $i ?>&nomprenomEn=<?php echo $nomprenomen?>">


										 <?php echo $i ?>
									</a>
								</li>
							<?php } ?>
						</ul>


                   </div>
               </div>
           </div>
    </div>
    </body>
</html>
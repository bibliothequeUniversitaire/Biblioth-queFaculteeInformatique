<?php
    require_once("identifier.php");
	require_once("connectiDb.php");
    $idUser=isset($_GET['id'])?$_GET['id']:0;
    $requeteUser="select * from utilisateur where idUtilisateur= $idUser";
    $resultatUser=$pdo->query($requeteUser);
    $user=$resultatUser->fetch();


    $login=$user['login'];
    $email=$user['email'];
    $role=strtoupper($user['role']);//majiscule
    
    
?>


<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Edition d'un utilisateur</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
	</head>
	<body>
		<?php include("nouveau.php");?>
    <div class="container">
	 <div style="background-color:lightbrown"  class="panel panel-primary margetop" >
      <div class="panel-heading" id="color" style="color: black">Edition de l'utilisateur</div>
       <div class="panel-body">
        <form method="post" action="updateUser.php" class="form" >
         <div class="form-group" >
          <label for="idu">ID : <?php echo $idUser ?></label>  
          <input type="hidden" name="idu"  class="form-control" value="<?php echo $idUser ?>"/>
         </div>   
                        
         <div class="form-group" >
          <label for="login">Login:</label>  
          <input type="text" 
				 name="login" 
                 plceholder="Login"
                 class="form-control" 
                 value="<?php echo $login ?>"/>
         </div>   
                        <!-------->
         <div class="form-group" >
          <label for="email">Email:</label>  
           <input type="text" 
				  name="email" 
                  plceholder="Email"
                  class="form-control" 
                  value="<?php echo $email ?>"/>
         </div>   
                        
                         <!------->
         <div class="form-group" >
          <label for="role">Role:</label>
           <select name="role" class="form-control">
            <option value="ADMIN" <?php if($role=="ADMIN") echo "selected"?>>Administrateur</option>
            <option value="VISITEUR" <?php if($role=="VISITEUR") echo "selected"?>>Visiteur</option>
           </select>
         </div> 
			             <!------->
         <button type="submit" class="btn btn-warning" style="color: black">
           <span class="glyphicon glyphicon-save" style="color: black"></span>
            Enregistrer
         </button>
			
         &nbsp;&nbsp;
			
         <!--pour changer le mot de passe -->
         <a href="modifierPwdAdmin.php?idu=<?php echo $idUser?>" style="color: black">Changer le mot de pase</a>
       </form>
      </div> 
     </div>
    </div>
  </body>
</html>
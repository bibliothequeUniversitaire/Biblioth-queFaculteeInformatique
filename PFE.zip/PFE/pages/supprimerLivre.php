<?php
   session_start();
  if(isset($_SESSION['user'])){//utilisateur connecter
	require_once("connectiDb.php");
	
	
	$idl=$_GET['idl'];

	$requete="delete from livre where idLivre=?";			
	$param=array($idl);	
	$resultatL = $pdo->prepare($requete);
    $resultatL ->execute($param);	
	header("location:livre.php");
      }else{//si l'utilisateur n'est pa authentifier
      header("location:login.php");
  }
	
?>
<meta charset="utf-8" />
    
<?php
    require_once("identifier.php");
	require_once("connectiDb.php");
     
     $titrel=isset($_GET['titreL'])?$_GET['titreL']:"";
     $nomprenoml=isset($_GET['nomprenomL'])?$_GET['nomprenomL']:"";
     $auteurl=isset($_GET['auteurL'])?$_GET['auteurL']:"";
     
    $sizeE=isset($_GET['size'])?$_GET['size']:2;
    $pageE=isset($_GET['page'])?$_GET['page']:1;
    $offsetE=($pageE-1)*$sizeE;
     $requeteE="select  r.idLivre,e.idEtudiant,auteur,titre,idReservation,nom,prenom,dateRes,dateFinRes,nbrCopie
                 from livre as l,reserver as r,etudiant as e
                 where (l.idLivre=r.idLivre and r.idEtudiant=e.idEtudiant)
                 
                 and titre like '%$titrel%' 
                 and auteur like '%$auteurl%' 
                 and (nom like '%$nomprenoml%' or prenom like '%$nomprenoml%')
                 limit $sizeE 
                 offset $offsetE";
$requeteCountE="select count(*) countL from livre as l,reserver as r,etudiant as e
                 where (l.idLivre=r.idLivre and r.idEtudiant=e.idEtudiant)
                 and titre like '%$titrel%' 
                 and auteur like '%$auteurl%'
                 and (nom like '%$nomprenoml%' or prenom like '%$nomprenoml%')
                 ";
$resultatE=$pdo->query($requeteE);//execution de la requete


     $resultatCountE=$pdo->query($requeteCountE);
     $tabCountE=$resultatCountE->fetch();
     $nbrLivreE=$tabCountE['countL'];
     $resteE=$nbrLivreE % $sizeE; // % operateur modulo:le reste de la division euclidiene de $nbrFiliere par
                               //$size
   if($resteE==0)//nbrFiliere est un multiple de size
        $nbrPageE=$nbrLivreE/$sizeE;
   else
		$nbrPageE=floor($nbrLivreE/$sizeE)+1;// floor retourne la partie entière d'un nombre 
										// decimale
	


    
?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Gestion des prets</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

		
        
	</head>
    <body>
        <?php include("nouveau.php");?>
       <style>
         body {
             background-image: url('95571686_2695129650770008_1954315548242214912_n.jpg');
              }
       </style>    
		
      <div class="container ">    <!--container permet d'apliquer une marge gauche et droite-->
        <div class="panel panel-info margetop" id="padding">
          <div class="panel-heading" id="color" style="color: black">Recherche des Reserver</div>
           <div class="panel-body">
             <form method="get" action="livreReserverEt.php" class="form-inline" >
                <div class="form-group" >
                <input type="text" name="titreL" placeholder="Titre du livre" class="form-control" value="<?php echo $titrel?>"/>
                    &nbsp &nbsp
                    <input type="text" name="auteurL" placeholder=" Auteur " class="form-control" value="<?php echo $auteurl?>"/>
                    &nbsp &nbsp
                     <input type="text" name="nomprenomL" placeholder="Nom Prenom étudiant" class="form-control" value="<?php echo $nomprenoml?>"/>
                 </div> 
                 
                 
                 
                 &nbsp &nbsp
                    <button type="submit" class="btn btn-warning" style="color: black">
                      <span class="glyphicon glyphicon-search" style="color: black"></span>
                        Rechercher...
                  </button>
                    
                  
                </form>    
               
               </div>
           </div>
        
           <div class="panel panel-info margetop">
               <div class="panel-heading" id="color" style="color: black">Liste des Reservation des étudiants(<?php echo $nbrLivreE?> Livres)</div>
               <div class="panel-body">
                  <table class="table table-striped table-bordered">
                     <thead>
                        <tr style="color: chocolate">
                       <th >N°livre</th><th>N°Réservation</th><th >Titre</th><th>Auteur</th>
                           <th>N°Lecteur</th><th>Nom étudiant</th>
                            <th>Prénom étudiant</th>
                            <th>Date Reservation</th><th>Date Fin Reservation</th>
                             <?php if($_SESSION['user']['role']=='ADMIN'){?> 
                            <th>Action</th>
                            <?php }?>
                        </tr>
                     </thead>          
                     <tbody>
                        
                          <?php while($livre=$resultatE->fetch()){?>   
                            <tr  class="<?php 
                                  if($_SESSION['user']['role']=='ADMIN'){      
                                $dateR=$livre['dateFinRes'];
                                  
                       $dateAuj= date("Y-m-d");
                       $dateA = date_create($dateAuj);                  
                       $dateR = date_create($dateR); 
                             $Auj= date_timestamp_get($dateA);
                             $d= date_timestamp_get($dateR);         
                                      
                                  
                                        if($Auj>=$d)
                                        echo 'danger' ; 
                                        
                                  }
                                 
                                        ?>">
                              <td><?php echo $livre['idLivre']?></td>
                              <td><?php echo $livre['idReservation']?></td>
                              <td><?php echo $livre['titre']?></td>
                              <td><?php echo $livre['auteur']?></td>
                              
                              <td><?php echo $livre['idEtudiant'] ?></td>
                              <td><?php echo $livre['nom'] ?></td> 
                              <td><?php echo $livre['prenom'] ?></td> 
                              <td><?php echo $livre['dateRes']?></td>    
                              <td><?php echo $livre['dateFinRes']?></td> 
                               
                                
                                
                                
                             
                                
                                
                            <?php if($_SESSION['user']['role']=='ADMIN'){?> 
                              <td >
                                  &nbsp &nbsp  
                            <a onclick="return confirm('Etes vous sure de vouloire supprimer Cette Reservation' )"
                               href="supprimerReserverEtL.php?idlet=<?php echo $livre['idLivre']?>&idet=<?php echo $livre['idEtudiant']?>&nbr=<?php echo $livre['nbrCopie']?>
                                     
                                 &idRes=<?php echo $livre['idReservation']?>    
                                     
                                     "><span class="glyphicon glyphicon-trash" style="color: #994d00"></span>
                                  
                              </a>    
                                 
                                  
                                  
                                  
                                  
                                  
                                  
                                  
                                  
                                  
                                  
                                  
                              </td>    
                                <?php }?>  
                            </tr>
                          <?php }?>    
                     </tbody>    
                   </table>   
                      
               </div>
               
          </div>
        
         <div>
                   
                     <ul class="pagination" >
							
							<?php for($i=1;$i<=$nbrPageE;$i++){ ?>
				              <li class="<?php if($i==$pageE) echo 'active' ?>">

								<a href="livreReserverEt.php?page=<?php echo $i ?>&titreL=<?php echo $titrel?>">	
										 <?php echo $i ?>
									</a>
								</li>
							<?php } ?>	
						</ul>
                   
                   
                   </div>
        
        
        
        
        
        
        
        
        
        
          <!-------------->
         
          <!----------->
    </div>    
    </body>
</html>    
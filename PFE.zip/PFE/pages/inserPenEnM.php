<?php
   session_start();
  if(isset($_SESSION['user'])){//utilisateur connecter
	require_once("connectiDb.php");
	
	
	$idmen=$_GET['idmen'];
	$iden=$_GET['iden'];
    
      $dateP= date("Y-m-d");
    $dateFp=date('Y-m-d', strtotime($dateP. ' + 7 days'));

	$requete="insert into     penalite(idmemoire,idEnseignant,dateP,dateFp) values(?,?,?,?)";    
   $param=array($idmen,$iden,$dateP,$dateFp);

    $resultat = $pdo->prepare($requete);
    $resultat->execute($param);
      
      
      
      
	header("location:memoirePretEn.php");
      }else{//si l'utilisateur n'est pa authentifier
      header("location:login.php");
  }
	
?>
<meta charset="utf-8" />
    
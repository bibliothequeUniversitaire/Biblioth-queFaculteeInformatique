<?php
session_start();
  if(isset($_SESSION['user'])){//utilisateur connecter
	require_once("connectiDb.php");
	
	$idm=$_GET['idm'];

	$requete="delete from memoire where idmemoire=?";			
	$param=array($idm);	
	$resultatM = $pdo->prepare($requete);
    $resultatM ->execute($param);	
	header("location:memoire.php");
      }else{//si l'utilisateur n'est pa authentifier
      header("location:login.php");
  }
	
?>
    
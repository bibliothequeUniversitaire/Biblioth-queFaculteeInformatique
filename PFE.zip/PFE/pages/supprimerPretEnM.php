<?php
   session_start();
  if(isset($_SESSION['user'])){//utilisateur connecter
	require_once("connectiDb.php");
	
	
	$idmen=$_GET['idmen'];
	$iden=$_GET['iden'];
    $nbr=$_GET['nbrEn'];
    $idEmprr=$_GET['idEmprr'];
      
    
      
	$requete="delete from emprunt where idmemoire=? and idEmrunt=?";			
	$param=array($idmen,$idEmprr);	
	$resultatM = $pdo->prepare($requete);
    $resultatM ->execute($param);	
      $nbr=$nbr+1; 
      ////////////////////
      
      $requetenbr="update memoire set nbrCopie='$nbr' where idmemoire='$idmen';";    
   $paramm=array($nbr);

    $resultatnbr = $pdo->prepare($requetenbr);
    $resultatnbr->execute($paramm);
      
      
      
	header("location:memoirePretEn.php");
      }else{//si l'utilisateur n'est pa authentifier
      header("location:login.php");
  }
	
?>
    
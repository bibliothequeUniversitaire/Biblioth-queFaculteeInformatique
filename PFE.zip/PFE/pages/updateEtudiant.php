

<?php
    require_once("identifier.php");
	require_once("connectiDb.php");

    $idE=isset($_POST['ide'])?$_POST['ide']:0;
    $nom=isset($_POST['nom'])?$_POST['nom']:"";//les donées sont envoyée par la méthode post

    $prenom=isset($_POST['prenom'])?$_POST['prenom']:"";//les donées sont envoyée par la méthode post
    $numCarte=isset($_POST['numCarte'])?$_POST['numCarte']:"";
    $cevilite=isset($_POST['cevilite'])?$_POST['cevilite']:"";
    $niveau=isset($_POST['niveau'])?$_POST['niveau']:"";

    
    
 
 
    $requete="update  etudiant set 	nom=?,prenom=?,numCarte=?,cevilite=?,niveau=? where idEtudiant=? ";
    $param=array($nom,$prenom,$numCarte,$cevilite,$niveau,$idE);
    $resultat = $pdo->prepare($requete);
    $resultat->execute($param);	
	header("location:etudiant.php");
	
?>
<meta charset="utf-8" />
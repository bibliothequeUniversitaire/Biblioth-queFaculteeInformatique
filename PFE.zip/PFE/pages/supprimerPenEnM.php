<?php
   session_start();
  if(isset($_SESSION['user'])){//utilisateur connecter
	require_once("connectiDb.php");
	
	
	$idmen=$_GET['idmen'];
	$iden=$_GET['iden'];
    $nbr=$_GET['nbrEn'];
      
	$requete="delete from penalite where idmemoire=? and idEnseignant=?";			
	$param=array($idmen,$iden);	
	$resultatL = $pdo->prepare($requete);
    $resultatL ->execute($param);
      $nbr=$nbr+1; 
      
      /////////////////////////
      $requetenbr="update memoire set nbrCopie='$nbr' where idmemoire='$idmen';";    
   $paramm=array($nbr);

    $resultatnbr = $pdo->prepare($requetenbr);
    $resultatnbr->execute($paramm);
      
      
      
      
	header("location:penaliteEnm.php");
      }else{//si l'utilisateur n'est pa authentifier
      header("location:login.php");
  }
	
?>
    
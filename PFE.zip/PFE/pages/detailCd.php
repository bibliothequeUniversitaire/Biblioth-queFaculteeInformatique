<?php

   require_once("identifier.php");
 
	require_once("connectiDb.php");
    $idC=isset($_GET['idc'])?$_GET['idc']:0;
    $requete="select * from cd where idCd= $idC";
    $resultat=$pdo->query($requete);
    $cd=$resultat->fetch();
    
    $titre=$cd['titre'];
    $nbr=$cd['nbrCopie'];
    $etudiant=$cd['etudiant'];
    $encadreur=$cd['encadreur'];
    $annee=$cd['anneeEdition'];
    $edition=$cd['edition'];
    
    $description=$cd['description'];
    $categorie=$cd['categorie'];
        
?>


<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Détail du cd</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		
        <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
	</head>
	<body>
        
	<?php include("nouveau.php");?>
    <div class="container">
			
        <div style="background-color:lightbrown"  class="panel panel-primary margetop" >
               
           <div class="panel-heading"  id="color" style="color: black">Détail du cd</div>
           <div class="panel-body">
                    
           <form method="post" action="cd.php" class="form" enctype="multipart/form-data" ><!--enctype pour l'envoi d'un fichier-->
                
               
               <div class="form-group" >
                   <label for="idl"><font color="chocolate">N°CD:</font> <?php echo $idC ?></label>  
                    <input type="hidden" name="idm"  class="form-control" value="<?php echo $idC ?>"/>
                </div>   
                        
                <div class="form-group" >
                    <label><font color="chocolate">Titre :</font> <?php echo $titre ?></label>  
                    <input type="hidden" name="titre" 
                       class="form-control" 
                       value="<?php echo $titre ?>"/>
                </div>   
                        <!---->
                <div class="form-group" >
                    <label><font color="chocolate">Etudiant: </font><?php echo $etudiant ?></label>  
                    <input type="hidden" name="auteur" 
                       class="form-control" 
                       value="<?php echo $etudiant ?>"/>
                </div>  
               
               <!---->
                <!---->
                <div class="form-group" >
                    <label><font color="chocolate">Encadreur: </font><?php echo $encadreur ?></label>  
                    <input type="hidden" name="auteur" 
                       class="form-control" 
                       value="<?php echo $encadreur ?>"/>
                </div>  
               
               <!---->
               <div class="form-group" >
                    <label><font color="chocolate">Catégorie : </font><?php echo $categorie?></label>  
                    <input type="hidden" name="categorie" 
                       class="form-control" 
                       value="<?php echo $categorie ?>"/>
                </div> 
               <!---->
               
               
          
                <div class="form-group" >
                    <label><font color="chocolate">Maison edition: </font><?php echo $edition ?></label>  
                    <input type="hidden" name="edition" 
                       class="form-control" 
                       value="<?php echo $edition ?>"/>
                </div> 
               

               
               
                        <!---->
              
               <div class="form-group" >
                    <label><font color="chocolate">Année edition: </font><?php echo $annee ?></label>  
                    <input type="hidden" name="maison" 
                       class="form-control" 
                       value="<?php echo $annee ?>"/>
                </div>
               <!---->
               
                 <div class="form-group" >
                    <label><font color="chocolate">Nombre de copie: </font><?php echo $nbr ?></label>  
                    <input type="hidden" name="nbr" 
                       class="form-control" 
                       value="<?php echo $nbr ?>"/>
                </div>
                    
               <!---->
                 <div class="form-group" >
                    <label><font color="chocolate">Description : </font><?php echo $description ?></label>  
                    <input type="hidden" name="nbr" 
                       class="form-control" 
                       value="<?php echo $description ?>"/>
                </div>                  
             <!---->
                  
              
                  <button type="submit" class="btn btn-warning" style="color: black" >
                      <span class="glyphicon glyphicon-share" style="color: black"></span>
                        Retour
                      
                  </button> 
             
                      
                    </form>
                    
                    
                    
                    
                </div> 
                    
                    
                </div>
        </div>
        
		
							
	</body>
</html>
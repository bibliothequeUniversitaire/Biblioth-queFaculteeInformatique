<?php require_once("identifier.php");?>


<!DOCTYPE html>
<head>
  <title>Mon menu</title>
	<meta charset="utf-8" />
   <link href="../css/nouveau.css" rel="stylesheet">
   <link href="../css/bootstrap.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-sm bg-info navbar-dark">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Bibliothèque</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a>Bibliotheque</a>
        <li><a>Ouvrages</a>
            <ul>
               <li><a href="livre.php">Livres</a></li>
               <li><a class="nav-link active" class="memoire.php">Memoires</a></li>
               <li><a href="cd.php">Cds</a></li>
            </ul>
        </li>
        <li><a>Lecteurs</a>
            <ul>
              <li><a href="enseignant.php">Enseignants</a></li>
              <li><a href="etudiant.php">Etudients</a></li>
            </ul>
       </li>
       <li><a href="utilisateurs.php">Utilisateurs</a></li>
       <li><a href="pret.php">Pret</a></li>
       <li><a href="reserver.php">Preserver</a></li>
       <li>
          <a href="editerUser.php?id=<?php echo $_SESSION['user']['idUtilisateur'];?>"><span class="glyphicon glyphicon-user"></span> 
            <?php echo $_SESSION['user']['login'];?>
          </a>
        </li>
       <li><a href="seDeconnecter.php"><i class="glyphicon glyphicon-log-out"></i>Se deconnecter</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
         
        <li>
          <a href="editerUser.php?id=<?php echo $_SESSION['user']['idUtilisateur'];?>"><span class="glyphicon glyphicon-user"></span> 
            <?php echo $_SESSION['user']['login'];?>
          </a>
        </li>
           
         <li><a href="seDeconnecter.php"><i class="glyphicon glyphicon-log-out"></i>&nbsp; Se déconnecter</a></li>
         </ul>
      
      
      
      
      
      
      
      
      
  </div>
</nav>
  


</body>
</html>

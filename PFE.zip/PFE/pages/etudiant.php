<?php
    require_once("identifier.php");
	require_once("connectiDb.php");
     
     $nomprenome=isset($_GET['nomprenomE'])?$_GET['nomprenomE']:"";
     $nume=isset($_GET['numE'])?$_GET['numE']:"";
     $niveau=isset($_GET['niveau'])?$_GET['niveau']:"all";
     

     


 $size=isset($_GET['size'])?$_GET['size']:6;
    $page=isset($_GET['page'])?$_GET['page']:1;
    $offset=($page-1)*$size;


if($niveau=="all"){
     $requete="select * from etudiant
                   where (nom like '%$nomprenome%' or prenom like '%$nomprenome%')
                   and numCarte like '%$nume%' 
                  
                   limit $size offset $offset";
     $requeteCount="select count(*) countE from etudiant 
               where (nom like '%$nomprenome%' or prenom like '%$nomprenome%')
              and numCarte like '%$nume%' ";
}else{
    
      $requete="select * from etudiant
                    where (nom like '%$nomprenome%' or prenom like '%$nomprenome%')
                   and numCarte like '%$nume%' 
                   and niveau='$niveau'
                   
                   limit $size offset $offset";
    
     $requeteCount="select count(*) countE from etudiant 
              where (nom like '%$nomprenome%' or prenom like '%$nomprenome%')
              and numCarte like '%$nume%' 
                   and niveau='$niveau'";
   
}

     $resultatE=$pdo->query($requete);//execution de la requete
     $resultatCount=$pdo->query($requeteCount);
     $tabCount=$resultatCount->fetch();
     $nbrEtudiant=$tabCount['countE'];
     $reste=$nbrEtudiant % $size; // % operateur modulo:le reste de la division euclidiene de $nbrFiliere par
                               //$size
   if($reste==0)//nbrFiliere est un multiple de size
        $nbrPage=$nbrEtudiant/$size;
   else
		$nbrPage=floor($nbrEtudiant/$size)+1;// floor retourne la partie entière d'un nombre 
										// decimale
	

      
?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Gestion des etudiants</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

		
        
	</head>
    <body>
       <style>
         body {
             background-image: url('95571686_2695129650770008_1954315548242214912_n.jpg');
              }
        #header{
          background-color: maroon;
      }
      #container{
          background-color: moccasin;
      }
       </style>    
        
        
		<?php include("nouveau.php");?>
      <div class="container ">    <!--container permet d'apliquer une marge gauche et droite-->
        <div class="panel panel-info margetop" id="padding">
          <div class="panel-heading" id="color" style="color: black">Recherche des étudiants</div>
           <div class="panel-body">
             <form method="get" action="etudiant.php" class="form-inline" >
                <div class="form-group" >
                    
                    &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
                    &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
                    &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
                <input type="text" name="nomprenomE" placeholder="Nom ou Prenom" class="form-control" value="<?php echo $nomprenome?>"/>
                    
                 
                <?php if($_SESSION['user']['role']=='ADMIN'){?> 
                 &nbsp &nbsp
                <input id="number" 
                       type="number"    
                       name="numE" 
                       placeholder="N° carte" 
                       class="form-control"
                       value="<?php echo $nume?>"/>
                    <?php }?>
                </div> 
                 
                 
                 
                 &nbsp &nbsp
                 
                 &nbsp &nbsp
                 <label for="niveau">Niveau:</label>
                  &nbsp &nbsp
                <select name="niveau" class="form-control" id="niveau" onchange="this.form.submit()"><!--this.from.submit() evenement de js-->
                  <option value="all"<?php if($niveau==="all") echo "selected"?>>Tous les niveaux</option>
                    
                  <option value="l2"<?php if($niveau==="l2") echo "selected"?>>Licence 2</option>
                    
                  <option value="l3"<?php if($niveau==="l3") echo "selected"?>>Licence 3</option>
                    
                  <option value="m1"<?php if($niveau==="m1") echo "selected"?>>Master 1</option>
                    
                  <option value="m2"<?php if($niveau==="m2") echo "selected"?>>Master 2</option>
                    
                    
                     </select>
                 
                 
                 
                 
                 
                 
                 &nbsp &nbsp
                    <button type="submit" class="btn btn-warning" style="color: black">
                      <span class="glyphicon glyphicon-search" style="color: black"></span>
                        Rechercher...
                  </button>
                    &nbsp &nbsp
                    <?php if($_SESSION['user']['role']=='ADMIN'){?>
                    <a href="nouveauEtudiant.php" style="color: black" ><span class="glyphicon glyphicon-plus" style="color: black"></span>
                      Nouveau étudiant</a>
                 <?php }?>
                </form>    
               
               </div>
           </div>
        
           <div class="panel panel-info margetop" style="color: black">
               <div class="panel-heading" id="color" style="color: black">Liste des etudiants (<?php echo $nbrEtudiant?> Etudiants)</div>
               <div class="panel-body">
                  <table class="table table-striped table-bordered">
                     <thead>
                        <tr style="color: chocolate">
                           <th >N° etudiant</th><th>Nom</th><th>Prenom</th><th>Niveau</th>
                        <?php if($_SESSION['user']['role']=='ADMIN'){?>    
                            <th>N° carte</th>
                            <th >Action</th>
                           <?php }?> 
                        </tr>
                     </thead>          
                     <tbody>
                        
                          <?php while($etudiant=$resultatE->fetch()){?>   
                            <tr>
                              <td><?php echo $etudiant['idEtudiant']?></td>
                              <td><?php echo $etudiant['nom']?></td>
                              <td><?php echo $etudiant['prenom']?></td>
                             <td><?php echo $etudiant['niveau']?></td>
                    <?php if($_SESSION['user']['role']=='ADMIN'){?>            
                              <td><?php echo $etudiant['numCarte']?></td>
                              <td>
                                <a href="editerEtudiant.php?ide=<?php echo $etudiant['idEtudiant']?>"><span class="glyphicon glyphicon-edit"style="color: #994d00"></span></a>
                                  &nbsp &nbsp
                                  <a onclick="return confirm('Etes vous sure de vouloire supprimer ce etudiant' )"
                                     href="supprimerEtudiant.php?ide=<?php echo $etudiant['idEtudiant']?>"><span class="glyphicon glyphicon-trash"style="color: #994d00"></span></a>  
                              </td>    
                           <?php }?>   
                                
                            </tr>
                          <?php }?>    
                        
                      
                     </tbody>    
                   </table>   
                   <div>
                   
                     <ul class="pagination">
							
							<?php for($i=1;$i<=$nbrPage;$i++){ ?>
				              <li class="<?php if($i==$page) echo 'active' ?>">

								<a href="etudiant.php?page=<?php echo $i ?>&nomprenomE=<?php echo $nomprenome?>">

										
										 <?php echo $i ?>
									</a>
								</li>
							<?php } ?>	
						</ul>
                   
                   
                   </div>    
               </div>
           </div>
    </div>    
    </body>
</html>    
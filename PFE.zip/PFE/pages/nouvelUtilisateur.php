
<?php
	require_once('connectiDb.php');//si le fichier est chargée à la mémoire il le recharge pas 
	
	include '../fonctions/fonctions.php'; 

//en utilise la méthode post pour encapsuler le code php avec un controle de la méthode utilisé 	
	if ($_SERVER['REQUEST_METHOD'] == 'POST') {//serveur c'est une variable globale 
//ce code est accecible uniquement via l'accé POST décloncher par le formulaire  si en accède à cette page via GET url on aura pas l'accé à ce code 
        
        
        
        
//pour ne pas créer plusieure variables de message d'erreur on déclare un tableau qui va permet de stocker   tous les messages d'erreur       
		$validationErrors = array();
		
		$login = $_POST['login'];
		
		$pwd1 = $_POST['pwd1'];
		
		$pwd2 = $_POST['pwd2'];
		
		$email = $_POST['email'];
//vérification si le login respecte les conditions de login
			if (isset($login)) {//si le login n'est pas vide 
//filter_var c'ets une fonction qui permet de vérifier le contenu d'une variable 		
//FILTER_SANITIZE_STRING permet de supprimer les balises et supprime ou encode les caravtères spéciaux                 
				$filtredLogin = filter_var($login, FILTER_SANITIZE_STRING);
//$filtredLogin c'est le login filtrer c-à-d suppressions des balises ...			
                
//vérification de la taille par la fonction strlen qui permet de vérifier la taille                 
				if (strlen($filtredLogin) < 4) {
	//$validationErrors[] c'est une case du tableau 				
					$validationErrors[] = "Erreur de validation: Le login doit contenir au moins 4 caractères";
				
				}
			}
//isset c'est différent du vide 
			if (isset($pwd1) && isset($pwd2)) {
//empty retourne true si la variable est vide et false si la variable n'est pas vide 				
				if (empty($pwd1)) {
					
					$validationErrors[] = "Erreur de validation: Le mot ne doit pas être vide!";
				}
//md5 fonction qui permet de crypter un pwd
				if (md5($pwd1) !== md5($pwd2)) {
					
					$validationErrors[] = "Erreur de validation: Les deux mots de passe ne sont pas identiques";
				}
			}
//pour controler la validation du l'email
			if (isset($email)) {
//FILTER_SANITIZE_EMAIL	c'est une fonction qui permet de supprimer	tous les caractères sauf les lettre,chifre et !#$%&*+-=?^_'{|}@.[]		
				$filtredEmail = filter_var($email, FILTER_SANITIZE_EMAIL);
                
            //si l'email est valide 
				if (filter_var($filtredEmail, FILTER_VALIDATE_EMAIL) != true) {
					
					$validationErrors[] = "Erreur de validation: Email non valid";
					
				}
			}
		
//si le tableau est vide avec la fonction empty
		if (empty($validationErrors)) {
//vérification de l'unucité de l'utilisateur si le nom d'utilisateur est unique la meme chose pou l'email			
            
//vérifier si on a pas deux utilisateur avec le mm pwd et login             
			if (findUserByLogin($login) == 0 && findUserByEmail($email) == 0) {
//déclaration des paramètre :plogin				
				$stmt = $pdo->prepare('INSERT INTO utilisateur(login, pwd,role, email,etat)
                
										VALUES (:pLogin,:pPwd,:pRole, :pEmail,:pEtat)');
										
				$stmt->execute(array(
						'pLogin' 	=> $login,
						'pPwd' 		=> md5($pwd1),
						'pRole'		=>'VISITEUR',
						'pEmail' 	=> $email,
						'pEtat'		=>0)
				);
				
				$succesMsg = "Félicitation , vous avez créer votre nouveau compte";
				
			} else if(findUserByLogin($login) >0){

				$validationErrors[] = 'Désolé ce login existe déja';
				
			}else if(findUserByEmail($email) >0){

				$validationErrors[] = 'Désolé cet Email existe déja';
			}

		}
	}
	
	
?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		
		<title>Nouvel utilisateur</title>
		
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		
		<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
		
		<script src="../js/jquery-3.3.1.js"></script>
		
		<script src="../js/myjs.js"></script>
		
	</head>
	<body>		
		 
		<div class="container user-page">
			<h1 class="text-center">
        		Créer un nouveau compte
    		</h1>
			<form method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>">			
										
				<div class="input-container">
					<input
							pattern=".{4,}"
							title="Le login doit contenir au moins 4 caractères"
							class="form-control"
							type="text"
							name="login"
							autocomplete="off"
							placeholder="Taper votre Login"
							required="required">
				</div>
				<div class="input-container">
					<input
							minlength=4
							class="form-control"
							type="password"
							name="pwd1"
							autocomplete="new-password"
							placeholder="Taper votre mot de passe"
							required>
				</div>
				<div class="input-container">
					<input
							minlength=4
							class="form-control"
							type="password"
							name="pwd2"
							autocomplete="new-password"
							placeholder="Retaper votre mot de passe pour le confirmer"
							required>
				</div>
				<div class="input-container">
					<input
							class="form-control"
							type="email"
							name="email"
							placeholder="Taper votre Email">
				</div>
				<input
						class="btn btn-success btn-block"
						type="submit"
						value="Enregistere">
			</form>
			
			 <div class="the-errors text-center">
			 
				<?php
//pour afficher les messages d'erreur	
    
    
//controler si le tableau existe et il contient des éléments     
					if (isset($validationErrors) && !empty($validationErrors)) {
//la boucle foreach c'est une dériver de la boucle for permet de parcourir une colection un ensemble d'objet,d'elements du premier jusqu'au dernier et d'executé un morceau de code pour chaque élément donc en va parcourir le tableau d'erreur  àa chaque fois si il y aun message d'erreur on va l'afficher 	    
						foreach ($validationErrors as $error) {
						    
							echo '<div class="msg error">' . $error . '</div>';
							
						}
					}

					if (!empty($succesMsg)) {
						
						echo '<div class="msg succes">' . $succesMsg . '</div>';

						header("refresh:3;url=formulaireLecteur.php");
						
						exit();
					}

				
				?>
				
			</div>
							
		</div>		
			
	</body>

</html>




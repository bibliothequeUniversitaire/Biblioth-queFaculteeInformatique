<?php

   require_once("identifier.php");
 
	require_once("connectiDb.php");
    $idM=isset($_GET['idm'])?$_GET['idm']:0;
    $requete="select * from memoire where idmemoire= $idM";
    $resultat=$pdo->query($requete);
    $memoire=$resultat->fetch();
    $_SESSION['idm']=$idM;
    $titre=$memoire['titre'];
    $nbr=$memoire['nbrCopie'];
    $etudiant=$memoire['etudiant'];
    $datePret= date("Y-m-d");
    $dateRetourEn=date('Y-m-d', strtotime($datePret. ' + 30 days'));
    $dateRetourE=date('Y-m-d', strtotime($datePret. ' + 15 days'));
    
  $_SESSION['dateP']=$datePret;
  $_SESSION['dateREn']=$dateRetourEn;
  $_SESSION['dateRE']=$dateRetourE;
        
?>


<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Formulaire pret mémoire</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
        
	</head>
	<body>
	<?php include("nouveau.php");?>
    <div class="container">
			
        <div style="background-color:lightbrown"  class="panel panel-primary margetop" >
               <?php if($nbr>=1){ ?> 
           <div class="panel-heading"  id="color" style="color: black">formulaire Pret des mémoires</div>
           <div class="panel-body">
                    
           <form method="post" action="insertMpret.php" class="form" enctype="multipart/form-data" ><!--enctype pour l'envoi d'un fichier-->
                
               
               <div class="form-group" >
                    <label for="idm">N°mémoire: <?php echo $idM ?></label>  
                    <input type="hidden" name="idm"  class="form-control" value="<?php echo $idM ?>"/>
                </div>   
                        
                <div class="form-group" >
                    <label >Titre : <?php echo $titre ?></label>  
                    <input type="hidden" name="titre" 
                       class="form-control" 
                       value="<?php echo $titre ?>"/>
                </div>   
                        <!---->
                <div class="form-group" >
                    <label  >Auteur: <?php echo $etudiant ?></label>  
                    <input type="hidden" name="etudiant" 
                       class="form-control" 
                       value="<?php echo $etudiant ?>"/>
                </div>  
               
               <!---->
               
          
                <div class="form-group" >
                     <label >Date Pret:  <?php echo $datePret ?></label>   
                            <input type="hidden" 
                            name="datePret" placeholder="datePret"            class="form-control" />
                </div>
               
               <!---->
               
         <label >Date Retoure: </label>     
               
<input type="radio" name="typee" value="<?php  echo $dateRetourEn?>" id="en" onclick="enn()" required>Enseignant
               
               &nbsp;
<input type="radio" name="typee" value="<?php  echo $dateRetourE?>" id="et" onclick="ett()"  >Etudiant





<p id="demo"></p>

    

<p id="demo"></p>

<script>
function ett() {
  var x = document.getElementById("et").value;
  document.getElementById("demo").innerHTML = x;
}
</script>        
            <script>
function enn() {
  var x = document.getElementById("en").value;
  document.getElementById("demo").innerHTML = x;
}
</script>          
               
               
                        <!---->
              
               
               
               
                 <div class="form-group" >
                           <label>N°carte :</label>   
                           <input type="number" name="numcarte" placeholder="Numero Lecteur:" class="form-control" required="required"
                            title="ce champ est vide "/>
                 </div> 
                        
               
               
               
               
               
                        
                  <button type="submit" class="btn btn-warning" style="color: black">
                      <span class="glyphicon glyphicon-save" style="color: black"></span>
                        Enregistrer
                      
                  </button>
                      <?php }else{
    
   echo $msg = "<center><h3><strong>Erreur!</strong> Cette Memoire n'est pas disponible!!!</h3></center>";
    
    
}?>
                    </form>
                    
                    
                    
                    
                </div> 
                    
                    
                </div>
        </div>
        
		
							
	</body>
</html>
<?php
    session_start();
	require_once("connectiDb.php");
    $login=isset($_POST['login'])?$_POST['login']:"";
    $pwd=isset($_POST['pwd'])?$_POST['pwd']:"";//pwd c'est le nom dans le formulaire name=""



    $requete="select * from utilisateur where login='$login' and pwd=MD5('$pwd')";
                 //pwd=MD5('$pwd')
    $resultat=$pdo->query($requete);
    if($user=$resultat->fetch()){//si l'utilisateur existe
        if($user['etat']==1){
            $_SESSION['user']=$user;
            header('location:livre.php');
        }else{
            $_SESSION['erreurLogin']="<strong>Erreur!!<strong>votre compte est désactivé.<br> Veuillez contacter l'administarteur";
            header('location:login.php');
        }
        }else{
            $_SESSION['erreurLogin']="<strong>Erreur!!<strong>Login ou mot de passe est incorrecte!!!";
            header('location:login.php');
        }
        
        
?>
<meta charset="utf-8" />
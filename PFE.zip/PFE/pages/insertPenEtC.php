<?php
   session_start();
  if(isset($_SESSION['user'])){//utilisateur connecter
	require_once("connectiDb.php");
	
	
	$idle=$_GET['idle'];
	$ide=$_GET['ide'];
    
      $dateP= date("Y-m-d");
    $dateFp=date('Y-m-d', strtotime($dateP. ' + 30 days'));

	$requete="insert into     penalite(idCd,idEtudiant,dateP,dateFp) values(?,?,?,?)";    
   $param=array($idle,$ide,$dateP,$dateFp);

    $resultat = $pdo->prepare($requete);
    $resultat->execute($param);
      
      
      
      
	header("location:cdPretEt.php");
      }else{//si l'utilisateur n'est pa authentifier
      header("location:login.php");
  }
	
?>
 <meta charset="utf-8" />   
<?php require_once("identifier.php");?>


<!DOCTYPE html>
<html>
<head>
  <title>Mon menu</title>
	<meta charset="utf-8" />
   <link  rel="stylesheet" href="../css/nouveau.css">
 <link href="../css/bootstrap.css" rel="stylesheet">
   <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
   
</head>
<body>
<?php if($_SESSION['user']['role']=='ADMIN'){?>
<nav>
  <div class="container-fluid navbar-fixed-top">
    <ul class="navbar-nav">
        <li><a href="vers.php">Bibliotheque</a></li>
        <li><a>Ouvrages</a>
            <ul>
               <li><a href="livre.php">Livres</a></li>
               <li><a class="nav-link active style= color: chocolate "href="memoire.php">Memoires</a></li>
               <li><a href="cd.php">Cd</a></li>
            </ul>
        </li>
        <li><a>Lecteurs</a>
            <ul>
              <li><a href="enseignant.php" >Enseignant</a></li>
              <li><a href="etudiant.php">Etudiant</a></li>
            </ul>
       </li>
        <?php if($_SESSION['user']['role']=='ADMIN'){?>
       <li><a href="utilisateurs.php">Utilisateur</a></li><?php }?>
        

        
      <li><a>Prêt </a>
        <div >   
           <ul>
            <li class="hover-me"><a >Enseignant</a>
               
               <div class="sub-menu-2">
                   <ul>
                     <li><a href="livrePretEn.php">Livre</a></li>
                     <li><a href="memoirePretEn.php">Mémoire</a></li>
                     <li ><a href="cdPretEn.php">CD</a></li>
                   </ul>
               </div>
               </li>
              <li class="hover-m"><a >Entudiant</a>
               
               <div class="sub-menu-1">
                   <ul>
                     <li><a href="livrePretEt.php">Livre</a></li>
                     <li><a href="memoirePretEt.php">Mémoire</a></li>
                     <li ><a href="cdPretEt.php">CD</a></li>
                   </ul>
               </div>
               </li> 
            </ul></div>
      </li>  
        
        
        
         
      <li><a>Réservation </a>
        <div >   
           <ul>
            <li class="hover-me"><a >Enseignant</a>
               
               <div class="sub-menu-2">
                   <ul>
                     <li><a href="livreReserverEn.php">Livre</a></li>
                     <li><a href="memoireReserverEn.php">Mémoire</a></li>
                     <li ><a href="cdReserverEn.php">CD</a></li>
                   </ul>
               </div>
               </li>
              <li class="hover-m"><a >Entudiant</a>
               
               <div class="sub-menu-1">
                   <ul>
                     <li><a href="livreReserverEt.php">Livre</a></li>
                     <li><a href="memoireReserverEt.php">Mémoire</a></li>
                     <li ><a href="cdReserverEt.php">CD</a></li>
                   </ul>
               </div>
               </li> 
            </ul></div>
      </li>
        
        
        
        
        
        
       
       <li><a>Pénalité</a>
        <div >   
           <ul>
            <li class="hover-me"><a >Enseignant</a>
               
               <div class="sub-menu-2">
                   <ul>
                     <li><a href="penaliteEnl.php">Livre</a></li>
                     <li><a href="penaliteEnm.php">Mémoire</a></li>
                     <li ><a href="penaliteEnc.php">CD</a></li>
                   </ul>
               </div>
               </li>
              <li class="hover-m"><a >Entudiant</a>
               
               <div class="sub-menu-1">
                   <ul>
                     <li><a href="penaliteEtl.php">Livre</a></li>
                     <li><a href="penaliteEtm.php">Mémoire</a></li>
                     <li ><a href="penaliteEtc.php">CD</a></li>
                   </ul>
               </div>
               </li> 
            </ul></div>
  
       <li>
          <a href="editerUser.php?id=<?php echo $_SESSION['user']['idUtilisateur'];?>"><span class="glyphicon glyphicon-user"></span> 
            <?php echo $_SESSION['user']['login'];?>
          </a>
        </li>
       <li><a href="seDeconnecter.php"><i class="glyphicon glyphicon-log-out"></i>Se deconnecter</a></li>
    </ul>
 </div>
</nav>
    <?php }?>
    <!----------------------------------------->
    
    <nav>
  <div class="container-fluid navbar-fixed-top">
    <ul class="navbar-nav">
        <li><a href="vers.php">Bibliotheque</a></li>
        <li><a>Ouvrages</a>
            <ul>
               <li><a href="livre.php">Livres</a></li>
               <li><a class="nav-link active style=" color: chocolate href="memoire.php">Memoires</a></li>
               <li><a href="cd.php">Cd</a></li>
            </ul>
        </li>
        <li><a>Lecteurs</a>
            <ul>
              <li><a href="enseignant.php" >Enseignant</a></li>
              <li><a href="etudiant.php">Etudiant</a></li>
            </ul>
       </li>
        <?php if($_SESSION['user']['role']=='ADMIN'){?>
       <li><a href="utilisateurs.php">Utilisateur</a></li><?php }?>
        

        
      <li><a>Prêt </a>
        <div >   
           <ul>
            <li class="hover-me"><a >Enseignant</a>
               
               <div class="sub-menu-2">
                   <ul>
                     <li><a href="livrePretEn.php">Livre</a></li>
                     <li><a href="memoirePretEn.php">Mémoire</a></li>
                     <li ><a href="cdPretEn.php">CD</a></li>
                   </ul>
               </div>
               </li>
              <li class="hover-m"><a >Etudiant</a>
               
               <div class="sub-menu-1">
                   <ul>
                     <li><a href="livrePretEt.php">Livre</a></li>
                     <li><a href="memoirePretEt.php">Mémoire</a></li>
                     <li ><a href="cdPretEt.php">CD</a></li>
                   </ul>
               </div>
               </li> 
            </ul></div>
      </li>  
        
        
        
         
      <li><a>Réservation </a>
        <div >   
           <ul>
            <li class="hover-me"><a >Enseignant</a>
               
               <div class="sub-menu-2">
                   <ul>
                     <li><a href="livreReserverEn.php">Livre</a></li>
                     <li><a href="memoireReserverEn.php">Mémoire</a></li>
                     <li ><a href="cdReserverEn.php">CD</a></li>
                   </ul>
               </div>
               </li>
              <li class="hover-m"><a >Etudiant</a>
               
               <div class="sub-menu-1">
                   <ul>
                     <li><a href="livreReserverEt.php">Livre</a></li>
                     <li><a href="memoireReserverEt.php">Mémoire</a></li>
                     <li ><a href="cdReserverEt.php">CD</a></li>
                   </ul>
               </div>
               </li> 
            </ul></div>
      </li>
        
        
        
        
        
        
        
        
        
        
        
       <li><a>Pénalité</a>
        <div >   
           <ul>
            <li class="hover-me"><a >Enseignant</a>
               
               <div class="sub-menu-2">
                   <ul>
                     <li><a href="penaliteEnl.php">Livre</a></li>
                     <li><a href="penaliteEnm.php">Mémoire</a></li>
                     <li ><a href="penaliteEnc.php">CD</a></li>
                   </ul>
               </div>
               </li>
              <li class="hover-m"><a >Entudiant</a>
               
               <div class="sub-menu-1">
                   <ul>
                     <li><a href="penaliteEtl.php">Livre</a></li>
                     <li><a href="penaliteEtm.php">Mémoire</a></li>
                     <li ><a href="penaliteEtc.php">CD</a></li>
                   </ul>
               </div>
               </li> 
            </ul></div>
      </li>
       <li>
          <a href="editerUser.php?id=<?php echo $_SESSION['user']['idUtilisateur'];?>"><span class="glyphicon glyphicon-user"></span> 
            <?php echo $_SESSION['user']['login'];?>
          </a>
        </li>
       <li><a href="seDeconnecter.php"><i class="glyphicon glyphicon-log-out"></i>Se deconnecter</a></li>
    </ul>
 </div>
</nav>
    
    
    
    <!------------------------------------------------------------->
</body>
</html>

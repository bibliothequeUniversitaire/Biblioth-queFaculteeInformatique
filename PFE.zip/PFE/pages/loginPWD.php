<!DOCTYPE html>
<html>
<head>
<title>passe word oublié</title>	
<meta charset="utf-8">
</head>
	
<body>
 <div align="center">
	<form method="post" action="">
	  <input type="text" name="pseudo" placeholder="pseudo">
	  <br/>
	  <input type="email" name="email" placeholder="email">
	  <br/>
	  <input type="password" name="mdp" placeholder="password">
	  <br/>
	  <input type="submit" name="ok" placeholder="valider">
	  <br/>
	  <a href="forget.php"><p>Mot de Passe oublié</p></a>
	</form>
 </div>	
</body>
</html>
<?php
   session_start();
  if(isset($_SESSION['user'])){//utilisateur connecter
	require_once("connectiDb.php");
	
	
	$idlen=$_GET['idlen'];
	$iden=$_GET['iden'];
    $nbr=$_GET['nbrEn'];
      
	$requete="delete from penalite where idLivre=? and idEnseignant=?";			
	$param=array($idlen,$iden);	
	$resultatL = $pdo->prepare($requete);
    $resultatL ->execute($param);
      $nbr=$nbr+1; 
      
      /////////////////////////
      $requetenbr="update livre set nbrCopie='$nbr' where idLivre='$idlen';";    
   $paramm=array($nbr);

    $resultatnbr = $pdo->prepare($requetenbr);
    $resultatnbr->execute($paramm);
      
      
      
      
	header("location:penaliteEnl.php");
      }else{//si l'utilisateur n'est pa authentifier
      header("location:login.php");
  }
	
?>
    
<?php
    require_once("identifier.php");
	require_once("connectiDb.php");
     
     $titrec=isset($_GET['titreC'])?$_GET['titreC']:"";
     $categotie=isset($_GET['categorie'])?$_GET['categorie']:"all";//pour recuperer le parametre envoyer dans utl
     $encadreurEtudiantc=isset($_GET['encadreurEtudiantC'])?$_GET['encadreurEtudiantC']:"";
     $anneec=isset($_GET['anneeC'])?$_GET['anneeC']:"";
     $size=isset($_GET['size'])?$_GET['size']:6;
     $page=isset($_GET['page'])?$_GET['page']:1;
     $offset=($page-1)*$size;


if($categotie=="all"){
     $requete="select * from cd
                   where  (encadreur like '%$encadreurEtudiantc%' or etudiant   like '%$encadreurEtudiantc%')
                   and titre like '%$titrec%'
                   and anneeEdition like '%$anneec%'
                   limit $size offset $offset";
     $requeteCount="select count(*) countC from cd 
              where  (encadreur like '%$encadreurEtudiantc%' or etudiant   like '%$encadreurEtudiantc%')
                   and titre like '%$titrec%'
                   and anneeEdition like '%$anneec%'";
}else{
    
     $requete="select * from cd
                   where  (encadreur like '%$encadreurEtudiantc%' or etudiant   like '%$encadreurEtudiantc%')
                   and titre like '%$titrec%'
                   and anneeEdition like '%$anneec%'
                   and categorie='$categotie'
                   limit $size offset $offset";
    $requeteCount="select count(*) countC from cd 
                 where  (encadreur like '%$encadreurEtudiantc%' or etudiant  like '%$encadreurEtudiantc%')
                 and titre like '%$titrec%'
                 and anneeEdition like '%$anneec%'
                 and categorie='$categotie'";
    
}
     $resultatC=$pdo->query($requete);//execution de la requete
     $resultatCount=$pdo->query($requeteCount);
     $tabCount=$resultatCount->fetch();
     $nbrCd=$tabCount['countC'];
     $reste=$nbrCd % $size; // % operateur modulo:le reste de la division euclidiene de $nbrFiliere par
                               //$size
   if($reste==0)//nbrFiliere est un multiple de size
        $nbrPage=$nbrCd/$size;
   else
		$nbrPage=floor($nbrCd/$size)+1;// floor retourne la partie entière d'un nombre 
										// decimale
?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Gestion des cd</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/monstyle.css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
		
                
 
	</head>
    <body>
        
        <style>
          body {
              background-image: url('95571686_2695129650770008_1954315548242214912_n.jpg');
               }
        </style>  
        
        
        
<?php include("nouveau.php");?>
  <div class="container" id="padding">    <!--container permet d'apliquer une marge gauche et droite-->
   <div class="panel panel-info margetop">
    <div class="panel-heading " id="color" style="color: black">Recherche des cd</div>
     <div class="panel-body">
      <form method="get" action="cd.php" class="form-inline" >
       <div class="form-group" >
                  &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
         <input type="text" 
				name="titreC" 
				placeholder="Titre cd" 
				class="form-control" 
				value="<?php echo $titrec?>"/>
                        &nbsp &nbsp
         <input type="text" 
				name="encadreurEtudiantC" 
				placeholder="Encadreur ou Etudiant" 
				class="form-control" 
				value="<?php echo $encadreurEtudiantc?>"/>   
                            &nbsp &nbsp
         <input 
                type="number"    
				min="1900" 
				max="3000"  
				name="anneeC"
                placeholder="Annee d'édition" 
				class="form-control" 
				value="<?php echo $anneec?>"/>
                   
       </div> 
		  
       <label for="categorie">Catégorie:</label>
        <select name="categorie" 
				class="form-control" 
				id="categorie" 
				onchange="this.form.submit()" ><!--this.from.submit() evenement de js-->
			
          <option value="all"<?php if($categotie==="all") echo "selected"?> 
				  style="color: black">Tous les cd</option>
			
          <option value="master"<?php if($categotie==="master") echo "selected"?> 
				  style="color: black">master</option>
			
          <option value="licence"<?php if($categotie==="licence") echo "selected"?> 
				  style="color: black">licence</option>
			
        
	      <option value="doctorat"<?php if($categotie==="doctorat") echo "selected"?> 
				  style="color: black">doctorat</option>
         
		  <option value="majister"<?php if($categotie==="majister") echo "selected"?> 
				  style="color: black">majister</option>
        </select>
                 &nbsp &nbsp &nbsp
        <button type="submit" 
				class="btn btn-warning" 
				style="color: black">
        
		<span class="glyphicon glyphicon-search" 
			  style="color: black"></span>Rechercher...
        </button>
                <?php if($_SESSION['user']['role']=='ADMIN'){?>
                <a href="nouveauCd.php" style="color: black"><span class="glyphicon glyphicon-plus" style="color: black"></span>Nouveau cd</a><?php }?>
       </form>    
      </div>
     </div>
                
     <div class="panel panel-info margetop" >
     <div class="panel-heading" 
		  id="color" 
		  style="color: black">Liste des cd (<?php echo $nbrCd?> Cd)</div>
     
	 <div class="panel-body">
       <table class="table table-striped table-bordered">
       <thead>
     <tr style="color: chocolate">
         <th >N° CD</th>
	     <th >titre</th>
	     <th >Etudiant</th>
		 <th >Encadreur</th>
		 <th >Catégorie</th>
		 <th >Edition</th>
		 <th >AnneeEdition</th>
		 <th >Copie</th>
		 <th >Détail</th>
         <th >Pret</th>
		 <th >Reserver</th>
		 
         <?php if($_SESSION['user']['role']=='ADMIN'){?>    
         <th >Action</th>
         <?php }?>
                            
       </tr>
       </thead>          
       <tbody>
                        
     <?php while($cd=$resultatC->fetch()){?>   
                      <tr style="color: black">
                          <td ><?php echo $cd['idCd']?></td>
                          <td ><?php echo $cd['titre']?></td>
                          <td ><?php echo $cd['etudiant']?></td>
                          <td ><?php echo $cd['encadreur']?></td>
                          <td ><?php echo $cd['categorie']?></td>
                          <td ><?php echo $cd['edition']?></td>
                          <td ><?php echo $cd['anneeEdition']?></td>
                          <td ><?php echo $cd['nbrCopie']?></td>
                          
                          <td>
                             &nbsp &nbsp
                             <a href="detailCd.php?idc=<?php echo $cd['idCd']?>">
						     <span class="glyphicon glyphicon-play" 
								   style="color: #994d00"></span></a>
						  </td> 
                          
                          <td><a style="color: chocolate" 
								 href="formulairePretC.php?idc=<?php echo $cd['idCd']?>" 
								 style="color: #994d00"> 
						         <span class="glyphicon glyphicon-triangle-right"></span></a>
						  </td>
                                
                          <td><a style="color: chocolate" 
								 href="formulaireReserverC.php?idc=<?php echo $cd['idCd']?>" style="color: #994d00">
					      <span class="glyphicon glyphicon-triangle-right"></span></a>
						  </td> 
                          
                          <?php if($_SESSION['user']['role']=='ADMIN'){?>
                          <td style="color: black">
                            <a href="editerCd.php?idc=<?php echo $cd['idCd']?>">      
					        <span class="glyphicon glyphicon-edit" 
								  style="color: #994d00"></span></a>
                            &nbsp &nbsp
                          <a onclick="return confirm('Etes vous sure de vouloire    supprimer ce  cd' )"
                             href="supprimerCd.php?idc=<?php echo $cd['idCd']?>">
							 <span class="glyphicon glyphicon-trash" 
								   style="color: #994d00"></span></a>  
                          </td><?php }?>
                         </tr><?php }?>    
                       </tbody>    
                     </table>   
                   <div>
                   <ul class="pagination" >
						<?php for($i=1;$i<=$nbrPage;$i++){ ?>
				              <li class="<?php if($i==$page) echo 'active' ?>" >
                              <a href="cd.php?page=<?php echo $i ?>&titreC=<?php echo $titrec?>&categorie=<?php echo  $categotie?>" >
                              <?php echo $i ?>
							  </a>
							  </li>
					   <?php } ?>	
				   </ul>
                  </div>    
                </div>
           </div>
       </div>    
    </body>
</html>    





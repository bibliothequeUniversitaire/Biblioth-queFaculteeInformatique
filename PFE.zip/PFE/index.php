<?php
  header("location:pages/vers.php");

?>



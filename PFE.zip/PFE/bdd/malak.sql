drop database if exists jdida;
create database if not exists jdida;
use jdida;

create table etudiant(
   idEtudiant int(10)  not null auto_increment primary key,
   nom varchar (50),
   prenom  varchar (50),
   numCarte   bigint,
   cevilite  varchar (1),
   niveau varchar(100),
   idLivre int(4),
   idCd int(4),
   idmemoire int(4),
   foreign key(idLivre) references livre(idLivre),
   foreign key(idCd) references cd(idCd),
   foreign key(idmemoire) references memoire(idmemoire)
);
create table enseignant(
   idEnseignant int(10)  not null auto_increment primary key,
   nom varchar (50),
   prenom  varchar (50),
   numCarte  bigint,
   cevilite  varchar (1),
   idLivre int(4),
   idCd int(4),
   idmemoire int(4),
   foreign key(idLivre) references livre(idLivre),
   foreign key(idCd) references cd(idCd),
   foreign key(idmemoire) references memoire(idmemoire)
);


create table livre(
   idLivre int(10) not null auto_increment primary key,
   titre varchar(100),
   auteur varchar(50),
   maisonEdition varchar(50),
   anneeEdition  int(8),
   nbrCopie int(50),
   photos varchar(100),
   description varchar(500),
   branche varchar(100)            
);

create table cd(
   idCd int(10) not null auto_increment primary key,
   titre varchar(100),
   etudiant varchar(50),
   categorie varchar(50),
   edition varchar(40),
   anneeEdition  int(8),
   nbrCopie int(10),
   description varchar(500),
    encadreur  varchar(100) 
);

create table memoire(
   idmemoire int(10) not null auto_increment primary key,
   titre varchar(500),
   etudiant varchar(50),
   categorie varchar(50),
   edition varchar(40),
   anneeEdition  int(8),
   nbrCopie int(10),
   photos varchar(30),
   description varchar(500),
   encadreur varchar(100)    
);
    
create table reserver(
   idReservation int(4) not null auto_increment primary key,
   idmemoire int(4)  ,
   idCd int(4)  ,
   idLivre int(4)  ,
   idEtudiant int(4)   ,
   idEnseignant int(4),
   dateRes date,
   dateFinRes date,
   foreign key(idLivre) references livre(idLivre),
   foreign key(idCd) references cd(idCd),
   foreign key(idmemoire) references memoire(idmemoire),
   foreign key(idEtudiant) references etudiant(idEtudiant),
   foreign key(idEnseignant) references enseignant(idEnseignant)
);

create table emprunt(
   idEmrunt int(4) not null auto_increment primary key,
   idmemoire int(4)  ,
   idCd int(4)  ,
   idLivre int(4)  ,
   idEtudiant int(4)   ,
   idEnseignant int(4)   ,
   datePret date,
   dateRetour date,
   foreign key(idCd) references cd(idCd),
   foreign key(idmemoire) references memoire(idmemoire),
   foreign key(idLivre) references livre(idLivre),
   foreign key(idEtudiant) references etudiant(idEtudiant),
   foreign key(idEnseignant) references enseignant(idEnseignant)
);

create table penalite(
idPenalite int(4) not null auto_increment primary key,
    idmemoire int(4)  ,
   idCd int(4)  ,
   idLivre int(4)  ,
   idEtudiant int(4)   ,
   idEnseignant int(4)   ,
dateP date,
dateFp date,
    
    foreign key(idCd) references cd(idCd),
   foreign key(idmemoire) references memoire(idmemoire),
   foreign key(idLivre) references livre(idLivre),
   foreign key(idEtudiant) references etudiant(idEtudiant),
   foreign key(idEnseignant) references enseignant(idEnseignant)
);


create table utilisateur(
   idUtilisateur int(4) not null auto_increment primary key,
   login varchar(50),
   email  varchar(500),
   role varchar(50),
   etat int(1),
   pwd varchar(255)
);


create table users(
   id int(4) not null auto_increment primary key,
   pseudo varchar(50),
   mdp varchar(255),
   email  varchar(500)
);

insert into users(pseudo,mdp,email) values("fatima","malak","sehilfatimazohra19@gmail.com");
insert into users(pseudo,mdp,email) values("radia","nadjet","nadjetradia22@gmail.com");


insert into 
livre(titre,auteur,maisonEdition,anneeEdition,nbrCopie,photos,description,branche) values
('introduction au base de donnees ACCEES','philippe Bellan ','ellesses','2006',3,'20200301_131500.jpg','permetre a chacun de se construire une base de donnee personel ou profestionel','base de donnee' ),

('C++','Brain overland','Osman eyrolles multimedia','2000',3,'20200301_131538.jpg','est un livre qui derit le C++ dans un langage claire et accessible','langage de programmation'),

('compilateur','A.Aho, M.Lan ,R.Sethi','Pearson','2007',2,'20200301_131558.jpg','est un livre pour la compilation, Principe technique et outils ','compilation'), 

('Base de donnee sur unix','david Egan','Eyrolles','2000',5,'20200301_131618.jpg','est un livre pour insteller et configurer MySQL, postegreSQL, oracle, BD2','base de donnee'),

('algorithme strectured computer arrays and  networks','leonard uhr','academic press','1984',1,'20200301_131632.jpg','architecture and processes for image perfect model information ','algorithme'),

('poptez vos bases ACCESS sur le web ','Remy lentzner','dunod','2004',4,'20200301_131834.jpg','ce livre montre comment porter et gerer une bese de donnee microoft accesses sur le web','base de donnee'),

('introduction a algorithme' ,'thomas h.cormen','donond','2002',2,'20200301_131801.jpg','cet livre sans equivalent exhaustif et acces facil est une introdction complet a algorithme ','algorithme'),

('architecture aux ordinateur','andrew tan','donond','2002',2,'20200301_131801.jpg','cet livre sans equivalent exhaustif et acces facil est une introdction complet a algorithme ','architecture');
   
insert into cd(titre,etudiant,categorie,edition,anneeEdition,nbrCopie,description,encadreur) values
('application don de sang','yebous toufik abdelillah','licence','udl','2016',3,'//','belfedhal alaa eddine'),

('classification utilisant les metaaheuristiques ','yousfate mohamed amine','master','udl','2018',2,'//','elberrichi'), 

('conception ert realisationapplication web pour une location de voiture','khelidje amel','licence','udl','2013',5,'//','boukli hacene sofi ne'),

('realisation une application web pour la gestion de vehicule','lebdouni mehamed','licence','udl','2018',1,'//','belhia'),

('conception et realisation dun application a base des servise web pour la gestion de la bibliotheque','khadraoui mohamed ilies','master','udl','2015',4,'//','toumouh adil'),

('application web pour la gestion de bibliotheque ','taibi malika ','licence ','udl','2009',2,'//','//'),

('application don de sang','yebous toufik abdelillah, mime alae eddine','licence','udl','2016',3,'//','belfedhal alaa eddine'),

('classification utilisant les metaaheuristiques ','yousfate mohamed amine','master','udl','2018',2,'//','elberrichi'), 

('conception ert realisationapplication web pour une location de voiture','khelidje amel','licence','udl','2013',5,'//','boukli hacene sofi ne'),

('realisation une application web pour la gestion de vehicule','lebdouni mehamed','licence','udl','2018',1,'//','belhia'),

('conception et realisation dun application a base des servise web pour la gestion de la bibliotheque','khadraoui mohamed ilies','master','udl','2015',4,'//','toumouh adil'),

('application web pour la gestion de bibliotheque ','taibi malika ','licence ','udl','2009',2,'//','//'),

('realisation une application web pour la gestion ','sihem khiat','licence ','udl','2018',3,'//','toumouh adil');

insert into memoire(titre,etudiant,categorie,edition,anneeEdition,nbrCopie,photos,description,encadreur) values 
('application don de sang','yebous toufik abdelillah','licence','udl','2016',3,'20200301_101902.jpg','//','belfedhal alaa eddine'),

('classification utilisant les metaaheuristiques ','yousfate mohamed amine','master','udl','2018',2,'20200301_101910.jpg','//','elberrichi'), 

('conception ert realisationapplication web pour une location de voiture','khelidje amel','licence','udl','2013',5,'20200301_101918.jpg','//','boukli hacene sofine'),

('application don de sang','yebous toufik abdelillah, mime alae eddine','licence','udl','2016',3,'20200301_101902.jpg','//','belfedhal alaa eddine'),

('classification utilisant les metaaheuristiques ','yousfate mohamed amine','master','udl','2018',2,'20200301_101910.jpg','//','elberrichi'), 

('conception ert realisationapplication web pour une location de voiture','khelidje amel','licence','udl','2013',5,'20200301_101918.jpg','//','boukli hacene sofine'),

('realisation une application web pour la gestion de vehicule','lebdouni mehamed','licence','udl','2018',1,'20200301_101924.jpg','//','belhia'),

('conception et realisation dun application a base des servise web pour la gestion de la bibliothequen','khadraoui mohamed ilies','master','udl','2015',4,'20200301_101930 (2).jpg','//','toumouh adil'),

('application web pour la gestion de bibliotheque ','taibi malika ','licence ','udl','2009',2,'20200301_132103.jpg','//','//'),

('realisation une application web pour la gestion de vehicule','lebdouni mehamed','licence','udl','2018',1,'20200301_101924.jpg','//','belhia'),

('conception et realisation dun application a base des servise web pour la gestion de la bibliothequen','khadraoui mohamed ilies','master','udl','2015',4,'20200301_101930 (2).jpg','//','toumouh adil'),

('application web pour la gestion de bibliotheque ','taibi malika ','licence ','udl','2009',2,'20200301_132103.jpg','//','//'),

('realisation une application web pour la gestion ','sihem khiat','licence ','udl','2018',2,'20200301_131856.jpg','//','toumouh adil');
   
   insert into utilisateur(login,email,role,etat,pwd) values
    ('admin','radiayassine13gmail.com','ADMIN',1,md5('malak')),
    ('user','nardjesfatima09@gmail.com','ADMIN',1,md5('malak')),
	('use1','user1@gmail.com','VISITEUR',1,md5('use1')),
	('use2','user2@gmail.com','VISITEUR',1,md5('use2'));
	
   
insert into etudiant(nom,prenom,numCarte,cevilite,niveau) values
    ('sehil','fatima zohra',171738037067,'F','l3'),
    ('yassine','radia nadjet',171738037068,'F','l3'),
    ('sahali','riheb',171738037069,'F','l3'),
    ('ouzaid','nassim',171738037070,'M','l3'),
    ('soussi','houssem',171738037071,'M','l3'),
	('nekrouf','ikram',171738037090,'F','l3'),
    ('kara ali','imene',171738037172,'F','l2'),
    ('rais','akram',171738037072,'M','l2'),
    ('boussahla','ahmad',171738037073,'M','l3'),
	('lahsen','fatima',171738037074,'F','l3'),
    ('didi','anes',171738037075,'M','m1'),
('habibech','sakina',171738037076,'F','m2'),
    ('oualhaci','mohamed',171738037077,'M','m1'),
    ('ghermaoui','amine',171738037078,'M','l2'),
    ('sanogo','adama',171738037079,'M','l2'),
	('reuth','alexandra',171738037080,'F','m1');
    
    
    
   insert into enseignant(nom,prenom,numCarte,cevilite) values
    ('abbad','houda',12347541,'F'),
    ('niar','leila',12347542,'F'),
    ('mustfai','//',12347546,'F'),
    ('salama','//',12347547,'F'),
    ('merazi','//',12347549,'F'),
    ('bouamama','abdelouafi',12347543,'M'),
    ('chaieb','yazid',12347544,'M'),
    ('berrabah','djamel',12347548,'M'),
	('boucli','hassansofiane',12347545,'M');
   

    
    
    
select current_date from dual;

insert into reserver(idLivre,idEtudiant,dateRes,dateFinRes) values
(1,9,'2020-04-02','2020-04-05'),
(7,5,'2020-04-03','2020-04-06'),
(2,1,'2020-04-04','2020-05-07'),
(8,2,'2020-04-05','2020-04-08');



insert into reserver(idLivre,idEnseignant,dateRes,dateFinRes) values

(1,1,'2020-04-02','2020-04-07'),
(7,2,'2020-04-03','2020-04-08'),
(2,3,'2020-04-04','2020-05-09');



insert into reserver(idmemoire,idEtudiant,dateRes,dateFinRes) values

(1,1,'2020-04-02','2020-04-05'),
(7,2,'2020-04-03','2020-04-06'),
(3,3,'2020-04-04','2020-04-07');


insert into reserver(idmemoire,idEnseignant,dateRes,dateFinRes) values

(4,1,'2020-04-02','2020-04-07'),
(7,2,'2020-04-03','2020-04-08'),
(8,3,'2020-04-04','2020-04-09');


insert into reserver(idCd,idEtudiant,dateRes,dateFinRes) values

(1,6,'2020-04-02','2020-04-05'),
(7,2,'2020-04-03','2020-04-06'),
(3,4,'2020-04-04','2020-04-07');

insert into reserver(idCd,idEnseignant,dateRes,dateFinRes) values

(2,1,'2020-04-02','2020-04-07'),
(3,2,'2020-04-03','2020-04-08'),
(2,3,'2020-04-04','2020-04-09');

select * from reserver;




insert into emprunt(idLivre,idEtudiant,datePret,dateRetour) values
(1,9,'2020-10-12','2020-11-12'),
(7,5,'2012-03-02','2012-03-15'),
(2,1,'2012-03-02','2012-03-15'),
(8,2,'2012-03-02','2012-03-15'),
(4,4,'2012-03-02','2012-03-15'),
(5,6,'2012-03-02','2012-03-15'),
(6,7,'2012-03-02','2012-03-15'),
(3,7,'2018-10-12','2018-10-31');


insert into emprunt(idLivre,idEnseignant,datePret,dateRetour) values
(1,8,'2020-10-12','2020-11-12'),
(2,1,'2012-03-02','2012-03-15'),
(3,5,'2019-04-12','2019-04-16'),
(4,2,'2020-08-12','2020-08-11'),
(5,3,'2012-03-12','2012-03-19'),
(6,2,'2018-10-12','2018-10-31');

insert into emprunt(idmemoire,idEtudiant,datePret,dateRetour) values
(1,1,'2020-10-12','2020-11-12'),
(7,2,'2012-03-02','2012-03-15'),
(3,3,'2018-10-12','2018-10-31');


insert into emprunt(idmemoire,idEnseignant,datePret,dateRetour) values
(1,1,'2020-10-12','2020-11-12'),
(2,2,'2012-03-02','2012-03-15'),
(3,3,'2019-04-12','2019-04-16'),
(4,4,'2020-08-12','2020-08-11'),
(5,5,'2012-03-12','2012-03-19'),
(6,6,'2018-10-12','2018-10-31');


insert into emprunt(idCd,idEtudiant,datePret,dateRetour) values
(1,1,'2020-10-12','2020-11-12'),
(7,2,'2012-03-02','2012-03-15'),
(3,3,'2018-10-12','2018-10-31');



insert into emprunt(idCd,idEnseignant,datePret,dateRetour) values
(1,1,'2020-10-12','2020-11-12'),
(2,2,'2012-03-02','2012-03-15'),
(3,3,'2019-04-12','2019-04-16'),
(4,4,'2020-08-12','2020-08-11'),
(5,5,'2012-03-12','2012-03-19'),
(6,6,'2018-10-12','2018-10-31');



insert into penalite(idLivre,idEtudiant,dateP,dateFp) values

(5,5,'2012-03-12','2012-04-12'),
(6,6,'2018-10-12','2018-11-12');






insert into penalite(idmemoire,idEtudiant,dateP,dateFp) values

(10,4,'2020-08-12','2020-09-12'),
(11,5,'2012-03-12','2012-04-12'),
(12,6,'2018-10-12','2018-11-12');


insert into penalite(idCd,idEtudiant,dateP,dateFp) values

(9,3,'2019-04-12','2019-05-12'),
(10,4,'2020-08-12','2020-09-12'),
(11,5,'2012-03-12','2012-04-12'),
(12,6,'2018-10-12','2018-11-12');

insert into penalite(idLivre,idEnseignant,dateP,dateFp) values
(5,2,'2020-04-01','2020-05-01'),
(8,3,'2020-05-01','2020-06-01'),
(6,5,'2020-06-01','2020-07-01'),
(3,8,'2020-07-01','2020-08-01');


   insert into penalite(idmemoire,idEnseignant,dateP,dateFp) values
(5,2,'2020-08-01','2020-09-01'),
(8,3,'2020-10-01','2020-11-01'),
(6,5,'2020-06-01','2020-07-01'),
(3,8,'2020-07-01','2020-08-01');                              
                                 
                                 
                          
    insert into penalite(idCd,idEnseignant,dateP,dateFp) values
(6,2,'2020-08-01','2020-09-01'),
(2,6,'2020-10-01','2020-11-01'),
(1,7,'2020-06-01','2020-07-01'),
(3,1,'2020-07-01','2020-08-01');                       
                          
                          
                          
                                 
                                 
   select * from emprunt;

   select * from memoire;
   select * from cd;
   select * from livre;
   select * from utilisateur;
   select * from users;
   